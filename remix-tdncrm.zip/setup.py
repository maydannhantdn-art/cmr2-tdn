import os
import subprocess
import sys
import shutil
import json

def run_command(command, shell=True):
    """Executes a command and returns the output."""
    try:
        process = subprocess.Popen(command, shell=shell, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8')
        for line in process.stdout:
            print(line, end='')
        process.wait()
        return process.returncode
    except Exception as e:
        print(f"Error executing command: {e}")
        return 1

def main():
    print("=========================================================================")
    print("        TÍN DÂN CRM COMPANY - GIẢI PHÁP TRIỂN KHAI LOCAL CHẠY THẬT        ")
    print("=========================================================================\n")
    print("Chào Sếp! Em là trợ lý hệ thống. Em sẽ hỗ trợ Sếp tự động cài cấu hình")
    print("và tất cả các công cụ cần thiết để ứng dụng CRM/Zalo/Chatbot chạy thực tế")
    print("trên bất kỳ máy tính chạy Windows/macOS hoặc Linux nào mới tinh nhé!\n")

    # 1. Check for Node.js / NPM
    print("[HỆ THỐNG 1/5] Kiểm tra nền tảng Node.js / NPM...")
    try:
        npm_check = subprocess.run(["npm", "-v"], capture_output=True, shell=True)
        if npm_check.returncode != 0:
            raise FileNotFoundError
        print(f"✓ Hoàn tất! Phát hiện thấy NPM phiên bản: {npm_check.stdout.decode().strip()}\n")
    except Exception:
        print("❌ LỖI NGHIÊM TRỌNG: Máy của sếp chưa được cài đặt Node.js!")
        print("👉 Hướng dẫn sửa lỗi:")
        print("  1. Truy cập trang chủ: https://nodejs.org/ (Nên chọn bản LTS)")
        print("  2. Tải về và cài đặt trực tiếp.")
        print("  3. Sau đó khởi động lại Terminal và chạy lại file setup.py này của em nhé.")
        sys.exit(1)

    # 2. Check for Firebase Applet Configuration
    print("[HỆ THỐNG 2/5] Kiểm định cấu hình cơ sở dữ liệu Firestore...")
    config_path = "firebase-applet-config.json"
    if os.path.exists(config_path):
        print("✓ Hoàn tất! Đã nhận dạng được file cấu hình Firebase thực: firebase-applet-config.json")
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                cfg = json.load(f)
                print(f"  - Project ID: {cfg.get('projectId', 'N/A')}")
                print(f"  - Database: {cfg.get('firestoreDatabaseId', '(default)')}")
        except Exception:
            print("  ⚠️ Cảnh báo: File firebase-applet-config.json lỗi định dạng JSON.")
    else:
        print("⚠️ Cảnh báo: Không tìm thấy file firebase-applet-config.json!")
        print("  Để kết nối database thực, sếp hãy dán file firebase-applet-config.json vào thư mục gốc này.")
    print("")

    # 3. Setup Environment Variables
    print("[HỆ THỐNG 3/5] Khởi tạo tệp môi trường thực tế (.env)...")
    if not os.path.exists(".env"):
        if os.path.exists(".env.example"):
            shutil.copy(".env.example", ".env")
            print("✓ Đã sao chép thành công file .env từ .env.example.")
        else:
            with open(".env", "w", encoding='utf-8') as f:
                f.write("GROQ_API_KEY=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\n")
                f.write("NODE_ENV=development\n")
            print("✓ Đã tạo mới file .env với cấu hình mặc định.")
    else:
        print("✓ File cấu hình thực tế .env đã có sẵn.")
    print("")

    # 4. Install Dependencies
    print("[HỆ THỐNG 4/5] Đang tự động tải các gói thư viện (npm install) hỏa tốc...")
    if run_command("npm install") != 0:
        print("❌ LỖI: Không thể cài đặt các package Node.js. Sếp vui lòng kiểm tra kết nối mạng.")
        sys.exit(1)
    print("✓ Tải và cài đặt các package hoàn tất!\n")

    # 5. Ngrok configuration instruction
    print("[HỆ THỐNG 5/5] CẤU HÌNH NGHIÊP VỤ NGROK ĐỂ CHẠY THẬT:")
    print("-------------------------------------------------------------------------")
    print("Để nhúng được Chatbot Duyên vào Website thực tế và nhận Webhook Zalo thực,")
    print("Sếp cần mở cổng kết nối từ máy Sếp ra ngoài internet thông qua Ngrok:")
    print("")
    print("👉 Bước 1: Mở một cửa sổ Terminal mới (hoặc CMD/Powershell) trên máy Sếp.")
    print("👉 Bước 2: Tải Ngrok và chạy lệnh sau:")
    print("      ngrok http 3000")
    print("👉 Bước 3: Copy đường link dạng https://xxxx.ngrok-free.app mà Ngrok cấp.")
    print("👉 Bước 4: Copy Script nhúng dưới đây và dán vào website của Sếp:")
    print("      <script src=\"https://[ĐƯỜNG-DẪN-NGROK-CỦA-SẾP]/api/chatbot/embed.js\"></script>")
    print("-------------------------------------------------------------------------\n")

    # Start option
    try:
        reply = input("Sếp có muốn khởi chạy máy chủ CRM Tín Dân ngay lúc này không? (y/n): ").strip().lower()
        if reply == 'y' or reply == '':
            print("\n🚀 ĐANG KHỞI CHẠY HỆ THỐNG (CHẠY THỰC TẾ)...")
            print("👉 Địa chỉ quản trị CRM nội bộ: http://localhost:3000")
            print("👉 Bấm Ctrl + C để tắt máy chủ.\n")
            run_command("npm run dev")
        else:
            print("\n✓ Đã thiết lập xong toàn bộ môi trường và tải xong thư viện!")
            print("Sếp có thể gõ lệnh: 'npm run dev' bất cứ lúc nào để bật hệ thống lên nhé.")
    except KeyboardInterrupt:
        print("\nĐã dừng hệ thống.")

if __name__ == "__main__":
    main()
