/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { User, UserRole, Department, ThemeMode } from '../types';
import { 
  LayoutDashboard, 
  CheckSquare, 
  FolderKanban, 
  FileSpreadsheet, 
  FileBox, 
  TrendingUp, 
  MessageSquareCode, 
  Bell, 
  Settings, 
  LogOut,
  FolderOpen,
  Palette,
  Briefcase,
  Sparkles,
  User as UserIcon
} from 'lucide-react';

interface NavigationProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  currentUser: User;
  onLogout: () => void;
  unreadCount: number;
}

export default function Navigation({ currentTab, setCurrentTab, currentUser, onLogout, unreadCount }: NavigationProps) {
  
  const menuItems = [
    { id: 'dashboard', label: 'Bàn làm việc', icon: LayoutDashboard },
    { id: 'tasks', label: 'Công việc', icon: CheckSquare },
    { id: 'projects', label: 'Dự án', icon: FolderKanban },
    { id: 'excel-import', label: 'AI Nhập Excel', icon: FileSpreadsheet },
    { id: 'reports', label: 'AI Báo cáo', icon: FileBox },
    { id: 'kpis', label: 'Chỉ số KPI', icon: TrendingUp },
    { id: 'assistant', label: 'Trợ lý AI', icon: MessageSquareCode },
    { id: 'duyen-chatbot', label: 'Chatbot Duyên', icon: Sparkles },
    { id: 'zalo-oa', label: 'Zalo OA', icon: Briefcase },
    { id: 'files', label: 'Tài liệu xưởng', icon: FolderOpen },
    ...(currentUser.role === UserRole.SUPER_ADMIN || currentUser.role === UserRole.ADMIN ? [{ id: 'users', label: 'Thành viên', icon: UserIcon }] : []),
    { id: 'settings', label: 'Cấu hình', icon: Settings }
  ];

  return (
    <>
      {/* WINDOWS/MAC DESKTOP SIDEBAR - Left Side */}
      <aside className="hidden lg:flex flex-col w-64 glass-sidebar text-slate-800 dark:text-slate-300 h-screen sticky top-0 shrink-0 justify-between select-none font-sans">
        
        {/* Top Branding Section */}
        <div className="p-5">
          <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800/80 pb-5">
            <div className="bg-white p-1 rounded-lg shrink-0 shadow-sm border border-slate-100">
              <img 
                src="https://temvivian.vn/wp-content/uploads/2024/11/logo-tin-dan-tdn.png" 
                alt="Logo Tín Dân" 
                className="h-8 w-auto object-contain"
              />
            </div>
            <div>
              <h2 className="text-sm font-bold tracking-tight text-slate-800 dark:text-white font-display block uppercase">Tín Dân CRM</h2>
              <span className="text-[10px] text-blue-600 dark:text-blue-400 font-mono tracking-wider">Hệ Điều Hành AI</span>
            </div>
          </div>

          {/* Department Workspace Badge Section */}
          <div className="mt-4 bg-white/50 dark:bg-slate-950/55 border border-slate-200/50 dark:border-slate-850 rounded-lg p-3">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500 glow-animation shrink-0" />
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-widest font-display">
                Phòng {currentUser.department}
              </span>
            </div>
            <span className="text-[10px] text-slate-400 dark:text-slate-550 block mt-1">Quyền: {currentUser.role}</span>
          </div>
        </div>

        {/* Middle Sidebar Menus */}
        <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto">
          {menuItems.map((item) => {
            const IconComponent = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2 text-xs font-medium rounded-lg transition-all border ${
                  isActive 
                    ? 'bg-blue-600/10 text-blue-650 dark:text-blue-400 border-blue-500/25 dark:border-blue-400/20 font-semibold' 
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/50 dark:hover:bg-white/5 border-transparent'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <IconComponent className={`w-4 h-4 ${isActive ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.id === 'dashboard' && unreadCount > 0 && (
                  <span className="px-1.5 py-0.5 rounded-full bg-red-500 text-white font-mono text-[9px] font-bold">
                    {unreadCount}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Bottom User Profile Section */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-white/30 dark:bg-slate-950/20 space-y-3">
          <div className="flex items-center gap-3">
            <img 
              src={currentUser.avatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150"} 
              alt={currentUser.name} 
              className="w-9 h-9 rounded-full border border-slate-200 dark:border-slate-800 object-cover"
            />
            <div className="flex-1 min-w-0">
              <span className="text-xs font-semibold text-slate-800 dark:text-white block truncate">{currentUser.name}</span>
              <span className="text-[10px] text-slate-400 dark:text-slate-500 block truncate">{currentUser.email}</span>
            </div>
          </div>

          <button
            onClick={onLogout}
            className="w-full py-1.5 text-xs text-slate-500 dark:text-slate-400 hover:text-rose-500 dark:hover:text-rose-450 hover:bg-rose-500/10 dark:hover:bg-rose-500/15 flex items-center justify-center gap-2 rounded-lg border border-slate-200/60 dark:border-slate-800 transition-all cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Thoát hệ thống</span>
          </button>
        </div>
      </aside>

      {/* MOBILE STICKY BOTTOM NAVIGATION BAR - Bottom of Mobile Screens */}
      <nav className="lg:hidden fixed bottom-1.5 left-1.5 right-1.5 glass-card backdrop-blur-xl border border-slate-200/50 dark:border-white/10 text-slate-500 dark:text-slate-400 flex justify-around items-center h-16 py-1 rounded-2xl shadow-2xl z-40 select-none font-sans mobile-nav-panel">
        
        <button
          onClick={() => setCurrentTab('dashboard')}
          className={`flex flex-col items-center justify-center flex-1 h-full py-1 transition-all ${
            currentTab === 'dashboard' ? 'text-blue-600 dark:text-blue-400 font-semibold' : 'hover:text-slate-800 dark:hover:text-slate-100'
          }`}
        >
          <div className="relative">
            <LayoutDashboard className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1.5 w-3.5 h-3.5 bg-red-500 text-white rounded-full text-[8px] flex items-center justify-center font-mono">
                {unreadCount}
              </span>
            )}
          </div>
          <span className="text-[9px] mt-0.5">Bàn việc</span>
        </button>

        <button
          onClick={() => setCurrentTab('tasks')}
          className={`flex flex-col items-center justify-center flex-1 h-full py-1 transition-all ${
            currentTab === 'tasks' ? 'text-blue-600 dark:text-blue-400 font-semibold' : 'hover:text-slate-800 dark:hover:text-slate-100'
          }`}
        >
          <CheckSquare className="w-5 h-5" />
          <span className="text-[9px] mt-0.5">Công việc</span>
        </button>

        <button
          onClick={() => setCurrentTab('excel-import')}
          className={`flex flex-col items-center justify-center flex-1 h-full py-1 transition-all ${
            currentTab === 'excel-import' ? 'text-blue-600 dark:text-blue-400 font-semibold' : 'hover:text-slate-800 dark:hover:text-slate-100'
          }`}
        >
          <FileSpreadsheet className="w-5 h-5 text-emerald-500" />
          <span className="text-[9px] mt-0.5 font-medium">AI Nhập</span>
        </button>

        <button
          onClick={() => setCurrentTab('assistant')}
          className={`flex flex-col items-center justify-center flex-1 h-full py-1 transition-all ${
            currentTab === 'assistant' ? 'text-blue-600 dark:text-blue-400 font-semibold glow-animation' : 'hover:text-slate-800 dark:hover:text-slate-100'
          }`}
        >
          <MessageSquareCode className="w-5 h-5 text-blue-550 dark:text-blue-400" />
          <span className="text-[9px] mt-0.5">Trợ lý AI</span>
        </button>

        <button
          onClick={() => setCurrentTab('settings')}
          className={`flex flex-col items-center justify-center flex-1 h-full py-1 transition-all ${
            currentTab === 'settings' ? 'text-blue-600 dark:text-blue-400 font-semibold' : 'hover:text-slate-800 dark:hover:text-slate-100'
          }`}
        >
          <Settings className="w-5 h-5" />
          <span className="text-[9px] mt-0.5">Mở rộng</span>
        </button>
      </nav>
    </>
  );
}
