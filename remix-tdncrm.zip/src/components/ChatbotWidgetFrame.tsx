import React, { useState, useEffect, useRef } from 'react';
import { Send, Phone, User, AlertCircle, X, MessageSquare } from 'lucide-react';

export default function ChatbotWidgetFrame() {
  const [config, setConfig] = useState<any>({
    botName: 'Duyên AI Chăm Sóc Tự Động',
    greeting: 'Xin chào! Em là trợ lý ảo Duyên của doanh nghiệp Tín Dân. Em có thể tư vấn gì về kỹ thuật in decal tem cuộn cho quý khách ạ?',
    primaryColor: '#2563eb',
    avatar: '👩‍💼',
    hotlineEnabled: true,
    hotline: '0903810082',
    hotlineBtnText: 'Bấm Gọi Hotline Tín Dân',
    systemPrompt: '',
    knowledgeBase: ''
  });

  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<any[]>([]);
  const [userInput, setUserInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [leadFormOpen, setLeadFormOpen] = useState(false);

  // Lead fields
  const [leadName, setLeadName] = useState('');
  const [leadPhone, setLeadPhone] = useState('');
  const [leadDemand, setLeadDemand] = useState('');
  const [leadSubmitted, setLeadSubmitted] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Parse parent URL or default path name
  const [parentPage, setParentPage] = useState('Trang chủ Tín Dân');

  useEffect(() => {
    // Determine context page from URL search parameters if available
    const params = new URLSearchParams(window.location.search);
    const pageParam = params.get('page');
    if (pageParam) {
      setParentPage(decodeURIComponent(pageParam));
    }

    // Fetch active live chatbot configuration from backend server directly
    const fetchConfig = async () => {
      try {
        const res = await fetch('/api/chatbot/config');
        if (res.ok) {
          const data = await res.json();
          if (data && data.success && data.config) {
            setConfig(data.config);
          }
        }
      } catch (err) {
        console.warn("Failed to retrieve live chatbot config, using defaults:", err);
      }
    };
    fetchConfig();
  }, []);

  // Sync initial message
  useEffect(() => {
    if (config.greeting) {
      setMessages([
        { sender: 'bot', text: config.greeting, time: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) }
      ]);
    }
  }, [config.greeting]);

  // Scroll to bottom on updates
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Expand / collapse IPC communication to parent window
  const toggleWidget = (forceState?: boolean) => {
    const nextState = forceState !== undefined ? forceState : !isOpen;
    setIsOpen(nextState);
    if (window.parent) {
      window.parent.postMessage({
        type: 'tindan_chatbot_resize',
        collapsed: !nextState
      }, '*');
    }
  };

  // Auto-trigger widget expand after brief delay for real customer engagement
  useEffect(() => {
    const timer = setTimeout(() => {
      toggleWidget(true);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim()) return;

    const userText = userInput;
    const userMsg = {
      sender: 'user',
      text: userText,
      time: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })
    };
    setMessages(prev => [...prev, userMsg]);
    setUserInput('');
    setIsTyping(true);

    // Gạ lấy SĐT triggers
    const triggerWords = ['sdt', 'gọi', 'điện thoại', 'báo giá', 'liên hệ', 'gia', 'giá', 'in decal', 'vivian'];
    const matchesTrigger = triggerWords.some(word => userText.toLowerCase().includes(word));
    
    if (matchesTrigger) {
      setTimeout(() => {
        setLeadFormOpen(true);
      }, 1000);
    }

    try {
      const res = await fetch('/api/chatbot/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userText,
          page: parentPage,
          config: config
        })
      });

      const data = await res.json();
      setIsTyping(false);
      
      setMessages(prev => [...prev, {
        sender: 'bot',
        text: data.reply || `Cảm ơn anh/chị đã quan tâm giải pháp in decal. Quý khách vui lòng đi lại thông tin số điện thoại để chuyên viên Tín Dân hỗ trợ tận tâm nhé!`,
        time: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })
      }]);
    } catch (err) {
      setIsTyping(false);
      setMessages(prev => [...prev, {
        sender: 'bot',
        text: `Dạ, em Duyên đã ghi nhận câu hỏi của sếp tại trang "${parentPage}". Vui lòng dán sđt vào khung phía trên hoặc gọi hotline ${config.hotline} để nhận phác thảo decal mẫu ngay ạ!`,
        time: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })
      }]);
      setLeadFormOpen(true);
    }
  };

  const handleLeadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!leadName || !leadPhone) return;

    try {
      const res = await fetch('/api/chatbot/submit-lead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: leadName,
          phone: leadPhone,
          demand: leadDemand || `Khách hàng gạ hỏi tại trang nhúng: ${parentPage}`,
          referrerPage: parentPage
        })
      });

      if (res.ok) {
        setLeadSubmitted(true);
        setLeadFormOpen(false);
        setMessages(prev => [...prev, {
          sender: 'bot',
          text: `🎉 Tuyệt vời! Em đã tiếp nhận thông tin của anh/chị ${leadName} (SĐT: ${leadPhone}). Bộ phận kinh doanh và tư vấn UV của Tín Dân sẽ bấm số gọi giải đáp trực tiếp cho anh/chị trong vòng 3-5 phút nữa!`,
          time: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })
        }]);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // If collapsed, render the gorgeous floating launch circle
  if (!isOpen) {
    return (
      <div 
        onClick={() => toggleWidget(true)}
        className="fixed bottom-3 right-3 w-14 h-14 rounded-full flex items-center justify-center cursor-pointer transition-all hover:scale-110 active:scale-95 shadow-xl select-none z-50 animate-bounce"
        style={{ backgroundColor: config.primaryColor }}
      >
        <span className="text-2xl">{config.avatar}</span>
        <span className="absolute -top-1 -right-1 bg-red-500 text-white font-bold text-[9px] px-1.5 py-0.5 rounded-full animate-pulse border border-white">
          1
        </span>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 flex flex-col bg-white dark:bg-slate-900 shadow-2xl overflow-hidden font-sans border border-slate-200/50 dark:border-white/5 md:rounded-3xl">
      
      {/* Widget Header */}
      <div 
        className="p-4 flex justify-between items-center text-white relative shrink-0"
        style={{ backgroundColor: config.primaryColor }}
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center text-xl shadow relative">
            {config.avatar}
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-white" />
          </div>
          <div>
            <h3 className="font-bold text-xs leading-none">{config.botName}</h3>
            <span className="text-[9.5px] opacity-75 mt-0.5 block">Hỗ trợ in Decal & UV hỏa tốc</span>
          </div>
        </div>

        <button 
          onClick={() => toggleWidget(false)}
          className="p-1 hover:bg-white/10 rounded-lg text-white transition-colors cursor-pointer"
        >
          <X className="w-4.5 h-4.5" />
        </button>
      </div>

      {/* Visitor views content scroll */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50/50 dark:bg-slate-950/20 relative">
        
        {messages.map((m, index) => {
          const isBot = m.sender === 'bot';
          return (
            <div key={index} className={`flex gap-2.5 max-w-[85%] ${isBot ? '' : 'ml-auto flex-row-reverse'}`}>
              <div className="w-6.5 h-6.5 rounded-full bg-white flex items-center justify-center text-xs border shrink-0 shadow-sm">
                {isBot ? config.avatar : '🙋'}
              </div>
              <div className={`p-3 rounded-2xl text-[11px] leading-relaxed relative ${isBot ? 'bg-white dark:bg-slate-800 text-slate-850 dark:text-neutral-200 shadow-sm border border-slate-100 dark:border-white/5' : 'bg-blue-600 text-white'}`}>
                <p className="whitespace-pre-wrap">{m.text}</p>
                <span className="text-[7.5px] opacity-40 mt-1 block text-right font-mono">{m.time}</span>
              </div>
            </div>
          );
        })}

        {isTyping && (
          <div className="flex gap-2 max-w-[80%]">
            <div className="w-6.5 h-6.5 rounded-full bg-white flex items-center justify-center border font-mono">
              {config.avatar}
            </div>
            <div className="p-2.5 bg-white dark:bg-slate-850 border dark:border-white/5 rounded-2xl flex items-center gap-1 shadow-sm">
              <div className="w-1 h-1 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
              <div className="w-1 h-1 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
              <div className="w-1 h-1 bg-slate-400 rounded-full animate-bounce" />
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />

        {/* Dynamic sliding Lead Capture Form */}
        {leadFormOpen && (
          <div className="p-4 bg-white dark:bg-slate-900 border-2 border-indigo-505/20 dark:border-indigo-500/20 rounded-2xl shadow-xl space-y-3 mx-1 animate-fade-in my-2">
            <h4 className="font-extrabold text-[11px] text-blue-600 uppercase tracking-wide flex items-center gap-1">
              <span className="animate-pulse">🎁</span>
              <span>ĐĂNG KÝ BÁO GIÁ ĐỘC QUYỀN TÍN DÂN</span>
            </h4>
            <p className="text-[9.5px] text-slate-450 leading-relaxed">
              Nhập ngay số điện thoại, sếp sẽ nhận ngay voucher thiết kế khuôn dập decal bảo ôn & dán mác UV miễn phí!
            </p>

            <form onSubmit={handleLeadSubmit} className="space-y-2.5">
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  required
                  placeholder="Họ tên của sếp"
                  value={leadName}
                  onChange={(e) => setLeadName(e.target.value)}
                  className="w-full text-[10.5px] p-2 bg-slate-50 border dark:border-white/5 rounded-xl focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
                <input
                  type="text"
                  required
                  placeholder="Số điện thoại"
                  value={leadPhone}
                  onChange={(e) => setLeadPhone(e.target.value)}
                  className="w-full text-[10.5px] p-2 bg-slate-50 border dark:border-white/5 rounded-xl font-mono focus:outline-none focus:ring-1 focus:ring-blue-500 font-bold"
                />
              </div>
              <input
                type="text"
                placeholder="Nhu cầu in ấn nhãn dán..."
                value={leadDemand}
                onChange={(e) => setLeadDemand(e.target.value)}
                className="w-full text-[10.5px] p-2 bg-slate-50 border dark:border-white/5 rounded-xl focus:outline-none"
              />

              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-[10.5px]"
                >
                  Gửi Nhận Ưu Đãi
                </button>
                <button
                  type="button"
                  onClick={() => setLeadFormOpen(false)}
                  className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-500 rounded-xl text-[10.5px]"
                >
                  Hủy
                </button>
              </div>
            </form>
          </div>
        )}

      </div>

      {/* Floating Action Call Buttons */}
      {config.hotlineEnabled && (
        <a 
          href={`tel:${config.hotline}`}
          className="mx-4 mb-2 p-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl flex items-center justify-center gap-1.5 font-bold text-[10px] uppercase shadow-lg shadow-emerald-600/10 transition-all active:scale-95 cursor-pointer"
        >
          <Phone className="w-3.5 h-3.5" />
          <span>{config.hotlineBtnText} • {config.hotline}</span>
        </a>
      )}

      {/* Message Chat submit input */}
      <form onSubmit={handleSendMessage} className="p-3 bg-white dark:bg-slate-900 border-t border-slate-150/40 dark:border-white/5 flex gap-2 shrink-0">
        <input
          type="text"
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          placeholder="Mời sếp hỏi về decal mác cuộn..."
          className="flex-grow text-[11px] px-3.5 py-2 bg-slate-100 dark:bg-slate-800 border-none rounded-xl focus:outline-none"
        />
        <button
          type="submit"
          disabled={!userInput.trim()}
          className="p-2.5 bg-blue-600 disabled:bg-slate-200 text-white rounded-xl flex items-center justify-center hover:bg-blue-750 transition-colors shadowCursor cursor-pointer"
          style={{ backgroundColor: userInput.trim() ? config.primaryColor : undefined }}
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>

    </div>
  );
}
