/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { User, Task, TaskPriority, TaskStatus, Department, TaskComment, UserRole, Project, ChecklistItem } from '../types';
import { DB } from '../lib/dataStore';
import { 
  Plus, 
  Search, 
  SlidersHorizontal, 
  Kanban,  
  List as ListIcon, 
  Calendar as CalendarIcon, 
  AlertCircle, 
  PlusCircle, 
  CheckSquare, 
  Square,
  MessageSquare, 
  User as UserIcon, 
  ChevronsUpDown, 
  CheckCircle2, 
  Sparkles, 
  Clock, 
  Smile, 
  CornerDownRight, 
  Trash2,
  Paperclip,
  UserPlus
} from 'lucide-react';

interface TasksProps {
  currentUser: User;
  tasks: Task[];
  setTasks: (tasks: Task[]) => void;
  projects: Project[];
  comments: TaskComment[];
  setComments: (comments: TaskComment[]) => void;
}

export default function Tasks({ currentUser, tasks, setTasks, projects, comments, setComments }: TasksProps) {
  // Navigation tabs of Tasks module
  const [viewMode, setViewMode] = useState<'kanban' | 'list' | 'calendar'>('kanban');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDeptFilter, setSelectedDeptFilter] = useState<string>('All');
  const [selectedPriorityFilter, setSelectedPriorityFilter] = useState<string>('All');

  // Detail Modal popup configs
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  
  // Create task popup configs
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newAssignee, setNewAssignee] = useState('');
  const [newDept, setNewDept] = useState<Department>(currentUser.department || Department.MARKETING);
  const [newPriority, setNewPriority] = useState<TaskPriority>(TaskPriority.MEDIUM);
  const [newDeadline, setNewDeadline] = useState(new Date().toISOString().split('T')[0]);
  const [newKpi, setNewKpi] = useState<number>(10);
  const [newChecklistText, setNewChecklistText] = useState('');
  const [newProjectId, setNewProjectId] = useState<string>(projects[0]?.id || '');
  const [actualResultInput, setActualResultInput] = useState('');

  // Comment local states
  const [commentInput, setCommentInput] = useState('');
  
  // AI splitting loader
  const [isAiSplitting, setIsAiSplitting] = useState(false);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [filteredAssignees, setFilteredAssignees] = useState<User[]>([]);
  const [newFollowers, setNewFollowers] = useState<string[]>([]);

  useEffect(() => {
    loadUsers();
  }, []);

  useEffect(() => {
    if (newDept) {
      // Include all users in department, but also ALWAYS include currentUser if not already in there
      // so they can self-assign easily regardless of department filters if we wanted, 
      // but sticking to department filter is more organized.
      const filtered = allUsers.filter(u => u.department === newDept);
      
      // If current user is not in the filtered list but we want them to be able to self-assign:
      if (newDept === currentUser.department && !filtered.find(u => u.id === currentUser.id)) {
        filtered.push(currentUser);
      }
      
      setFilteredAssignees(filtered);
      // Auto select first user from department if existing assignee is empty
      if (filtered.length > 0 && !newAssignee) {
        setNewAssignee(filtered[0].name);
      }
    }
  }, [newDept, allUsers, currentUser]);

  const loadUsers = async () => {
    const data = await DB.getUsers();
    setAllUsers(data);
  };

  const depts = Object.values(Department);
  const priorities = Object.values(TaskPriority);
  const statuses = Object.values(TaskStatus);

  const filteredTasks = tasks.filter(t => {
    // 1. Role-based visibility
    if (currentUser.role === UserRole.EMPLOYEE) {
      // Employee only sees tasks assigned to them, created by them, or where they are a follower
      const isAssigned = t.assignee === currentUser.name || t.assigneeId === currentUser.id;
      const isCreatedBy = t.createdBy === currentUser.id;
      const isFollower = t.followers?.includes(currentUser.name);
      if (!isAssigned && !isCreatedBy && !isFollower) return false;
    } 
    
    // Manage/Admin might see full department context
    if (currentUser.role === UserRole.MANAGER) {
      if (t.department !== currentUser.department) return false;
    }

    // 2. Search & UI Filters
    if (selectedDeptFilter !== 'All' && t.department !== selectedDeptFilter) return false;
    if (selectedPriorityFilter !== 'All' && t.priority !== selectedPriorityFilter) return false;

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        t.title.toLowerCase().includes(q) || 
        t.description.toLowerCase().includes(q) || 
        t.assignee.toLowerCase().includes(q) ||
        (t.projectName && t.projectName.toLowerCase().includes(q))
      );
    }

    return true;
  });

  const handleAiChecklistSuggest = async () => {
    if (!newTitle) return;
    setIsAiSplitting(true);
    try {
      const res = await fetch('/api/ai/suggest-checklist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newTitle,
          department: newDept || currentUser.department
        })
      });
      const data = await res.json();
      if (data.success && data.checklist) {
        setNewChecklistText(data.checklist);
      }
    } catch (err) {
      console.error("AI suggest error", err);
    } finally {
      setIsAiSplitting(false);
    }
  };

  const handleSplitWithAI = async () => {
    if (!newTitle) return;
    setIsAiSplitting(true);
    
    try {
      const res = await fetch('/api/ai/split-task', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: newTitle })
      });
      const data = await res.json();
      if (data.success && data.data) {
        setNewDesc(data.data.description);
        setNewChecklistText(data.data.checklist.join('\n'));
        setNewKpi(data.data.kpiScore);
      }
    } catch (err) {
      console.error("AI split error", err);
    } finally {
      setIsAiSplitting(false);
    }
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle) return;

    // Split checklist items
    const checkArray = newChecklistText
      .split('\n')
      .filter(line => line.trim().length > 0)
      .map((line, i) => ({
        id: 'new_cli_' + Date.now() + '_' + i,
        title: line.trim(),
        done: false
      }));

    const selectedProject = projects.find(p => p.id === newProjectId);

    const freshTask: Task = {
      id: 'task_' + Date.now(),
      projectId: newProjectId,
      projectName: selectedProject?.name || 'Dự án',
      title: newTitle,
      description: newDesc,
      checklist: checkArray,
      deadline: newDeadline,
      assignee: newAssignee || currentUser.name,
      department: newDept,
      priority: newPriority,
      status: TaskStatus.PENDING,
      followers: newFollowers,
      attachments: [],
      commentsCount: 0,
      kpiScore: newKpi,
      planMonth: 'June',
      planWeek: 'Week 2',
      createdAt: new Date().toISOString(),
      createdBy: currentUser.id
    };

    const updated = [freshTask, ...tasks];
    setTasks(updated);
    DB.saveTasks(updated);
    
    // Clear form and modal
    setShowCreateModal(false);
    setNewTitle('');
    setNewDesc('');
    setNewAssignee('');
    setNewFollowers([]);
    setNewChecklistText('');
  };

  const handleUpdateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTask) return;

    const updated = tasks.map(t => {
      if (t.id === editingTask.id) {
        return editingTask;
      }
      return t;
    });

    setTasks(updated);
    DB.saveTasks(updated);
    if (selectedTask?.id === editingTask.id) {
      setSelectedTask(editingTask);
    }
    setEditingTask(null);
  };

  const handleDeleteTask = async (taskId: string) => {
    if (window.confirm('Sếp có chắc chắn muốn xóa tác vụ này không? Việc này không thể phục hồi.')) {
      const updated = tasks.filter(t => t.id !== taskId);
      setTasks(updated);
      await DB.deleteTask(taskId);
      setSelectedTask(null);
    }
  };

  const handleUpdateStatus = (taskId: string, nextStatus: TaskStatus) => {
    const updated = tasks.map(t => {
      if (t.id === taskId) {
        return { ...t, status: nextStatus };
      }
      return t;
    });
    setTasks(updated);
    DB.saveTasks(updated);
    if (selectedTask?.id === taskId) {
      setSelectedTask({ ...selectedTask, status: nextStatus });
      // Reset actual result if moving back from done
      if (nextStatus !== TaskStatus.DONE) {
        setActualResultInput('');
      } else if (selectedTask.actualResult) {
        setActualResultInput(selectedTask.actualResult);
      }
    }
  };

  const handleSaveActualResult = () => {
    if (!selectedTask || !actualResultInput.trim()) return;
    const updated = tasks.map(t => {
      if (t.id === selectedTask.id) {
        return { ...t, actualResult: actualResultInput };
      }
      return t;
    });
    setTasks(updated);
    DB.saveTasks(updated);
    setSelectedTask({ ...selectedTask, actualResult: actualResultInput });
  };

  const handleToggleChecklistItem = (taskId: string, itemId: string) => {
    const updated = tasks.map(t => {
      if (t.id === taskId) {
        const itemUpdated = t.checklist.map(item => {
          if (item.id === itemId) return { ...item, done: !item.done };
          return item;
        });
        return { ...t, checklist: itemUpdated };
      }
      return t;
    });
    setTasks(updated);
    DB.saveTasks(updated);
    
    // Update selected visual overlay
    if (selectedTask?.id === taskId) {
      setSelectedTask({
        ...selectedTask,
        checklist: selectedTask.checklist.map(item => {
          if (item.id === itemId) return { ...item, done: !item.done };
          return item;
        })
      });
    }
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTask || !commentInput.trim()) return;

    const newComment: TaskComment = {
      id: 'c_' + Date.now(),
      taskId: selectedTask.id,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      content: commentInput,
      createdAt: new Date().toISOString()
    };

    const updatedComments = [...comments, newComment];
    setComments(updatedComments);
    DB.saveComments(updatedComments);

    // Sync task counters
    const updatedTasks = tasks.map(t => {
      if (t.id === selectedTask.id) {
        return { ...t, commentsCount: (t.commentsCount || 0) + 1 };
      }
      return t;
    });
    setTasks(updatedTasks);
    DB.saveTasks(updatedTasks);

    setCommentInput('');
  };

  // Pre-calculate categories for calendar view
  const daysInMonth = Array.from({ length: 15 }, (_, i) => `2026-06-${String(i + 1).padStart(2, '0')}`);

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-4 md:p-6 lg:p-8 font-sans transition-colors duration-300">
      
      {/* Title & Toolbar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white font-display">
            Hồ sơ Nhiệm vụ
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Phân loại theo Kanban, bảng danh sách trực quan & AI hỗ trợ bóc tách lỗi vận hành.
          </p>
        </div>

        {/* Top Actions combo */}
        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <button
            onClick={() => setShowCreateModal(true)}
            className="flex-1 sm:flex-none py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-all outline-none"
          >
            <Plus className="w-4 h-4" />
            <span>Tạo Nhiệm Vụ Mới</span>
          </button>

          <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700">
            <button
              onClick={() => setViewMode('kanban')}
              className={`p-1.5 rounded ${viewMode === 'kanban' ? 'bg-white dark:bg-slate-700 text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
              title="Cột Kanban"
            >
              <Kanban className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded ${viewMode === 'list' ? 'bg-white dark:bg-slate-700 text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
              title="Danh sác dòng"
            >
              <ListIcon className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('calendar')}
              className={`p-1.5 rounded ${viewMode === 'calendar' ? 'bg-white dark:bg-slate-700 text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
              title="Lịch biểu"
            >
              <CalendarIcon className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Filter and search bar */}
      <div className="glass-card p-4 rounded-xl shadow-sm space-y-3 sm:space-y-0 sm:flex items-center justify-between gap-4">
        
        {/* Search input field */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Tìm kiếm công việc, người làm..."
            className="w-full glass-input rounded-lg text-xs py-2 pl-9 pr-4 focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800 dark:text-white"
          />
        </div>

        {/* dropdown filters inline */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1">
            <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide">Bộ lọc:</span>
          </div>

          <select
            value={selectedDeptFilter}
            onChange={(e) => setSelectedDeptFilter(e.target.value)}
            className="glass-dropdown text-xs px-2.5 py-1.5 rounded-lg text-slate-700 dark:text-slate-300 focus:outline-none"
          >
            <option value="All">Phòng Ban (Tất cả)</option>
            {depts.map(d => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>

          <select
            value={selectedPriorityFilter}
            onChange={(e) => setSelectedPriorityFilter(e.target.value)}
            className="glass-dropdown text-xs px-2.5 py-1.5 rounded-lg text-slate-700 dark:text-slate-300 focus:outline-none"
          >
            <option value="All">Độ ưu tiên (Tất cả)</option>
            {priorities.map(p => (
              <option key={p} value={p}>{p === 'High' ? 'Khẩn cấp' : p === 'Medium' ? 'Trung bình' : 'Mức thấp'}</option>
            ))}
          </select>
        </div>

      </div>

      {/* ==========================================
          KANBAN VIEW LAYOUT
          ========================================== */}
      {viewMode === 'kanban' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {statuses.map((status) => {
            const columnTasks = filteredTasks.filter(t => t.status === status);
            return (
              <div
                key={status}
                className="glass-card rounded-2xl p-4 flex flex-col min-h-[480px]"
              >
                {/* Column header title */}
                <div className="flex items-center justify-between pb-3.5 border-b border-slate-200 dark:border-slate-800 mb-4">
                  <div className="flex items-center gap-2">
                    <span className={`w-3 h-3 rounded-full ${
                      status === 'Pending' ? 'bg-yellow-400' : status === 'In Progress' ? 'bg-blue-500' : 'bg-emerald-500'
                    }`} />
                    <span className="text-xs font-bold font-display text-slate-800 dark:text-slate-200 tracking-tight uppercase">
                      {status === 'Pending' ? 'ĐỊNH HÌNH' : status === 'In Progress' ? 'ĐANG CHẠY' : 'ĐÃ HOÀN THÀNH'}
                    </span>
                    <span className="text-[10px] bg-slate-200 dark:bg-slate-800 text-slate-500 dark:text-slate-400 px-1.5 rounded-full font-bold">
                      {columnTasks.length}
                    </span>
                  </div>
                </div>

                {/* Task card list stack */}
                <div className="flex-1 space-y-3 overflow-y-auto pr-1">
                  {columnTasks.length === 0 ? (
                    <div className="py-12 text-center text-slate-400 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
                      <span className="text-xs font-light">Không có nhiệm vụ</span>
                    </div>
                  ) : (
                    columnTasks.map((task) => {
                      const progress = task.status === TaskStatus.DONE
                        ? 100
                        : (task.checklist && task.checklist.length > 0 
                            ? Math.round((task.checklist.filter(c => c.done).length / task.checklist.length) * 100)
                            : 0);
                        
                      return (
                        <div
                          key={task.id}
                          onClick={() => setSelectedTask(task)}
                          className={`glass-card-hover shadow-sm p-4 rounded-xl cursor-pointer hover:border-blue-500 dark:hover:border-blue-700 transition-all space-y-3 ${
                            task.status === TaskStatus.DONE ? 'opacity-75 grayscale-[0.3]' : ''
                          }`}
                        >
                          <div className="flex justify-between items-start">
                            <span className="text-[9px] px-2 py-0.5 bg-blue-50 dark:bg-blue-900/40 text-blue-600 dark:text-blue-300 rounded font-medium font-mono uppercase">
                              {task.projectName || 'Dự án'}
                            </span>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setEditingTask(task);
                                }}
                                className="p-1 hover:text-blue-500 text-slate-400 transition-colors"
                              >
                                <PlusCircle className="w-3.5 h-3.5 rotate-45" title="Sửa" />
                              </button>
                              <span className={`text-[9px] font-semibold px-2 py-0.5 rounded ${
                                task.priority === 'High' 
                                  ? 'bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-300'
                                  : 'bg-slate-100 text-slate-700 dark:bg-slate-750'
                              }`}>
                                {task.priority === 'High' ? 'Khẩn' : 'Thường'}
                              </span>
                            </div>
                          </div>

                          <div>
                            <h4 className="text-xs font-bold text-slate-800 dark:text-white line-clamp-2">{task.title}</h4>
                            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 font-light">{task.description}</p>
                          </div>

                          {/* Checklist items progress counter */}
                          <div className="space-y-1.5">
                            <div className="flex justify-between items-center text-[9px] text-slate-400 font-bold uppercase tracking-tighter">
                              <span>Tiến độ</span>
                              <span>{progress}%</span>
                            </div>
                            <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-900 rounded-full overflow-hidden">
                              <div 
                                className={`h-full transition-all duration-500 ${
                                  progress === 100 ? 'bg-emerald-500' : 'bg-blue-500'
                                }`} 
                                style={{ width: `${progress}%` }} 
                              />
                            </div>
                          </div>

                          {/* Footer statistics slots */}
                          <div className="flex justify-between items-center pt-2.5 border-t border-slate-100 dark:border-slate-700/80">
                            <div className="flex items-center gap-2">
                              <div className="w-5 h-5 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center font-display text-[9px] font-bold text-slate-600 dark:text-slate-300">
                                {task.assignee.charAt(0)}
                              </div>
                              <span className="text-[10px] text-slate-600 dark:text-slate-400 truncate max-w-[80px]">{task.assignee}</span>
                            </div>

                            <div className="flex items-center gap-2 text-slate-400 font-mono text-[10px]">
                              {task.followers && task.followers.length > 0 && (
                                <UserPlus className="w-3 h-3 text-blue-500" title={`+${task.followers.length} người liên quan`} />
                              )}
                              <span className="flex items-center gap-0.5 font-bold font-display text-blue-600">
                                +{task.kpiScore}đ
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ==========================================
          LIST VIEW LAYOUT
          ========================================== */}
      {viewMode === 'list' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider border-b border-slate-150 dark:border-slate-800">
                  <th className="p-4">Tên Công việc</th>
                  <th className="p-4">Phòng ban</th>
                  <th className="p-4">Người nhận</th>
                  <th className="p-4">Hạn chót</th>
                  <th className="p-4">Độ ưu tiên</th>
                  <th className="p-4">Tiến độ</th>
                  <th className="p-4">Điểm KPI</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-150 dark:divide-slate-800">
                {filteredTasks.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-400">Không tìm thấy công việc phù hợp bộ lọc.</td>
                  </tr>
                ) : (
                  filteredTasks.map((task) => (
                    <tr
                      key={task.id}
                      onClick={() => setSelectedTask(task)}
                      className="hover:bg-slate-50 dark:hover:bg-slate-800/40 cursor-pointer text-slate-700 dark:text-slate-300"
                    >
                      <td className="p-4">
                        <div className="font-semibold text-slate-900 dark:text-white max-w-sm truncate">{task.title}</div>
                        <span className="text-[10px] text-slate-400 block mt-0.5">{task.projectName}</span>
                      </td>
                      <td className="p-4">{task.department}</td>
                      <td className="p-4 flex items-center gap-1.5 mt-2.5">
                        <div className="w-4 h-4 rounded-full bg-slate-150 dark:bg-slate-700 text-[8px] flex items-center justify-center font-bold">
                          {task.assignee.charAt(0)}
                        </div>
                        <span className="truncate">{task.assignee}</span>
                      </td>
                      <td className="p-4 font-mono font-semibold">{task.deadline}</td>
                      <td className="p-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-medium ${
                          task.priority === 'High' ? 'bg-red-100 text-red-700 dark:bg-red-950/30' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {task.priority === 'High' ? 'Khẩn' : 'Bình thường'}
                        </span>
                      </td>
                      <td className="p-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          task.status === 'Done' ? 'bg-emerald-100 text-emerald-700' : 'bg-yellow-100 text-yellow-700'
                        }`}>
                          {task.status === 'Done' ? 'Đã XONG' : 'Đang làm'}
                        </span>
                      </td>
                      <td className="p-4 text-blue-600 font-bold font-mono">+{task.kpiScore}đ</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==========================================
          CALENDAR DATE LIST VIEW LAYOUT
          ========================================== */}
      {viewMode === 'calendar' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <h2 className="text-sm font-bold font-display text-slate-800 dark:text-white uppercase tracking-wider">Lịch Biểu Phân PHối Theo Ngày (Tháng 06/2026)</h2>
          <div className="space-y-3">
            {daysInMonth.map((day) => {
              const dayTasks = filteredTasks.filter(t => t.deadline === day);
              if (dayTasks.length === 0) return null; // Only show active days with tasks
              return (
                <div key={day} className="flex gap-4 p-3 border-l-4 border-blue-500 bg-slate-50 dark:bg-slate-800/45 rounded-r-xl">
                  <div className="w-24 shrink-0">
                    <span className="text-xs font-bold text-slate-800 dark:text-white block font-mono">{day}</span>
                    <span className="text-[10px] text-slate-400 font-medium">Lô tem sản xuất</span>
                  </div>
                  <div className="flex-1 space-y-2">
                    {dayTasks.map(task => (
                      <div
                        key={task.id}
                        onClick={() => setSelectedTask(task)}
                        className="p-2 border border-slate-250 dark:border-slate-700/80 bg-white dark:bg-slate-800 hover:border-blue-500 cursor-pointer rounded-lg text-xs"
                      >
                        <div className="font-semibold text-slate-800 dark:text-white">{task.title}</div>
                        <span className="text-[10px] text-slate-400 mt-1 block">Người làm: {task.assignee} | Phòng: {task.department}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ==========================================
          TASK DETAILED VIEW DIALOG OVERLAY
          ========================================== */}
      {selectedTask && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-850 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden block">
            
            {/* Header banner */}
            <div className="bg-slate-50 dark:bg-slate-800 p-5 border-b border-slate-150 dark:border-slate-800 flex justify-between items-center">
              <div>
                <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest block font-mono">TASK: {selectedTask.id}</span>
                <h3 className="text-sm font-bold text-slate-800 dark:text-white font-display mt-1">{selectedTask.title}</h3>
              </div>
              <button
                onClick={() => setSelectedTask(null)}
                className="text-slate-400 hover:text-slate-700 p-1.5 focus:outline-none"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-6 max-h-[480px] overflow-y-auto">
              
              {/* Task descriptions and status togglers */}
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl text-xs">
                <div>
                  <span className="text-slate-400 block font-medium">Bộ phận</span>
                  <span className="font-bold text-slate-800 dark:text-white block mt-0.5">{selectedTask.department}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-medium">Người chịu trách nhiệm</span>
                  <span className="font-bold text-slate-800 dark:text-white block mt-0.5">{selectedTask.assignee}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-medium">Dự án</span>
                  <span className="font-bold text-emerald-600 block mt-0.5">{selectedTask.projectName || 'N/A'}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-medium">Ngày Tạo</span>
                  <span className="font-bold text-slate-800 dark:text-white block mt-0.5">
                    {selectedTask.createdAt ? new Date(selectedTask.createdAt).toLocaleDateString('vi-VN') : 'Sơ khai'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block font-medium">Hạn Chót</span>
                  <span className="font-bold text-blue-600 font-mono block mt-1">{selectedTask.deadline}</span>
                </div>
              </div>

              {/* Followers list display */}
              {selectedTask.followers && selectedTask.followers.length > 0 && (
                <div className="space-y-2">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Người liên quan</span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedTask.followers.map(f => (
                      <div key={f} className="flex items-center gap-1.5 px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded-full border border-slate-200 dark:border-slate-700">
                        <div className="w-4 h-4 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-[9px] font-bold text-blue-600">
                          {f.charAt(0)}
                        </div>
                        <span className="text-[10px] font-medium text-slate-600 dark:text-slate-400">{f}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Mandatory result for Lead/Nhóm tasks */}
              {(selectedTask.title.toLowerCase().includes('lead') || selectedTask.title.toLowerCase().includes('nhóm')) && (
                <div className="bg-amber-50 dark:bg-amber-950/20 p-4 rounded-xl border border-amber-200 dark:border-amber-900/50 space-y-3">
                  <div className="flex items-center gap-2 text-amber-700 dark:text-amber-400 font-bold">
                    <Sparkles className="w-4 h-4" />
                    <span className="uppercase tracking-wide text-[10px]">Kết quả thực tế (Bắt buộc cho Lead/Nhóm)</span>
                  </div>
                  <div className="flex gap-2">
                    <input 
                      type="text"
                      value={actualResultInput}
                      onChange={(e) => setActualResultInput(e.target.value)}
                      placeholder="Nhập kết quả đạt được: Vd: Chốt được 5 khách sỉ..."
                      className="flex-1 glass-input rounded-lg text-xs py-2 px-3 focus:ring-1 focus:ring-amber-500"
                    />
                    <button 
                      onClick={handleSaveActualResult}
                      disabled={!actualResultInput.trim()}
                      className="px-3 py-2 bg-amber-600 text-white rounded-lg text-xs font-bold hover:bg-amber-700 disabled:opacity-50"
                    >
                      Lưu KQ
                    </button>
                  </div>
                  {selectedTask.actualResult && (
                    <p className="text-[10px] text-emerald-600 font-medium">✓ Đã ghi nhận: {selectedTask.actualResult}</p>
                  )}
                </div>
              )}

              {/* Task deep description text */}
              <div className="space-y-1.5">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest block">Chi tiết công việc</span>
                <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-light">{selectedTask.description}</p>
              </div>

              {/* Checklist details status manager */}
              {selectedTask.checklist && selectedTask.checklist.length > 0 && (
                <div className="space-y-2.5">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest block">Checklist con cần làm ({selectedTask.checklist.filter(c => c.done).length}/{selectedTask.checklist.length})</span>
                  <div className="space-y-1.5">
                    {selectedTask.checklist.map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => handleToggleChecklistItem(selectedTask.id, item.id)}
                        className="w-full text-left flex items-center gap-2.5 p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-850/50 transition-all font-light text-xs"
                      >
                        {item.done ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-300 shrink-0" />
                        )}
                        <span className={item.done ? 'line-through text-slate-400' : 'text-slate-700 dark:text-slate-300'}>
                          {item.title}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Status workflow dispatcher buttons */}
              <div className="space-y-2.5">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest block">Cập Nhật Tiến Độ</span>
                <div className="flex gap-2">
                  {statuses.map((status) => (
                    <button
                      key={status}
                      type="button"
                      onClick={() => handleUpdateStatus(selectedTask.id, status)}
                      className={`flex-1 py-2 rounded-lg text-[10px] font-bold uppercase transition-all ${
                        selectedTask.status === status 
                          ? 'bg-blue-600 text-white font-semibold' 
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-600 border border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {status === 'Pending' ? 'Chưa chạy' : status === 'In Progress' ? 'Đang Chạy' : 'Đã HOÀN THÀNH'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Comments Section Area */}
              <div className="border-t border-slate-150 dark:border-slate-800 pt-5 space-y-4">
                <h4 className="text-xs font-bold font-display uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-blue-500" />
                  <span>Trao đổi nội bộ ({comments.filter(c => c.taskId === selectedTask.id).length})</span>
                </h4>

                {/* Listing of comments */}
                <div className="space-y-3.5 max-h-[180px] overflow-y-auto pr-1">
                  {comments.filter(c => c.taskId === selectedTask.id).length === 0 ? (
                    <p className="text-[11px] text-slate-400 italic">Chưa có bình luận thảo luận cho lô hàng UV này. Đặt câu hỏi bên dưới để trao đổi.</p>
                  ) : (
                    comments.filter(c => c.taskId === selectedTask.id).map(c => (
                      <div key={c.id} className="p-3 bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-700 rounded-xl space-y-1 text-xs">
                        <div className="flex justify-between items-center">
                          <span className="font-bold text-slate-850 dark:text-white font-display block">{c.userName} ({c.userRole})</span>
                          <span className="text-[9px] text-slate-400 block font-mono">
                            {new Date(c.createdAt).toLocaleDateString('vi-VN')} {new Date(c.createdAt).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-slate-600 dark:text-slate-300 font-light mt-1 text-[11px] leading-relaxed">{c.content}</p>
                      </div>
                    ))
                  )}
                </div>

                {/* Input block comment */}
                <form onSubmit={handleAddComment} className="flex gap-2">
                  <input
                    type="text"
                    value={commentInput}
                    onChange={(e) => setCommentInput(e.target.value)}
                    placeholder="Viết phản hồi mẫu hàng in..."
                    className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs py-2 px-3 focus:outline-none focus:ring-1 focus:ring-blue-500 text-slate-800 dark:text-white"
                  />
                  <button
                    type="submit"
                    className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-750 shrink-0"
                  >
                    Gửi
                  </button>
                </form>
              </div>

            </div>

            {/* Bottom Footer Admin Operations */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-150 dark:border-slate-800 font-sans flex justify-between">
              <div className="flex gap-2">
                {(currentUser.role === 'Super Admin' || currentUser.role === 'Admin') && (
                  <button
                    type="button"
                    onClick={() => handleDeleteTask(selectedTask.id)}
                    className="px-3 py-1.5 text-xs text-rose-500 hover:text-white hover:bg-rose-600 border border-slate-200 rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Xóa công việc</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setEditingTask(selectedTask);
                    setSelectedTask(null);
                  }}
                  className="px-3 py-1.5 text-xs text-blue-500 hover:text-white hover:bg-blue-600 border border-slate-200 rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Sửa nhanh</span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => setSelectedTask(null)}
                className="px-4 py-1.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg"
              >
                Đóng
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ==========================================
          EDIT TASK POPUP FORM MODAL
          ========================================== */}
      {editingTask && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto font-sans">
          <form onSubmit={handleUpdateTask} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden block">
            
            <div className="bg-slate-50 dark:bg-slate-850 p-5 border-b border-slate-150 dark:border-slate-800 flex justify-between items-center">
              <span className="font-bold text-sm text-slate-800 dark:text-white font-display uppercase tracking-tight">Cập nhật công việc</span>
              <button
                type="button"
                onClick={() => setEditingTask(null)}
                className="text-slate-400 hover:text-slate-700"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Tiêu đề công việc</label>
                <input
                  type="text"
                  required
                  value={editingTask.title}
                  onChange={(e) => setEditingTask({ ...editingTask, title: e.target.value })}
                  className="w-full glass-input rounded-xl text-xs py-2.5 px-4"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Mô tả chi tiết</label>
                <textarea
                  rows={3}
                  value={editingTask.description}
                  onChange={(e) => setEditingTask({ ...editingTask, description: e.target.value })}
                  className="w-full glass-input rounded-xl text-xs py-2.5 px-4"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Người phụ trách</label>
                  <select
                    value={editingTask.assignee}
                    onChange={(e) => setEditingTask({ ...editingTask, assignee: e.target.value })}
                    className="w-full glass-input rounded-xl text-xs py-2.5 px-4 outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    {allUsers.filter(u => u.department === editingTask.department).map(u => (
                      <option key={u.id} value={u.name}>{u.name}</option>
                    ))}
                    {allUsers.filter(u => u.department === editingTask.department).length === 0 && (
                      <option disabled>Phòng chưa có nhân sự</option>
                    )}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Hạn chót</label>
                  <input
                    type="date"
                    value={editingTask.deadline}
                    onChange={(e) => setEditingTask({ ...editingTask, deadline: e.target.value })}
                    className="w-full glass-input rounded-xl text-xs py-2.5 px-4"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Độ ưu tiên</label>
                  <select
                    value={editingTask.priority}
                    onChange={(e) => setEditingTask({ ...editingTask, priority: e.target.value as TaskPriority })}
                    className="w-full glass-dropdown rounded-xl text-xs py-2.5 px-4 border border-slate-200"
                  >
                    {priorities.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Điểm KPI (Chỉ Admin)</label>
                  <input
                    type="number"
                    value={editingTask.kpiScore}
                    disabled={currentUser.role !== UserRole.SUPER_ADMIN && currentUser.role !== UserRole.ADMIN}
                    onChange={(e) => setEditingTask({ ...editingTask, kpiScore: parseInt(e.target.value) || 0 })}
                    className={`w-full glass-input rounded-xl text-xs py-2.5 px-4 ${
                      currentUser.role !== UserRole.SUPER_ADMIN && currentUser.role !== UserRole.ADMIN ? 'opacity-60 cursor-not-allowed bg-slate-50' : 'text-blue-600 font-bold'
                    }`}
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Người liên quan (Followers)</label>
                <div className="flex flex-wrap gap-2 p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl min-h-[50px]">
                  {allUsers.map(u => (
                    <button
                      key={u.id}
                      type="button"
                      onClick={() => {
                        const current = editingTask.followers || [];
                        if (current.includes(u.name)) {
                          setEditingTask({ ...editingTask, followers: current.filter(f => f !== u.name) });
                        } else {
                          setEditingTask({ ...editingTask, followers: [...current, u.name] });
                        }
                      }}
                      className={`text-[10px] px-2.5 py-1 rounded-full transition-all ${
                        (editingTask.followers || []).includes(u.name)
                          ? 'bg-blue-600 text-white'
                          : 'bg-white dark:bg-slate-700 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-600'
                      }`}
                    >
                      {u.name}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Checklist (mỗi dòng một bước)</label>
                <textarea
                  rows={4}
                  value={(editingTask.checklist || []).map(i => i.title).join('\n')}
                  onChange={(e) => {
                    const lines = e.target.value.split('\n');
                    const updatedChecklist = lines.filter(l => l.trim()).map((l, i) => {
                      const existing = (editingTask.checklist || []).find(item => item.title === l.trim());
                      return {
                        id: existing?.id || `edit_cli_${Date.now()}_${i}`,
                        title: l.trim(),
                        done: existing?.done || false
                      };
                    });
                    setEditingTask({ ...editingTask, checklist: updatedChecklist });
                  }}
                  className="w-full glass-input rounded-xl text-xs py-2.5 px-4 font-mono"
                  placeholder="Bước 1: Kiểm tra máy&#10;Bước 2: In mẫu..."
                />
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setEditingTask(null)}
                  className="flex-1 py-3 border border-slate-200 dark:border-slate-700 text-slate-500 rounded-xl text-[10px] font-bold uppercase"
                >
                  Hủy bỏ
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-blue-600 text-white rounded-xl text-[10px] font-bold uppercase shadow-lg shadow-blue-500/20"
                >
                  Lưu thay đổi
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* ==========================================
          CREATE TASK POPUP FORM MODAL
          ========================================== */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <form onSubmit={handleCreateTask} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden block">
            
            <div className="bg-slate-50 dark:bg-slate-850 p-5 border-b border-slate-150 dark:border-slate-800 flex justify-between items-center">
              <span className="font-bold text-sm text-slate-800 dark:text-white font-display">Tạo mới đầu việc xưởng</span>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4">
              
              {/* AI Auto split helper banner ringer */}
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50/50 dark:from-slate-800 p-3.5 rounded-xl border border-blue-200 dark:border-slate-700 flex justify-between items-center gap-3">
                <div className="space-y-0.5">
                  <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wide block">Gợi ý phân tách AI Tự động</span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 block font-light">Tự động đề xuất checklist, điểm KPI và mô tả in chỉ 1-click.</span>
                </div>
                <button
                  type="button"
                  onClick={handleSplitWithAI}
                  disabled={!newTitle || isAiSplitting}
                  className="shrink-0 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white text-[11px] font-semibold rounded-lg flex items-center gap-1 transition-all"
                >
                  <Sparkles className="w-3 h-3 text-yellow-300 fill-yellow-300" />
                  <span>{isAiSplitting ? 'Đang bóc tách...' : 'AI bóc tách'}</span>
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Tiêu đề công việc
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Nhập tên nhiệm vụ: ví dụ Bảo dưỡng máy UV tuần đầu"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-250 dark:border-slate-700 rounded-lg text-xs py-2 px-3"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Dự án liên kết
                  </label>
                  <select
                    value={newProjectId}
                    onChange={(e) => setNewProjectId(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-250 dark:border-slate-700 rounded-lg text-xs py-2 px-3"
                  >
                    <option value="">Chọn dự án...</option>
                    {projects.map(p => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Phòng ban chỉ dẫn
                  </label>
                  <select
                    value={newDept}
                    onChange={(e) => setNewDept(e.target.value as Department)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-250 dark:border-slate-700 rounded-lg text-xs py-2 px-3"
                  >
                    {depts.map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Độ khẩn cấp
                  </label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value as TaskPriority)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-250 dark:border-slate-700 rounded-lg text-xs py-2 px-3"
                  >
                    {priorities.map(p => (
                      <option key={p} value={p}>{p === 'High' ? 'Khẩn cấp' : p === 'Medium' ? 'Trung bình' : 'Xem xét thấp'}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Cán bộ phụ trách
                  </label>
                  <select
                    value={newAssignee}
                    onChange={(e) => setNewAssignee(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-250 dark:border-slate-700 rounded-lg text-xs py-2 px-3 focus:ring-1 focus:ring-blue-500 transition-all outline-none"
                  >
                    <option value="">Chọn cán bộ...</option>
                    {filteredAssignees.map(u => (
                      <option key={u.id} value={u.name}>{u.name}</option>
                    ))}
                    {filteredAssignees.length === 0 && (
                      <option disabled>Không có nhân viên trong phòng này</option>
                    )}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Người liên quan (Followers)
                </label>
                <div className="flex flex-wrap gap-2 p-2 bg-slate-50 dark:bg-slate-800 border border-slate-250 dark:border-slate-700 rounded-lg min-h-[40px]">
                  {allUsers.map(u => (
                    <button
                      key={u.id}
                      type="button"
                      onClick={() => {
                        if (newFollowers.includes(u.name)) {
                          setNewFollowers(newFollowers.filter(f => f !== u.name));
                        } else {
                          setNewFollowers([...newFollowers, u.name]);
                        }
                      }}
                      className={`text-[10px] px-2 py-1 rounded-full transition-all ${
                        newFollowers.includes(u.name)
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {u.name}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Hạn chót hoàn thành
                </label>
                <input
                  type="date"
                  required
                  value={newDeadline}
                  onChange={(e) => setNewDeadline(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-250 dark:border-slate-700 rounded-lg text-xs py-2 px-3"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Nội dung chi tiết của nhiệm vụ
                </label>
                <textarea
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  rows={2}
                  placeholder="Mô tả cụ thể chỉ đạo từ giám đốc..."
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-250 dark:border-slate-700 rounded-lg text-xs py-2 px-3 font-light text-slate-700"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400">
                    Checklist chia nhỏ dòng việc (Xuống dòng cho mỗi gạch ý)
                  </label>
                  <button 
                    type="button"
                    onClick={handleAiChecklistSuggest}
                    className="text-[10px] bg-blue-650/10 text-blue-600 dark:text-blue-400 hover:bg-blue-650/20 px-2 py-0.5 rounded font-bold flex items-center gap-1 cursor-pointer transition-all"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>Tác Tạo Checklist AI</span>
                  </button>
                </div>
                <textarea
                  value={newChecklistText}
                  onChange={(e) => setNewChecklistText(e.target.value)}
                  rows={3}
                  placeholder="Ví dụ:&#10;Thiết kế market in decal bóng&#10;Xuất file PDF duyệt xưởng&#10;Khởi động máy phun UV test"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-250 dark:border-slate-700 rounded-lg text-xs py-2 px-3 font-mono text-slate-700"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Trọng số KPI điểm mẫu quy đổi (5đ - 50đ)
                </label>
                <input
                  type="number"
                  min={5}
                  max={100}
                  value={newKpi}
                  onChange={(e) => setNewKpi(parseInt(e.target.value) || 10)}
                  disabled={currentUser.role !== UserRole.SUPER_ADMIN && currentUser.role !== UserRole.ADMIN}
                  className={`w-full bg-slate-50 dark:bg-slate-800 border border-slate-250 dark:border-slate-700 rounded-lg text-xs py-2 px-3 font-bold font-mono ${
                    currentUser.role !== UserRole.SUPER_ADMIN && currentUser.role !== UserRole.ADMIN ? 'opacity-60 cursor-not-allowed' : 'text-slate-800'
                  }`}
                />
              </div>

            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-850 border-t border-slate-150 dark:border-slate-800 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold rounded-lg"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700"
              >
                Đồng ý tạo việc
              </button>
            </div>

          </form>
        </div>
      )}

    </div>
  );
}
