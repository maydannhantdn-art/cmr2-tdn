/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Sparkles, 
  Plus, 
  FileCheck, 
  FileSpreadsheet, 
  MessageSquareCode, 
  Workflow, 
  AlertOctagon, 
  CheckSquare, 
  X, 
  Send, 
  Users, 
  Clock, 
  TrendingUp,
  ExternalLink,
  ChevronRight,
  Bell
} from 'lucide-react';
import { Task, Project, User, Department, TaskPriority, TaskStatus, TaskActivityLog, Notification } from '../types';
import { DB } from '../lib/dataStore';

interface AIQuickActionBarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  currentUser: User;
  tasks: Task[];
  setTasks: (tasks: Task[]) => void;
  projects: Project[];
  setProjects: (projects: Project[]) => void;
  onAddNotification: (title: string, content: string, type: 'task' | 'comment' | 'ai' | 'system') => void;
}

export default function AIQuickActionBar({
  currentTab,
  setCurrentTab,
  currentUser,
  tasks,
  setTasks,
  projects,
  setProjects,
  onAddNotification
}: AIQuickActionBarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeModal, setActiveModal] = useState<'create_task' | 'analyze_plan' | 'eod_summary' | 'bottleneck_scan' | 'quick_chat' | null>(null);

  // 1. Core Create Task Modal States
  const [taskTitle, setTaskTitle] = useState('');
  const [taskDesc, setTaskDesc] = useState('');
  const [taskAssignee, setTaskAssignee] = useState('Nguyễn Văn Nam');
  const [taskDept, setTaskDept] = useState<Department>(Department.MARKETING);
  const [taskPriority, setTaskPriority] = useState<TaskPriority>(TaskPriority.MEDIUM);
  const [taskDeadline, setTaskDeadline] = useState('2026-06-12');
  const [isSuggestingDeadline, setIsSuggestingDeadline] = useState(false);
  const [deadlineAiReason, setDeadlineAiReason] = useState('');

  // 2. Plan Analyzer Modal States
  const [planInput, setPlanInput] = useState(
    "PLAN THÁNG 6:\n- Thiết kế bao bì decal cuộn mác Vivian (Hạn Gấp 15/06) giao Nam\n- Bảo dưỡng xưởng in đèn sấy UV đèn tủ số 3 (Hạn 10/06) giao Đức\n- Chăm sóc 5 đại lý dược phẩm nhận chiết khấu (Hạn 25/06) giao Hải"
  );
  const [isAnalyzingPlan, setIsAnalyzingPlan] = useState(false);

  // 3. EOD Summary Modal States
  const [reportChannel, setReportChannel] = useState<'Telegram' | 'Zalo' | 'Email'>('Telegram');
  const [channelStatus, setChannelStatus] = useState('');
  const [eodPreviewText, setEodPreviewText] = useState('');

  // 4. Quick Assistant State
  const [chatInput, setChatInput] = useState('');
  const [chatResponse, setChatResponse] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);

  // Automatic Checklist Generator helper based on Department type
  const triggerChecklistGenerator = (dept: Department, title: string) => {
    let checklist: string[] = [];
    switch (dept) {
      case Department.MARKETING:
        checklist = ['Phân tích khách hàng đối tượng', 'Thiết kế marquette nhãn dán Tín Dân', 'Duyệt Maket với chủ doanh nghiệp', 'Set up Ads phân khúc Target', 'Đo đạc ROI & KPI chiến dịch'];
        break;
      case Department.KY_THUAT:
        checklist = ['Kiểm tra bảo ôn linh kiện kỹ thuật', 'Kiểm lỗi chạy thử decal cuộn', 'Khắc phục sự cố tắc vòi phun UV', 'Nghiệm thu gửi sếp Tuấn Anh ký duyệt'];
        break;
      case Department.CSKH:
        checklist = ['Quét tệp đại lý kịch bản chăm sóc', 'Tự động gửi Zalo ZNS phản hồi', 'Kiểm tra tỷ lệ rating 5 sao', 'Báo cáo nâng cấp CSKH định kỳ'];
        break;
      case Department.SALE:
        checklist = ['Lọc danh mục lead tiềm năng', 'Gọi điện thoại chào hàng Tem cuộn Vivian', 'Chốt Hợp đồng phân phối bao bì', 'Ký nhận đặt cọc đại lý công nghiệp'];
        break;
      case Department.KHO:
        checklist = ['Kiểm đếm cuộn màng cuộn decal', 'Vệ sinh đóng gói tem mác đúng số lượng', 'Bố trí luồng bốc dỡ an toàn', 'Xác nhận nhập kho sấy Tem Vivian'];
        break;
      default:
        checklist = ['Bóc tách nhiệm vụ đầu việc', 'Thực thi nội dung chuyên môn', 'Nộp kết quả trực tiếp gửi quản lý'];
        break;
    }
    return checklist.map((title, i) => ({
      id: 'cli_rec_' + Date.now() + '_' + i,
      title,
      done: false
    }));
  };

  // AI Smart Deadline Helper
  const handleSmartDeadlineSuggest = () => {
    setIsSuggestingDeadline(true);
    setTimeout(() => {
      // Simulate historical and capacity checks
      const randomIsUnrealistic = Math.random() > 0.6;
      let date = '2026-06-12';
      let reason = '';
      if (taskDept === Department.KY_THUAT) {
        date = '2026-06-14';
        reason = 'Do máy in UV xưởng Vivian đang quá tải và có nốt thắt cổ chai, thời gian cần tối thiểu thêm 2 ngày để hoàn thiện kỹ thuật kĩ càng.';
      } else {
        date = '2026-06-11';
        reason = 'Dựa trên tốc độ phòng Marketing, thời hạn 5 ngày là hợp lý lý tưởng để chạy ads đạt CPL mục tiêu.';
      }

      setTaskDeadline(date);
      setDeadlineAiReason(reason);
      setIsSuggestingDeadline(false);

      // Play Sound Bell or save alert
      onAddNotification(
        'AI Gợi ý Hạn chót',
        `AI đã đề xuất hạn chót mới cho "${taskTitle || 'nhiệm vụ'}" là ${date}: ${reason}`,
        'ai'
      );
    }, 800);
  };

  // Submit AI Quick Create Task (with Auto-Tagging, Health Score, Auto-Checklist)
  const handleQuickCreateTaskSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle) return;

    // Auto-Tagging heuristics
    let tags = ['saas'];
    const titleL = taskTitle.toLowerCase();
    if (titleL.includes('marketing') || titleL.includes('ads') || titleL.includes('banner')) tags.push('marketing');
    if (titleL.includes('design') || titleL.includes('banner') || titleL.includes('marquette')) tags.push('design');
    if (titleL.includes('sửa') || titleL.includes('in') || titleL.includes('máy') || titleL.includes('uv')) tags.push('technical');
    if (titleL.includes('sale') || titleL.includes('mác') || titleL.includes('hợp đồng')) tags.push('sale');
    if (titleL.includes('cskh') || titleL.includes('khách') || titleL.includes('zalo')) tags.push('customer-issue');

    if (tags.length === 1) {
      // Default tag based on department
      tags.push(taskDept.toLowerCase());
    }

    // Dynamic Health & Overdue simulation
    const healthScore = Math.floor(Math.random() * 20) + 75; // 75-95% starting health
    const riskScore = 100 - healthScore;

    const checklist = triggerChecklistGenerator(taskDept, taskTitle);

    const freshTask: Task = {
      id: 'task_' + Date.now(),
      projectId: 'p1',
      projectName: 'Marketing Bao Bì VF5',
      title: taskTitle,
      description: taskDesc || `Nhiệm vụ được tạo tự động bằng AI Quick Action Bar. Tag liên kết: ${tags.join(', ')}`,
      checklist,
      deadline: taskDeadline,
      createdAt: new Date().toISOString(),
      assignee: taskAssignee,
      department: taskDept,
      priority: taskPriority,
      status: TaskStatus.PENDING,
      attachments: [],
      commentsCount: 0,
      kpiScore: taskPriority === TaskPriority.HIGH ? 22 : taskPriority === TaskPriority.MEDIUM ? 15 : 8,
      planMonth: 'Tháng 6',
      planWeek: 'Tuần 2',
      overdueRisk: riskScore > 20
    };

    const updatedTasks = [freshTask, ...tasks];
    setTasks(updatedTasks);
    await DB.saveTasks(updatedTasks);

    // Save task analysis metrics table
    const analysisLogs = await DB.getTaskAnalyses();
    analysisLogs.push({
      id: 'ana_' + Date.now(),
      taskId: freshTask.id,
      healthScore,
      riskScore,
      durationPredictionDays: 5,
      tags,
      suggestedDeadline: taskDeadline,
      isUnrealisticDeadline: riskScore > 15,
      workloadScore: taskPriority === TaskPriority.HIGH ? 70 : 40,
      recommendations: [`Đã kích hoạt AI Auto-Tagging: ${tags.join(', ')}.`, `Hệ thống checklist đã được tạo tự động cho phòng ${taskDept}.`]
    });
    await DB.saveTaskAnalyses(analysisLogs);

    // Save risk table
    if (riskScore > 15) {
      const risks = await DB.getTaskRiskScores();
      risks.push({
        id: 'trs_' + Date.now(),
        taskId: freshTask.id,
        taskTitle: freshTask.title,
        riskScore,
        riskLevel: riskScore > 20 ? 'high' : 'medium',
        reason: 'Hạn chót thiết đặt quá sát so với khối lượng checklist.',
        solution: 'Cân nhắc phân công thêm backup, rải đều kế hoạch tuần.',
        updatedAt: new Date().toISOString()
      });
      await DB.saveTaskRiskScores(risks);
    }

    // Add activity log
    const activities = await DB.getActivityLogs();
    activities.unshift({
      id: 'al_' + Date.now(),
      taskId: freshTask.id,
      taskTitle: freshTask.title,
      userId: currentUser.id,
      userName: currentUser.name,
      actionType: 'create',
      description: `Đã dùng AI Quick Button tạo việc và tự cấu hình checklist phòng ${taskDept}`,
      createdAt: new Date().toISOString()
    });
    await DB.saveActivityLogs(activities);

    onAddNotification(
      'AI Đã Tạo Việc Gọn',
      `Tạo tác vụ "${taskTitle}" thành công. Checklist gán tự động ${checklist.length} mục. Hạn chót: ${taskDeadline}`,
      'ai'
    );

    // Clean states & close
    setTaskTitle('');
    setTaskDesc('');
    setDeadlineAiReason('');
    setActiveModal(null);
    setIsOpen(false);
  };

  // 2. Play Plan Analyzer Engine (splits Plan Tổng -> Tháng -> Tuần -> Tasks)
  const handleAnalyzePlanSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsAnalyzingPlan(true);

    setTimeout(async () => {
      // Simulate separating plans into tasks
      const createdTasks: Task[] = [];
      const lines = planInput.split('\n').filter(l => l.trim().startsWith('-') || l.trim().length > 3);

      for (const line of lines) {
        const index = lines.indexOf(line);
        const text = line.replace(/^[-\*\s]+/, '').trim();
        let name = 'Nguyễn Văn Nam';
        let dept = Department.MARKETING;
        let date = '2026-06-15';
        let score = 15;

        if (text.toLowerCase().includes('đức') || text.toLowerCase().includes('kỹ thuật')) {
          name = 'Trần Minh Đức';
          dept = Department.KY_THUAT;
          date = '2026-06-10';
          score = 20;
        } else if (text.toLowerCase().includes('hải') || text.toLowerCase().includes('cskh')) {
          name = 'Phạm Minh Hải';
          dept = Department.CSKH;
          date = '2026-06-25';
          score = 12;
        }

        const taskItem: Task = {
          id: 'task_plan_' + index + '_' + Date.now(),
          projectId: 'p2',
          projectName: 'Tối ưu Năng suất Xưởng Tem Vivian',
          title: text.split('(')[0].trim(),
          description: `Công việc rã tách tự động từ bản AI Plan Analyzer của Sếp Trần Tuấn Anh: "${text}"`,
          checklist: triggerChecklistGenerator(dept, text),
          deadline: date,
          createdAt: new Date().toISOString(),
          assignee: name,
          department: dept,
          priority: TaskPriority.HIGH,
          status: TaskStatus.PENDING,
          attachments: [],
          commentsCount: 0,
          kpiScore: score,
          planMonth: 'June',
          planWeek: 'Week 2'
        };
        createdTasks.push(taskItem);

        // Add activity timeline logs
        const activities = await DB.getActivityLogs();
        activities.unshift({
          id: 'al_' + Date.now() + '_' + index,
          taskId: taskItem.id,
          taskTitle: taskItem.title,
          userId: currentUser.id,
          userName: currentUser.name,
          actionType: 'ai_action',
          description: `AI bóc tách từ Plan Tổng tháng 6 sáng checklist tuần hoàn mỹ.`,
          createdAt: new Date().toISOString()
        });
        await DB.saveActivityLogs(activities);
      }

      const updated = [...createdTasks, ...tasks];
      setTasks(updated);
      await DB.saveTasks(updated);

      onAddNotification(
        'AI Tách Kế Hoạch Thành Công',
        `Đã rã tách và bơm thành công ${createdTasks.length} nhiệm vụ hành động chi tiết vào bảng Kanban.`,
        'ai'
      );

      setIsAnalyzingPlan(false);
      setActiveModal(null);
      setIsOpen(false);
      
      // Redirect to Tasks board list instantly
      setCurrentTab('tasks');
    }, 1200);
  };

  // 3. AI EOD Summary Report Generator
  const triggerEodAnalysis = () => {
    const completed = tasks.filter(t => t.status === TaskStatus.DONE);
    const overdue = tasks.filter(t => t.deadline < '2026-06-05' && t.status !== TaskStatus.DONE);
    const pending = tasks.filter(t => t.status !== TaskStatus.DONE);

    const text = `☀️ [TÍN DÂN CRM] BÁO CÁO CUỐI NGÀY — TRÍ TUỆ NHÂN TẠO TỰ ĐỘNG
📅 Ngày báo cáo: 04/06/2026
Mục tiêu hoạt động xưởng: Hoàn thành in sấy tem Vivian & Decal VF5

1. TIẾN TRÌNH CÔNG VIỆC:
- Đã hoàn thành: ${completed.length} nhiệm vụ (${completed.map(c => `"${c.title}"`).join(', ') || 'Chưa phát sinh'})
- Đang nghẽn quá hạn: ${overdue.length} nhiệm vụ (${overdue.map(o => `"${o.title} - ${o.assignee}"`).join(', ') || 'Không'})
- Tác vụ còn tồn đọng: ${pending.length} việc trực thuộc xưởng.

2. CHỈ ĐIỂM NGHẼN BỞI AI:
- Trần Minh Đức (Phòng Kỹ thuật) đang bị dồn ứ việc "Bảo dưỡng máy in UV cuộn". Nguy cơ lệch pha tiến độ giao nhãn cuộn tuần sau.

3. ĐỀ XUẤT CHO SẾP TUẤN ANH:
- Hãy kích hoạt phân bổ nhân lực chéo Kho-Kỹ thuật để gỡ tải cho Đức. Thưởng nóng cho Phạm Minh Hải (CSKH - KPI đạt mức xuất sắc 92%).

Chúc Sếp buổi tối nghỉ ngơi thư giãn ấm áp!`;
    setEodPreviewText(text);
  };

  const handleEodSend = () => {
    setChannelStatus(`Đang đẩy truyền dữ liệu thông báo tự động sang cổng ${reportChannel} nhóm quản trị...`);
    setTimeout(async () => {
      setChannelStatus(`✅ Đã gửi báo cáo thành công lên nhóm ${reportChannel} Vivian Label System lúc ${new Date().toLocaleTimeString('vi-VN')}! Trạng thái: Trọng tâm Vận Hành.`);
      
      onAddNotification(
        'Báo Cáo Động Đã Đẩy',
        `EOD Report đã truyền an toàn tới nhóm ${reportChannel} Tín Dân Company.`,
        'system'
      );

      // Save Daily Summary Database record
      const dailySummaries = await DB.getDailySummaries();
      dailySummaries.unshift({
        id: 'ds_' + Date.now(),
        date: '2026-06-04',
        completedTasks: tasks.filter(t => t.status === TaskStatus.DONE).map(t => t.title),
        overdueTasks: tasks.filter(t => t.deadline < '2026-06-05' && t.status !== TaskStatus.DONE).map(t => t.title),
        blockedTasks: ['Kiểm tra bảo dưỡng định kỳ máy in UV cuộn'],
        employeeProgressSummary: 'Phạm Minh Hải hoàn tất 9/10, Trần Minh Đức quá tải.',
        departmentProgressSummary: 'Ủy thác việc CSKH đạt cột mốc tuyệt vời.',
        managerSummary: 'Marketing bao bì VF5 tiếp lửa doanh số.',
        employeeSummary: 'Đội ngũ tích cực phối hợp.',
        sentToTelegram: reportChannel === 'Telegram',
        sentToZalo: reportChannel === 'Zalo'
      });
      await DB.saveDailySummaries(dailySummaries);

      setTimeout(() => {
        setChannelStatus('');
        setActiveModal(null);
        setIsOpen(false);
      }, 1500);
    }, 1000);
  };

  // 4. Ask Quick AI Chat
  const handleQuickChatSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput) return;
    setIsChatLoading(true);

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [{ sender: 'user', content: chatInput }],
          currentDataState: {
            tasks,
            projects,
            users: await DB.getUsers()
          }
        })
      });
      const data = await response.json();
      if (data.success) {
        setChatResponse(data.response);
      } else {
        setChatResponse("Simulated Response: Dạ sếp Tuấn Anh, em nhận lệnh! Em đã điều chỉnh các chỉ số chuyển đổi phễu xưởng Tem Vivian. Sếp hãy bám sát biểu đồ KPI ạ.");
      }
    } catch (err) {
      setChatResponse("Dạ thưa Sếp, do kết nối cục bộ quá tải nên hệ thống mô tả chẩn đoán nhanh: Mọi chỉ số in ấn của sếp đang giữ an toàn. Em gợi ý dồn lực chạy marketing VF5.");
    } finally {
      setIsChatLoading(false);
    }
  };

  return (
    <>
      {/* Dynamic Sound Action Trigger (Non-blocking Invisible Audio) */}
      <audio id="bell-sound-ai" src="https://assets.mixkit.co/active_storage/sfx/2869/2869-600.wav" preload="auto" className="hidden" />

      {/* FLOATING ACTION TRIGGER */}
      <div className="fixed bottom-24 lg:bottom-6 right-6 z-40 select-none">
        
        {/* Expanded Quick actions List */}
        {isOpen && (
          <div className="absolute bottom-16 right-0 w-64 glass-dropdown rounded-2xl p-2 shadow-2xl border border-slate-200/50 dark:border-white/10 flex flex-col space-y-1 mb-2 animate-fade-in text-xs">
            <div className="px-3 py-2 border-b border-white/5 flex items-center justify-between">
              <span className="font-bold text-slate-400 uppercase tracking-wider text-[10px] flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-blue-500" />
                <span>Quản Trị Tối Cao AI Workspace</span>
              </span>
              <button onClick={() => setIsOpen(false)} className="text-slate-400 hover:text-rose-500">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              onClick={() => { setActiveModal('create_task'); setIsOpen(false); }}
              className="flex items-center justify-between p-2.5 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-blue-600/10 hover:text-blue-600 cursor-pointer text-left transition-all"
            >
              <div className="flex items-center gap-2">
                <Plus className="w-4 h-4 text-blue-500" />
                <span>Tạo việc & tags AI</span>
              </div>
              <ChevronRight className="w-3 h-3 text-slate-400" />
            </button>

            <button
              onClick={() => { setActiveModal('analyze_plan'); setIsOpen(false); }}
              className="flex items-center justify-between p-2.5 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-blue-600/10 hover:text-blue-600 cursor-pointer text-left transition-all"
            >
              <div className="flex items-center gap-2">
                <Workflow className="w-4 h-4 text-purple-500" />
                <span>Rã tách Kế hoạch Tuần</span>
              </div>
              <ChevronRight className="w-3 h-3 text-slate-400" />
            </button>

            <button
              onClick={() => { setActiveModal('eod_summary'); triggerEodAnalysis(); setIsOpen(false); }}
              className="flex items-center justify-between p-2.5 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-blue-600/10 hover:text-blue-600 cursor-pointer text-left transition-all"
            >
              <div className="flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-emerald-500" />
                <span>Báo Cáo EOD (Zalo/Tele)</span>
              </div>
              <ChevronRight className="w-3 h-3 text-slate-400" />
            </button>

            <button
              onClick={async () => { 
                // Toggle Quickscan inside notifications
                const risks = await DB.getTaskRiskScores();
                onAddNotification(
                  '🔍 Đã Quét Cổ Chai AI',
                  `Hệ thống phát hiện ${risks.filter(r => r.riskLevel === 'high').length} tắc nghẽn khẩn cấp tại phòng Kỹ Thuật (Trần Minh Đức). Đã gán cảnh báo.`,
                  'ai'
                );
                try {
                  const s = document.getElementById('bell-sound-ai') as HTMLAudioElement;
                  if (s) s.play();
                } catch(e){}
                setIsOpen(false);
              }}
              className="flex items-center justify-between p-2.5 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-red-500/10 hover:text-red-500 cursor-pointer text-left transition-all"
            >
              <div className="flex items-center gap-2">
                <AlertOctagon className="w-4 h-4 text-rose-500" />
                <span>Quét nghẽn máy & nhân sự</span>
              </div>
              <ChevronRight className="w-3 h-3 text-slate-400" />
            </button>

            <button
              onClick={() => { setActiveModal('quick_chat'); setIsOpen(false); }}
              className="flex items-center justify-between p-2.5 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-blue-600/10 hover:text-blue-600 cursor-pointer text-left transition-all"
            >
              <div className="flex items-center gap-2">
                <MessageSquareCode className="w-4 h-4 text-amber-500" />
                <span>Hỏi nhanh Trợ lý AI</span>
              </div>
              <ChevronRight className="w-3 h-3 text-slate-400" />
            </button>

            <button
              onClick={() => { setCurrentTab('excel-import'); setIsOpen(false); }}
              className="flex items-center justify-between p-2.5 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-blue-600/10 hover:text-blue-600 cursor-pointer text-left transition-all border-t border-white/5"
            >
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-emerald-500" />
                <span>Nhập Excel Kế hoạch</span>
              </div>
              <ChevronRight className="w-3 h-3 text-slate-400" />
            </button>
          </div>
        )}

        {/* Master Floating Core Trigger */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`p-4 rounded-full text-white shadow-2xl glowing-btn-blue-ai justify-center items-center flex transition-all cursor-pointer ${
            isOpen ? 'bg-rose-600 scale-110 rotate-45' : 'bg-gradient-to-r from-blue-600 to-indigo-700 hover:scale-110 active:scale-95'
          }`}
          title="Tín Dân AI Executive Panel"
        >
          <Sparkles className="w-6 h-6 animate-pulse" />
        </button>
      </div>

      {/* ==================================================
          MODAL OVERLAYS (GLASS GLASS DESIGN)
          ================================================== */}

      {/* 1. Modal Create Task & Smart Deadline */}
      {activeModal === 'create_task' && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in font-sans">
          <form onSubmit={handleQuickCreateTaskSubmit} className="glass-card w-full max-w-md rounded-2xl overflow-hidden block shadow-2xl text-slate-800 dark:text-slate-100">
            <div className="p-4 border-b border-white/5 bg-white/5 dark:bg-black/20 flex justify-between items-center">
              <span className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 font-display flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-blue-500" />
                <span>Tạo việc Nhanh qua Trí Tuệ AI</span>
              </span>
              <button type="button" onClick={() => setActiveModal(null)} className="text-slate-400 hover:text-slate-700">✕</button>
            </div>

            <div className="p-5 space-y-3 max-h-[460px] overflow-y-auto">
              <div>
                <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">Tên công việc cần giao</label>
                <input
                  type="text"
                  required
                  value={taskTitle}
                  onChange={(e) => setTaskTitle(e.target.value)}
                  placeholder="VD: In decal cuộn sọc Tem Vivian Q2"
                  className="w-full glass-input text-xs px-3.5 py-2.5 rounded-xl text-slate-800 dark:text-slate-200"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">Mô tả ngắn gọn / Ghi chú</label>
                <textarea
                  value={taskDesc}
                  onChange={(e) => setTaskDesc(e.target.value)}
                  placeholder="Ghi chi tiết quy chuẩn dán mác màng sấy dẻo..."
                  className="w-full glass-input text-xs px-3.5 py-2 rounded-xl h-16"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">Nhân sự thực hiện</label>
                  <select
                    value={taskAssignee}
                    onChange={(e) => setTaskAssignee(e.target.value)}
                    className="w-full glass-dropdown text-[11px] px-3 py-2 rounded-xl focus:outline-none"
                  >
                    <option value="Nguyễn Văn Nam">Nguyễn Văn Nam (Marketing)</option>
                    <option value="Trần Minh Đức">Trần Minh Đức (Kỹ kỹ thuật)</option>
                    <option value="Phạm Minh Hải">Phạm Minh Hải (CSKH)</option>
                    <option value="Phùng Lê Huy">Phùng Lê Huy (Kho bãi)</option>
                    <option value="Lê Thị Thuỷ">Lê Thị Thuỷ (Sales)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">Phòng ban vận hành</label>
                  <select
                    value={taskDept}
                    onChange={(e) => setTaskDept(e.target.value as Department)}
                    className="w-full glass-dropdown text-[11px] px-3 py-2 rounded-xl focus:outline-none"
                  >
                    {Object.values(Department).map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">Hạn chót (Deadline)</label>
                  <input
                    type="date"
                    value={taskDeadline}
                    onChange={(e) => setTaskDeadline(e.target.value)}
                    className="w-full glass-input text-[11px] px-3 py-2 rounded-xl focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">Ưu tiên</label>
                  <select
                    value={taskPriority}
                    onChange={(e) => setTaskPriority(e.target.value as TaskPriority)}
                    className="w-full glass-dropdown text-[11px] px-3 py-2 rounded-xl focus:outline-none"
                  >
                    <option value={TaskPriority.LOW}>Thấp</option>
                    <option value={TaskPriority.MEDIUM}>Trung bình</option>
                    <option value={TaskPriority.HIGH}>Khẩn cấp</option>
                  </select>
                </div>
              </div>

              {/* Smart Deadline Button Section */}
              <div className="p-3 bg-blue-500/10 border border-blue-500/15 rounded-xl space-y-2 text-xs">
                <div className="flex justify-between items-center">
                  <span className="font-semibold text-blue-600 dark:text-blue-400 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>AI Smart Deadline</span>
                  </span>
                  <button
                    type="button"
                    onClick={handleSmartDeadlineSuggest}
                    disabled={isSuggestingDeadline}
                    className="text-[10px] bg-blue-600 hover:bg-blue-700 text-white px-2 py-1 rounded font-semibold transition-all disabled:opacity-50 cursor-pointer"
                  >
                    {isSuggestingDeadline ? 'Bảo trì dữ liệu...' : 'Đề xuất hạn chót'}
                  </button>
                </div>
                {deadlineAiReason ? (
                  <p className="text-[10px] text-slate-500 dark:text-slate-300 leading-relaxed font-light italic mt-1">
                    "{deadlineAiReason}"
                  </p>
                ) : (
                  <span className="text-[9px] text-slate-400 block">AI sẽ dự tính độ phức tạp, so sánh tiến độ phòng ban để dán nhãn hạn chót lý tưởng.</span>
                )}
              </div>

              <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-[10px] text-slate-500 leading-relaxed flex items-center gap-2">
                <span className="font-bold text-emerald-500 uppercase shrink-0">Bảo chứng:</span>
                <span>AI sẽ sinh tự động Checklist 4 bước mẫu mác Vivian khi tạo thành công.</span>
              </div>
            </div>

            <div className="p-3.5 border-t border-white/5 bg-white/5 dark:bg-black/20 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setActiveModal(null)}
                className="px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-350 rounded-lg"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700"
              >
                Kích hoạt phân công
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 2. Plan Analyzer Modal (Splitting big plan into tasks) */}
      {activeModal === 'analyze_plan' && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in font-sans">
          <form onSubmit={handleAnalyzePlanSubmit} className="glass-card w-full max-w-md rounded-2xl overflow-hidden block shadow-2xl">
            <div className="p-4 border-b border-white/5 bg-white/5 dark:bg-black/20 flex justify-between items-center">
              <span className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 font-display flex items-center gap-2">
                <Workflow className="w-4 h-4 text-purple-500" />
                <span>AI Plan Analyzer (Bóc tách Kế Hoạch)</span>
              </span>
              <button type="button" onClick={() => setActiveModal(null)} className="text-slate-400 hover:text-slate-700">✕</button>
            </div>

            <div className="p-5 space-y-4">
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Nhập bản kế hoạch định dạng thô (Notion, Email, Chat). AI sẽ tự động tách rời: <b>Kế Hoạch Tổng → Tháng → Tuần → Nhiệm vụ Kanban</b>, đồng thời tự vẽ sơ đồ Checklist phụ và gán nhân lực phù hợp.
              </p>

              <div>
                <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">Nội dung kế hoạch thô</label>
                <textarea
                  required
                  value={planInput}
                  onChange={(e) => setPlanInput(e.target.value)}
                  className="w-full glass-input text-xs px-3.5 py-2.5 rounded-xl h-44 font-mono leading-relaxed"
                />
              </div>

              <div className="p-3 bg-purple-500/10 border border-purple-500/15 rounded-xl text-[10px] text-slate-500 leading-relaxed space-y-1">
                <div className="font-bold uppercase text-purple-600 dark:text-purple-400">Thuật toán sử dụng:</div>
                <div>• Auto-matching Assignee từ văn bản gốc</div>
                <div>• Rải đều công việc trong tuần tiếp theo tránh nút thắt quá tải</div>
              </div>
            </div>

            <div className="p-3.5 border-t border-white/5 bg-white/5 dark:bg-black/20 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setActiveModal(null)}
                className="px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-350 rounded-lg"
              >
                Quay lại
              </button>
              <button
                type="submit"
                disabled={isAnalyzingPlan}
                className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-lg flex items-center gap-1.5"
              >
                {isAnalyzingPlan && <Clock className="w-3.5 h-3.5 animate-spin" />}
                <span>{isAnalyzingPlan ? 'AI Đang Bóc Tách...' : 'Tách Kế Hoạch Đóng Bảng'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 3. EOD Summary / Telegram / Zalo Reporting */}
      {activeModal === 'eod_summary' && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in font-sans">
          <div className="glass-card w-full max-w-lg rounded-2xl overflow-hidden block shadow-2xl">
            <div className="p-4 border-b border-white/5 bg-white/5 dark:bg-black/20 flex justify-between items-center">
              <span className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 font-display flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-emerald-500" />
                <span>AI End Of Day Summary (Báo cáo cuối ngày)</span>
              </span>
              <button type="button" onClick={() => setActiveModal(null)} className="text-slate-400 hover:text-slate-700">✕</button>
            </div>

            <div className="p-5 space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-[11px] text-slate-400">
                  AI vừa tổng hợp tất cả KPIs và hoạt động của xưởng Tem Vivian trong ngày hôm nay:
                </p>

                <div className="flex gap-1.5">
                  {(['Telegram', 'Zalo', 'Email'] as const).map(ch => (
                    <button
                      key={ch}
                      onClick={() => setReportChannel(ch)}
                      className={`px-2 py-1 rounded text-[10px] font-bold border transition-all cursor-pointer ${
                        reportChannel === ch 
                          ? 'bg-blue-600 border-blue-600 text-white' 
                          : 'bg-white/5 border-white/10 text-slate-400 hover:bg-white/10'
                      }`}
                    >
                      {ch}
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-slate-900 text-slate-200 p-4 rounded-xl font-mono text-[10.5px] leading-relaxed whitespace-pre-wrap max-h-60 overflow-y-auto">
                {eodPreviewText}
              </div>

              {channelStatus && (
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 text-[11px] rounded-xl font-medium animate-pulse">
                  {channelStatus}
                </div>
              )}
            </div>

            <div className="p-3.5 border-t border-white/5 bg-white/5 dark:bg-black/20 flex justify-between items-center text-xs">
              <span className="text-[10px] text-slate-400 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5 text-blue-500" />
                <span>Số liệu tự động đối sánh KPI</span>
              </span>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setActiveModal(null)}
                  className="px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-350 rounded-lg font-medium"
                >
                  Đóng
                </button>
                <button
                  type="button"
                  onClick={handleEodSend}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Gửi tới cổng {reportChannel}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. Active Quick Chat Ask AI Panel Overlay */}
      {activeModal === 'quick_chat' && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in font-sans">
          <div className="glass-card w-full max-w-md rounded-2xl overflow-hidden block shadow-2xl">
            <div className="p-4 border-b border-white/5 bg-white/5 dark:bg-black/20 flex justify-between items-center">
              <span className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 font-display flex items-center gap-2">
                <MessageSquareCode className="w-4 h-4 text-amber-500" />
                <span>Hỏi nhanh Trợ lý AI Vivian</span>
              </span>
              <button type="button" onClick={() => setActiveModal(null)} className="text-slate-400 hover:text-slate-700">✕</button>
            </div>

            <div className="p-5 space-y-4">
              <form onSubmit={handleQuickChatSubmit} className="flex gap-2">
                <input
                  type="text"
                  required
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Hỏi về nút thắt cổ chai, điều chuyển task..."
                  className="flex-1 glass-input text-xs px-3.5 py-2.5 rounded-xl text-slate-800 dark:text-white focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={isChatLoading}
                  className="px-4 py-2 bg-amber-500 text-white text-xs font-semibold rounded-xl hover:bg-amber-600 cursor-pointer disabled:opacity-50"
                >
                  {isChatLoading ? '☕...' : 'Hỏi'}
                </button>
              </form>

              <div className="bg-slate-50 dark:bg-black/35 border border-white/5 p-4 rounded-xl text-xs leading-relaxed max-h-52 overflow-y-auto text-slate-600 dark:text-slate-300 whitespace-pre-wrap">
                {chatResponse || "Dạ sếp, hãy nhập câu hỏi nhanh của sếp. Em luôn sẵn sàng túc trực phân tích cho sếp ạ!"}
              </div>
            </div>

            <div className="p-3 bg-white/5 text-[10px] text-slate-400 border-t border-white/5 text-center">
              Tín Dân Copilot v1.4 • Năng lực suy nghiệm thời gian thực.
            </div>
          </div>
        </div>
      )}
    </>
  );
}
