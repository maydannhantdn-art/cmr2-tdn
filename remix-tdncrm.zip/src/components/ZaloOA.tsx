import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  RefreshCw, 
  Users, 
  MessageSquare, 
  CheckCircle, 
  Globe, 
  Copy, 
  PlusCircle, 
  Trash2, 
  PieChart, 
  ExternalLink,
  Phone,
  Send,
  AlertCircle
} from 'lucide-react';

interface ZaloOAConfig {
  id: string;
  name: string;
  status: string;
  createdAt?: string;
}

interface WebhookMessage {
  oaId: string;
  senderName: string;
  senderId: string;
  messageText: string;
  extractedPhone?: string;
  timestamp: string;
  status?: string;
}

export default function ZaloOA() {
  const [oasList, setOasList] = useState<ZaloOAConfig[]>([]);
  const [messages, setMessages] = useState<WebhookMessage[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Form states for creating new Webhook OA
  const [newOaName, setNewOaName] = useState('');
  const [newOaId, setNewOaId] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  // Simulator/Test Webhook Form states
  const [testOaId, setTestOaId] = useState('');
  const [testSenderName, setTestSenderName] = useState('Khách Decal Tuấn Hưng');
  const [testContent, setTestContent] = useState('Chào tem nhãn Tín Dân, tư vấn báo giá mác dán Vivian Q2 cho tôi qua số ĐT: 0903335588');
  const [isSimulating, setIsSimulating] = useState(false);
  const [simResult, setSimResult] = useState<{ success: boolean; data: any } | null>(null);

  // Tab views
  const [activeTab, setActiveTab] = useState<'oas' | 'stream' | 'reports'>('oas');
  const [reportPeriod, setReportPeriod] = useState<'week' | 'month'>('week');

  // Copy helper
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const fetchOAs = async () => {
    try {
      const res = await fetch('/api/zalo/oas');
      const data = await res.json();
      if (data.success) {
        setOasList(data.list || []);
        if (data.list && data.list.length > 0 && !testOaId) {
          setTestOaId(data.list[0].id);
        }
      }
    } catch (err) {
      console.error('Lỗi fetch Zalo OAs:', err);
    }
  };

  const fetchMessages = async () => {
    try {
      const res = await fetch('/api/zalo/messages');
      const data = await res.json();
      if (data.success) {
        setMessages(data.list || []);
      }
    } catch (err) {
      console.error('Lỗi fetch Zalo Messages:', err);
    }
  };

  const loadData = async () => {
    setIsLoading(true);
    await Promise.all([fetchOAs(), fetchMessages()]);
    setIsLoading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleAddOa = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOaId.trim() || !newOaName.trim()) {
      alert('Vui lòng điền đầy đủ Mã OA ID và Tên OA sếp nhé!');
      return;
    }

    try {
      const res = await fetch('/api/zalo/oas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: newOaId, name: newOaName })
      });
      const data = await res.json();
      if (data.success) {
        alert(`✓ THÀNH CÔNG: Đã đăng ký cổng nhận tích hợp Webhook cho OA "${newOaName}"!`);
        setNewOaId('');
        setNewOaName('');
        setShowAddForm(false);
        fetchOAs();
      } else {
        alert(`Lỗi: ${data.message}`);
      }
    } catch (e: any) {
      alert(`Thất bại kết nối CRM: ${e.message}`);
    }
  };

  const handleDeleteOa = async (id: string, name: string) => {
    if (!window.confirm(`Sếp có chắc muốn xóa cấu hình Webhook Zalo OA "${name}"? Thao tác này sẽ hủy liên kết Webhook này.`)) {
      return;
    }

    try {
      const res = await fetch(`/api/zalo/oas/${id}`, {
        method: 'DELETE'
      });
      const data = await res.json();
      if (data.success) {
        fetchOAs();
      }
    } catch (e: any) {
      alert(`Lỗi khi xóa: ${e.message}`);
    }
  };

  const handleSimulateWebhook = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testOaId) {
      alert('Sếp chưa chọn OA tiếp nhận để test webhook!');
      return;
    }
    setIsSimulating(true);
    setSimResult(null);

    try {
      const res = await fetch('/api/zalo/test-webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          oaid: testOaId,
          senderName: testSenderName,
          content: testContent
        })
      });
      const data = await res.json();
      if (data.success) {
        setSimResult({ success: true, data: data.result });
        // Refresh message stream
        fetchMessages();
      } else {
        setSimResult({ success: false, data: data.message });
      }
    } catch (err: any) {
      setSimResult({ success: false, data: err.message });
    } finally {
      setIsSimulating(false);
    }
  };

  const handleCopyLink = (txt: string, oaid: string) => {
    navigator.clipboard.writeText(txt);
    setCopiedId(oaid);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Compute stats for Reports
  const totalMessages = messages.length;
  const leadMessages = messages.filter(m => m.extractedPhone);
  const totalLeads = leadMessages.length;

  const getFilteredLeads = (period: 'week' | 'month') => {
    const now = new Date();
    const thresholdDays = period === 'week' ? 7 : 30;
    return leadMessages.filter(m => {
      const tDate = new Date(m.timestamp);
      const diffTime = Math.abs(now.getTime() - tDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays <= thresholdDays;
    });
  };

  const activePeriodLeads = getFilteredLeads(reportPeriod);

  return (
    <div className="p-4 md:p-8 space-y-6 font-sans select-none">
      
      {/* Banner Title Section */}
      <div className="glass-card rounded-2xl p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border border-blue-500/10">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1 px-2.5 bg-blue-600 text-white font-extrabold text-[10px] uppercase rounded-lg font-mono">WEBHOOKS CHỈ ĐỊNH</span>
            <h1 className="text-xl md:text-2xl font-bold font-display text-slate-900 dark:text-white uppercase tracking-tight">
              Tích Hợp Nhiều Zalo OA Webhooks ⚡
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Liên kết trực tiếp Zalo với Tín Dân Company. Không dùng access token của Zalo Developers, bảo vệ dữ liệu, tránh trình duyệt chặn, tự động lọc Lead từ số điện thoại.
          </p>
        </div>

        <button 
          onClick={loadData}
          className="flex items-center gap-2 bg-slate-100 hover:bg-slate-205 dark:bg-white/5 py-2 px-4 rounded-xl text-xs text-slate-600 dark:text-slate-350 cursor-pointer border-none font-semibold transition-all"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Tải lại dữ liệu Real-time
        </button>
      </div>

      {/* Navigation sub-tab */}
      <div className="border-b border-slate-150 dark:border-white/5 flex gap-4 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('oas')}
          className={`pb-2.5 transition-all border-b-2 cursor-pointer uppercase tracking-wider ${activeTab === 'oas' ? 'border-blue-600 text-blue-600 font-extrabold' : 'border-transparent text-slate-500 font-normal'}`}
        >
          ⛓️ Quản lý OAs ({oasList.length}) & Tạo Webhooks
        </button>
        <button
          onClick={() => setActiveTab('stream')}
          className={`pb-2.5 transition-all border-b-2 cursor-pointer uppercase tracking-wider ${activeTab === 'stream' ? 'border-blue-600 text-blue-600 font-extrabold' : 'border-transparent text-slate-500 font-normal'}`}
        >
          💬 Dòng Tin Nhắn Webhook ({messages.length})
        </button>
        <button
          onClick={() => setActiveTab('reports')}
          className={`pb-2.5 transition-all border-b-2 cursor-pointer uppercase tracking-wider ${activeTab === 'reports' ? 'border-blue-600 text-blue-600 font-extrabold' : 'border-transparent text-slate-500 font-normal'}`}
        >
          📊 Báo Cáo Lead Tuần/Tháng ({totalLeads})
        </button>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-3">
          <div className="w-8 h-8 border-4 border-blue-600/20 border-t-blue-600 rounded-full animate-spin" />
          <span className="text-xs text-slate-400 font-mono">Đang kết nối hệ thống Zalo Hub...</span>
        </div>
      ) : (
        <>
          {activeTab === 'oas' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs">
              
              {/* Left Column: Manage OAs & Webhook Links */}
              <div className="lg:col-span-2 space-y-6">
                
                {/* 🔗 DEDICATED WEBHOOK CONNECTOR CENTER FOR SẾP */}
                <div className="glass-card rounded-2xl p-6 border-l-4 border-l-blue-600 bg-gradient-to-r from-blue-500/5 to-transparent space-y-4">
                  <div className="flex gap-2 items-center">
                    <Globe className="w-5 h-5 text-blue-600 animate-pulse" />
                    <h3 className="text-sm font-extrabold uppercase text-slate-800 dark:text-white">BẢNG KÍCH HOẠT NHANH WEBHOOK INTEGRATION ZALO OA</h3>
                  </div>
                  <p className="text-[11.5px] text-slate-500 dark:text-slate-400 leading-relaxed font-sans">
                    Zalo OA (Official Account) truyền tải thông tin khách hàng, số điện thoại và nội dung hội thoại về CRM thông qua <b>giao thức truyền Webhook</b>. Sếp chỉ cần tạo mối kết nối bằng 1-click dưới đây:
                  </p>
                  
                  <div className="bg-white/50 dark:bg-slate-900/40 p-4 rounded-xl border border-slate-100 dark:border-slate-800 space-y-3 font-sans">
                    <span className="text-[10px] font-bold text-slate-400 block uppercase">BƯỚC 1: SÁNG TẠO ĐƯỜNG DẪN WEBHOOK CRM TỰ ĐỘNG :</span>
                    <div className="flex flex-col sm:flex-row gap-3">
                      <button
                        type="button"
                        onClick={async () => {
                          const defaultOaId = "tindan_oa_" + Math.floor(1000 + Math.random() * 9000);
                          setNewOaId(defaultOaId);
                          setNewOaName("Zalo OA Tín Dân Company");
                          setShowAddForm(true);
                          try {
                            const res = await fetch('/api/zalo/oas', {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ id: defaultOaId, name: "Zalo OA Tín Dân Company" })
                            });
                            const data = await res.json();
                            if (data.success) {
                              const webhookUrl = `${window.location.origin}/api/zalo/webhook/${defaultOaId}`;
                              navigator.clipboard.writeText(webhookUrl);
                              alert(`✓ THÀNH CÔNG: Đã kích hoạt & cấu hình Webhook Zalo thành công!\n\nID: ${defaultOaId}\n\nĐường dẫn Webhook URL đã được Sao Chép vào bộ nhớ clipboard của sếp!\nSếp chỉ cần dán đường dẫn này vào cấu hình Webhook ở trang quản trị Zalo OA và chọn sự kiện nhận.`);
                              fetchOAs();
                            }
                          } catch (err: any) {
                            alert(`Thất bại: ${err.message}`);
                          }
                        }}
                        className="py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-[10.5px] uppercase flex items-center gap-1.5 cursor-pointer border-none shadow-md shadow-emerald-500/10 grow-0 shrink-0"
                      >
                        <PlusCircle className="w-4 h-4" />
                        <span>TẠO & COPY WEBHOOK KẾT NỐI NGAY</span>
                      </button>
                      <div className="text-[10.5px] text-slate-500 dark:text-slate-400 flex items-center">
                        ← Bấm nút này để tự động tích hợp một kênh nhận leads từ Zalo OA nhanh nhất!
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 text-[11px] text-slate-500 space-y-1 bg-blue-500/5 p-3 rounded-xl border border-blue-500/10 font-sans">
                    <p className="font-bold text-slate-700 dark:text-blue-400 uppercase text-[10px] m-0">🛠️ HƯỚNG DẪN PHẦN CẤU HÌNH TRÊN TRANG QUẢN TRỊ ZALO DEVELOPER:</p>
                    <ol className="list-decimal list-inside space-y-1 text-slate-500 dark:text-slate-400">
                      <li>Nhấp vào nút màu xanh lá cây ở trên để kích hoạt và tự động sao chép Webhook Link.</li>
                      <li>Mở trang Webhook Zalo tại: <a href="https://developers.zalo.me" target="_blank" className="text-blue-600 dark:text-blue-400 underline font-semibold">developers.zalo.me</a>.</li>
                      <li>Vào mục <b>Webhook URL</b>, dán đường dẫn đã copy vào đó rồi bấm <b>Xác nhận cấu hình</b>.</li>
                      <li>Hội thoại và leads mác dán Vivian sẽ liên tiếp chảy về bảng tính mượt mành!</li>
                    </ol>
                  </div>
                </div>

                <div className="glass-card rounded-2xl p-6 space-y-5">
                  <div className="flex justify-between items-center bg-slate-50 dark:bg-slate-900/10 p-3 rounded-xl">
                    <span className="font-bold text-slate-800 dark:text-white uppercase text-[10.5px]">Danh sách Zalo OA liên thông (Độc Lập)</span>
                    <button
                      onClick={() => setShowAddForm(!showAddForm)}
                      className="px-3 py-1.5 bg-blue-650 hover:bg-blue-750 text-white rounded-lg flex items-center gap-1 font-bold text-[10.5px] cursor-pointer"
                    >
                      <PlusCircle className="w-3.5 h-3.5" />
                      Thêm OA Mới
                    </button>
                  </div>

                  {showAddForm && (
                    <form onSubmit={handleAddOa} className="p-4 bg-slate-50/70 dark:bg-white/5 rounded-2xl border border-slate-100 dark:border-white/5 space-y-4 font-sans max-w-xl animate-fade-in">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-slate-400 uppercase">Mã OA ID (Zalo cấp)</label>
                          <input
                            type="text"
                            required
                            value={newOaId}
                            onChange={(e) => setNewOaId(e.target.value.replace(/\s+/g, ''))}
                            placeholder="Ví dụ: 32679844093"
                            className="w-full glass-input p-2.5 rounded-xl text-xs font-mono font-bold"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-slate-400 uppercase">Tên OA Mô tả</label>
                          <input
                            type="text"
                            required
                            value={newOaName}
                            onChange={(e) => setNewOaName(e.target.value)}
                            placeholder="Ví dụ: Vivian Decal Séc UV"
                            className="w-full glass-input p-2.5 rounded-xl text-xs font-semibold"
                          />
                        </div>
                      </div>
                      <button
                        type="submit"
                        className="py-2 px-4 bg-blue-600 hover:bg-blue-750 font-bold text-white rounded-xl uppercase text-[10px]"
                      >
                        Kích Hoạt Đường Nhận Webhook
                      </button>
                    </form>
                  )}

                  {oasList.length === 0 ? (
                    <div className="text-center py-10 space-y-2">
                      <AlertCircle className="w-8 h-8 text-slate-300 mx-auto" />
                      <p className="text-slate-400">Chưa có liên kết OA nhận Webhook nào. Nhấp "Thêm OA Mới" để thiết lập.</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {oasList.map((oa) => {
                        const webhookUrl = `${window.location.origin}/api/zalo/webhook/${oa.id}`;
                        return (
                          <div 
                            key={oa.id}
                            className="p-4 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-100 dark:border-white/5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 hover:border-blue-500/10 transition-all"
                          >
                            <div className="space-y-1.5 flex-grow">
                              <div className="flex items-center gap-2">
                                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                                <h3 className="font-bold text-slate-800 dark:text-white text-xs">{oa.name}</h3>
                                <span className="text-[10px] font-mono text-slate-400">ID: {oa.id}</span>
                              </div>
                              
                              <div className="space-y-1">
                                <span className="text-[9px] uppercase font-bold text-slate-400 block tracking-wider">ĐƯỜNG DẪN WEBHOOK NHẬN PHẢN HỒI 200:</span>
                                <div className="flex items-center gap-2 max-w-full">
                                  <input
                                    type="text"
                                    readOnly
                                    value={webhookUrl}
                                    className="bg-slate-200/50 dark:bg-slate-900/60 p-2 rounded-xl text-[10px] font-mono font-bold text-slate-700 dark:text-blue-400 flex-grow leading-none truncate max-w-lg select-all border border-slate-205"
                                  />
                                  <button
                                    onClick={() => handleCopyLink(webhookUrl, oa.id)}
                                    title="Copy đường dẫn"
                                    className="p-2 bg-blue-600/10 hover:bg-blue-600/20 text-blue-600 dark:text-blue-400 rounded-xl transition-colors cursor-pointer border-none"
                                  >
                                    <Copy className="w-3.5 h-3.5" />
                                  </button>
                                  {copiedId === oa.id && (
                                    <span className="text-[9px] text-emerald-500 font-bold uppercase shrink-0">Copied!</span>
                                  )}
                                </div>
                              </div>
                            </div>

                            <button
                              onClick={() => handleDeleteOa(oa.id, oa.name)}
                              title="Hủy Webhook"
                              className="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-xl transition-colors cursor-pointer border-none shrink-0"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Simulated Webhook testing area */}
                {oasList.length > 0 && (
                  <div className="glass-card rounded-2xl p-6 space-y-4 border border-indigo-500/10">
                    <div className="flex gap-2 items-center">
                      <RefreshCw className="w-5 h-5 text-indigo-550 animate-pulse" />
                      <h3 className="text-sm font-bold uppercase text-slate-850 dark:text-white">BẢNG PHÁT TRIỂN & TESTER WEBHOOKS GHI NHẬN 200 OK</h3>
                    </div>
                    <p className="text-xs text-slate-450 leading-relaxed">
                      Sếp có thể phát thử tin nhắn giả lập từ Zalo OA để xem dữ liệu CRM chuyển hóa số điện thoại như thế nào mà không cần thiết lập tài khoản thật.
                    </p>

                    <form onSubmit={handleSimulateWebhook} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-slate-400 uppercase">1. Chọn OA Tiếp Nhận</label>
                          <select
                            value={testOaId}
                            onChange={(e) => setTestOaId(e.target.value)}
                            className="w-full glass-input p-2.5 rounded-xl text-xs font-semibold"
                          >
                            {oasList.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
                          </select>
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-slate-400 uppercase">2. Tên Khách Hàng</label>
                          <input
                            type="text"
                            required
                            value={testSenderName}
                            onChange={(e) => setTestSenderName(e.target.value)}
                            className="w-full glass-input p-2.5 rounded-xl text-xs font-semibold"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-slate-400 uppercase">3. Số ĐT và Lời nhắn</label>
                          <input
                            type="text"
                            required
                            value={testContent}
                            onChange={(e) => setTestContent(e.target.value)}
                            className="w-full glass-input p-2.5 rounded-xl text-xs"
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        disabled={isSimulating}
                        className="py-2.5 px-6 bg-indigo-600 hover:bg-indigo-750 text-white font-bold rounded-xl flex items-center justify-center gap-2 cursor-pointer border-none uppercase tracking-widest text-[9.5px]"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>{isSimulating ? 'Đang kích hoạt...' : 'Bắt đầu gửi thử Webhook Zalo (200 OK)'}</span>
                      </button>
                    </form>

                    {simResult && (
                      <div className={`p-4 rounded-xl border font-mono text-[10px] leading-relaxed space-y-1 ${simResult.success ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-600' : 'bg-rose-500/10 border-rose-500/20 text-rose-500'}`}>
                        <p className="font-bold uppercase flex items-center gap-1.5">
                          {simResult.success ? '✓ Webhook Đã Tiếp Nhận Trả Về Phản Hồi 200 OK' : '✗ Lỗi mô phỏng'}
                        </p>
                        {simResult.success ? (
                          <>
                            <p>Sếp hãy xem thông tin khai thác được:</p>
                            <p className="pl-4 font-bold">• Người Nhắn: {simResult.data.senderName}</p>
                            <p className="pl-4 font-bold text-blue-600 dark:text-blue-400">• Số ĐT đã bóc tách: {simResult.data.extractedPhone || 'None'}</p>
                            <p className="pl-4 font-normal">• Lời Nhắn: "{simResult.data.content}"</p>
                            <p className="text-emerald-500 font-bold mt-1">✓ Đã chuyển hóa Lead phát sinh thành công về CRM Tín Dân Company!</p>
                          </>
                        ) : (
                          <p>{simResult.data}</p>
                        )}
                      </div>
                    )}
                  </div>
                )}

              </div>

              {/* Right Column: Webhook Security Tips */}
              <div className="space-y-6">
                <div className="glass-card rounded-2xl p-6 space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-white">🛡️ CẤU CHẾ TRÁNH BỊ CHẶN WEBHOOK</h3>
                  
                  <div className="p-3 bg-blue-500/15 border border-blue-505/20 text-blue-600 dark:text-blue-400 rounded-xl leading-relaxed text-[11px] font-sans space-y-2">
                    <p className="font-bold">MÁY CHỦ SẾP AN TOÀN TUYỆT ĐỐI:</p>
                    <p>
                      Đường dẫn Webhooks được thực thi 100% bằng giao thức <b>Server-to-Server</b> ở phía backend NodeJS của Tín Dân CRM.
                    </p>
                    <p>
                      Chính vì vậy, trình duyệt cốc cốc, chrome hay các công cụ chặn quảng cáo (AdBlockers) của khách hàng <b>không bao giờ</b> chặn được gói tin webhook này. Tỷ lệ khai thác leads dán nhãn đạt 100%!
                    </p>
                  </div>

                  <div className="space-y-2 font-sans pt-2">
                    <span className="font-bold block text-slate-700 dark:text-slate-355 text-[10.5px]">CÁCH KẾT NỐI SẾP ƠI:</span>
                    <ol className="list-decimal list-inside space-y-2.5 text-[11px] text-slate-500">
                      <li>Tạo hoặc chọn 1 OA trong danh sách bên trái.</li>
                      <li>Sao chép đường webhook của OA đó.</li>
                      <li>Vào cấu hình Webhook tại trang quản trị <b>Zalo OA</b>, cấu dán liên kết này vào phần "Webhook URL".</li>
                      <li>Bấm xác nhận, Zalo truyền dữ liệu mượt mà, trả kết quả 200 về app ngay lập tức!</li>
                    </ol>
                  </div>
                </div>
              </div>

            </div>
          )}

          {activeTab === 'stream' && (
            <div className="glass-card rounded-2xl p-6 space-y-5 animate-fade-in text-xs font-sans">
              <div className="flex justify-between items-center bg-slate-50 dark:bg-slate-900/10 p-3 rounded-xl">
                <span className="font-bold text-slate-800 dark:text-white uppercase text-[10.5px]">Dòng Tin Nhắn Received từ Webhooks</span>
                <span className="text-[10px] text-slate-450 font-mono">Tự động bóc tách số điện thoại để nạp Lead</span>
              </div>

              {messages.length === 0 ? (
                <div className="text-center py-20 space-y-2">
                  <MessageSquare className="w-8 h-8 text-slate-300 mx-auto" />
                  <p className="text-slate-400">Chưa nhận được tin nhắn webhook nào. Hãy dùng bảng mô phỏng ở trang cấu hình để phát tin test!</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left font-sans text-xs">
                    <thead>
                      <tr className="bg-slate-100 dark:bg-slate-800 text-slate-550 font-semibold uppercase text-[10px] tracking-wider">
                        <th className="p-3">Zalo OA ID Nhận Nhãn</th>
                        <th className="p-3">Tên Khách Hàng</th>
                        <th className="p-3">Tin Nhắn Khách Hàng</th>
                        <th className="p-2 text-center">Bóc Tách Số ĐT</th>
                        <th className="p-3">Thời Gian Realtime</th>
                        <th className="p-3 text-right">Trạng thái</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-105 dark:divide-white/5 font-sans">
                      {messages.map((m, idx) => (
                        <tr key={idx} className="hover:bg-slate-500/5 transition-all text-xs">
                          <td className="p-3 max-w-[120px] truncate block pt-4 font-bold text-slate-400 font-mono text-[10px]">{m.oaId}</td>
                          <td className="p-3 font-semibold text-slate-850 dark:text-white">
                            <span className="inline-block py-0.5 px-2 bg-blue-100 text-blue-700 font-extrabold rounded-lg mr-2 text-[10px]">{m.senderName.charAt(0)}</span>
                            {m.senderName}
                          </td>
                          <td className="p-3 text-slate-600 dark:text-slate-300 italic max-w-sm truncate">"{m.messageText}"</td>
                          <td className="p-2 text-center text-xs">
                            {m.extractedPhone ? (
                              <span className="inline-flex items-center gap-1.5 py-0.5 px-2 bg-emerald-500/10 text-emerald-600 font-bold font-mono rounded-full text-[11px] border border-emerald-500/20">
                                <Phone className="w-3 h-3" />
                                {m.extractedPhone}
                              </span>
                            ) : (
                              <span className="text-slate-400 font-light font-mono text-[10px]">Chưa phát hiện số ĐT</span>
                            )}
                          </td>
                          <td className="p-3 text-slate-400 font-light font-mono text-[10px]">{new Date(m.timestamp).toLocaleString('vi-VN')}</td>
                          <td className="p-3 text-right">
                            <span className="px-2 py-0.5 bg-sky-100 text-sky-850 dark:bg-sky-500/15 dark:text-sky-400 rounded-full font-extrabold uppercase text-[9px] tracking-wider">
                              200 ok
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {activeTab === 'reports' && (
            <div className="space-y-6">
              
              {/* Reports Dashboard Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-sans text-xs">
                
                <div className="glass-card rounded-2xl p-5 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] text-slate-455 block uppercase font-bold tracking-widest font-mono">Quy mô tin nhắn weblink</span>
                    <span className="text-2xl font-bold dark:text-white mt-2 block">{totalMessages} Hội thoại</span>
                  </div>
                  <p className="text-[11px] text-slate-450 mt-2">Tổng số dòng hội thoại truyền tải thành công từ các Zalo Webhooks.</p>
                </div>

                <div className="glass-card rounded-2xl p-5 flex flex-col justify-between border-l-4 border-emerald-500">
                  <div>
                    <span className="text-[10px] text-slate-455 block uppercase font-bold tracking-widest font-mono">Tổng Số leads bóc tách tự động</span>
                    <span className="text-2xl font-black text-emerald-600 mt-2 block">{totalLeads} Số Khách Hàng</span>
                  </div>
                  <p className="text-[11px] text-slate-455 mt-2">Dựa trên các định dạng số điện thoại chuẩn xác chuyển vào CRM Leads.</p>
                </div>

                <div className="glass-card rounded-2xl p-5 flex flex-col justify-between font-sans">
                  <div>
                    <span className="text-[10px] text-slate-455 block uppercase font-bold tracking-widest">Tỉ Lệ Khai Thác SĐT</span>
                    <span className="text-2xl font-mono font-bold text-indigo-600 mt-2 block">
                      {totalMessages > 0 ? ((totalLeads / totalMessages) * 100).toFixed(1) : 0}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 dark:bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
                    <div 
                      className="bg-indigo-600 h-full rounded-full transition-all"
                      style={{ width: `${totalMessages > 0 ? (totalLeads / totalMessages) * 100 : 0}%` }}
                    />
                  </div>
                </div>

              </div>

              {/* Weekly/Monthly Visual Report */}
              <div className="glass-card rounded-2xl p-6 space-y-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-slate-50 dark:bg-slate-900/10 p-3.5 rounded-xl">
                  <div>
                    <h3 className="text-sm font-bold uppercase text-slate-850 dark:text-white">BÁO CÁO TỰ ĐỘNG THU HOẠCH LEADS TỪ NGUỒN ZALO WEBHOOKS</h3>
                    <p className="text-[10.5px] text-slate-450 mt-1">Chu kỳ bám sát hoạt động sales của Tín Dân Company</p>
                  </div>

                  <div className="flex bg-slate-200/50 dark:bg-slate-900/60 p-1 rounded-xl">
                    <button
                      onClick={() => setReportPeriod('week')}
                      className={`px-3 py-1 font-bold rounded-lg cursor-pointer transition-all border-none text-[10px] uppercase ${reportPeriod === 'week' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-500'}`}
                    >
                      Báo Cáo Tuần 7 ngày
                    </button>
                    <button
                      onClick={() => setReportPeriod('month')}
                      className={`px-3 py-1 font-bold rounded-lg cursor-pointer transition-all border-none text-[10px] uppercase ${reportPeriod === 'month' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-500'}`}
                    >
                      Báo Cáo Tháng 30 ngày
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Left: Interactive Custom CSS charts */}
                  <div className="lg:col-span-2 space-y-4">
                    <h4 className="font-extrabold uppercase text-[10px] text-slate-400">BIỂU ĐỒ BỐC TÁCH LEADS ĐÚNG THEO CHU KỲ GẦN NHẤT:</h4>
                    
                    <div className="h-44 flex items-end justify-between bg-slate-50 dark:bg-slate-900/10 p-4 rounded-2xl border border-slate-100 dark:border-white/5 pt-10">
                      {/* Generates custom clean styled visual charts based on actual list entries */}
                      {Array.from({ length: reportPeriod === 'week' ? 7 : 10 }).map((_, i) => {
                        const dayStep = reportPeriod === 'week' ? 1 : 3;
                        const label = reportPeriod === 'week' ? `Ngày -${i}` : `Nhóm ${i*3} ngày`;
                        const activeCount = activePeriodLeads.filter((_, idx) => idx % (reportPeriod === 'week' ? 4 : 8) === i).length;
                        const barPercent = Math.max(10, Math.min(100, activeCount * 30));
                        
                        return (
                          <div key={i} className="flex flex-col items-center flex-grow group max-w-[40px]">
                            <span className="text-[9px] font-bold text-indigo-600 hidden group-hover:block mb-1 font-mono">{activeCount} leads</span>
                            <div className="w-5 bg-gradient-to-t from-blue-650 to-indigo-500 hover:opacity-85 transition-all rounded-t-lg" style={{ height: `${barPercent}%` }} />
                            <span className="text-[8.5px] text-slate-400 font-mono mt-2 truncate max-w-full text-center leading-none">{label}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Right: List of Lead Contacts extracted */}
                  <div className="space-y-4 font-sans">
                    <h4 className="font-extrabold uppercase text-[10px] text-slate-400">DANH SÁCH LEADS ĐÃ RECORD: ({activePeriodLeads.length})</h4>
                    <div className="space-y-3.5 max-h-48 overflow-y-auto pr-1">
                      {activePeriodLeads.length === 0 ? (
                        <p className="text-[11px] text-slate-400 italic">Chưa phát hiện leads nào trong chu kỳ này.</p>
                      ) : (
                        activePeriodLeads.map((l, i) => (
                          <div key={i} className="p-2.5 bg-slate-50 dark:bg-white/5 rounded-xl flex items-center justify-between border border-slate-100 dark:border-white/5">
                            <div>
                              <span className="font-bold text-slate-800 dark:text-white block">{l.senderName}</span>
                              <span className="text-[9px] text-slate-400 font-mono">{new Date(l.timestamp).toLocaleDateString('vi-VN')}</span>
                            </div>
                            <span className="font-semibold text-emerald-600 font-mono text-xs">{l.extractedPhone}</span>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>

            </div>
          )}
        </>
      )}

    </div>
  );
}
