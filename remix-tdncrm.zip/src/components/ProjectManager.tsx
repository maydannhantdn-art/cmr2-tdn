/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, Project, Department } from '../types';
import { DB } from '../lib/dataStore';
import { Plus, FolderKanban, Info, CheckCircle2, TrendingUp, Filter, Trash2 } from 'lucide-react';

interface ProjectManagerProps {
  currentUser: User;
  projects: Project[];
  setProjects: (projects: Project[]) => void;
}

export default function ProjectManager({ currentUser, projects, setProjects }: ProjectManagerProps) {
  const [showCreateProj, setShowCreateProj] = useState(false);
  const [projName, setProjName] = useState('');
  const [projCode, setProjCode] = useState('');
  const [projDesc, setProjDesc] = useState('');
  const [projDept, setProjDept] = useState<Department>(currentUser.department || Department.MARKETING);
  const [selectedDeptFilter, setSelectedDeptFilter] = useState<string>('All');

  const depts = Object.values(Department);

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!projName || !projCode) return;

    const newProject: Project = {
      id: 'p_' + Date.now(),
      name: projName,
      code: projCode.toUpperCase(),
      description: projDesc,
      progress: 0,
      department: projDept,
      status: 'active'
    };

    const updated = [...projects, newProject];
    setProjects(updated);
    DB.saveProjects(updated);

    // Clear form
    setProjName('');
    setProjCode('');
    setProjDesc('');
    setShowCreateProj(false);
  };

  const handleDeleteProj = (id: string) => {
    const proj = projects.find(p => p.id === id);
    const name = proj ? proj.name : 'Dự án';
    if (!window.confirm(`Sếp có chắc chắn muốn xóa dự án "${name}" vĩnh viễn? Tất cả đầu việc đi kèm sản xuất sẽ bị loại bỏ!`)) {
      return;
    }
    const updated = projects.filter(p => p.id !== id);
    setProjects(updated);
    DB.saveProjects(updated);
  };

  const handleProgressChange = (id: string, nextProgress: number) => {
    const updated = projects.map(p => {
      if (p.id === id) return { ...p, progress: nextProgress };
      return p;
    });
    setProjects(updated);
    DB.saveProjects(updated);
  };

  const handleUpdateStatus = (id: string, nextStatus: any) => {
    const updated = projects.map(p => {
      if (p.id === id) return { ...p, status: nextStatus };
      return p;
    });
    setProjects(updated);
    DB.saveProjects(updated);
  };

  const filteredProjects = projects.filter(p => {
    if (selectedDeptFilter !== 'All' && p.department !== selectedDeptFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-4 md:p-6 lg:p-8 font-sans">
      
      {/* Page Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white font-display">Chiến dịch & Dự án Tổng</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Khởi tạo và giám sát lũy tiến tiến trình các nhóm máy xưởng, chiến dịch in ấn.</p>
        </div>

        {/* Create button */}
        {(currentUser.role === 'Super Admin' || currentUser.role === 'Admin' || currentUser.role === 'Manager') && (
          <button
            onClick={() => setShowCreateProj(true)}
            className="w-full sm:w-auto py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Thành lập Dự án Mới</span>
          </button>
        )}
      </div>

      {/* Filter line */}
      <div className="glass-card rounded-xl p-4 flex justify-between items-center text-xs">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="font-semibold text-slate-500">Phòng ban liên kết:</span>
        </div>
        <select
          value={selectedDeptFilter}
          onChange={(e) => setSelectedDeptFilter(e.target.value)}
          className="glass-dropdown rounded-lg text-xs py-1.5 px-3 focus:outline-none"
        >
          <option value="All">Tất cả phòng ban</option>
          {depts.map(d => (
            <option key={d} value={d}>{d}</option>
          ))}
        </select>
      </div>

      {/* Projects Grid List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredProjects.map((proj) => (
          <div
            key={proj.id}
            className="glass-card rounded-2xl p-5 space-y-4"
          >
            <div className="flex justify-between items-start gap-3">
              <div className="flex items-start gap-3">
                <div className="p-2.5 bg-blue-50 dark:bg-blue-900/20 text-blue-600 rounded-xl shrink-0">
                  <FolderKanban className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white font-display">{proj.name}</h3>
                  <span className="text-[10px] text-slate-400 font-mono block mt-0.5">{proj.code} • Phòng {proj.department}</span>
                </div>
              </div>

              {/* Status Select Badge */}
              <div className="flex items-center gap-1">
                <select
                  value={proj.status}
                  onChange={(e) => handleUpdateStatus(proj.id, e.target.value)}
                  className="glass-dropdown text-[10px] uppercase font-bold text-slate-600 border border-white/5 py-1 px-2.5 rounded-lg outline-none cursor-pointer"
                >
                  <option value="planning">Lập kế hoạch</option>
                  <option value="active">Đang kích hoạt</option>
                  <option value="completed">Đã bàn giao</option>
                  <option value="on-hold">Đang tạm dừng</option>
                </select>

                {/* Trash delete project */}
                {(currentUser.role === 'Super Admin' || currentUser.role === 'Admin') && (
                  <button
                    onClick={() => handleDeleteProj(proj.id)}
                    className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/25 rounded cursor-pointer border-none transition-colors"
                    title="Xóa dự án"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400 font-light leading-relaxed min-h-[30px]">
              {proj.description || 'Chưa cập nhật tài liệu mô tả.'}
            </p>

            {/* Completion dynamic bar */}
            <div className="space-y-1.5 pt-2">
              <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400">
                <span className="font-semibold">Tiến độ lũy tiến</span>
                <span className="font-bold text-blue-600 font-mono">{proj.progress}%</span>
              </div>
              <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-indigo-600 h-full transition-all" 
                  style={{ width: `${proj.progress}%` }} 
                />
              </div>

              {/* Progress slider handle if Admin */}
              {(currentUser.role === 'Super Admin' || currentUser.role === 'Admin' || currentUser.role === 'Manager') && (
                <div className="flex items-center gap-2 pt-2 text-[10px]">
                  <span className="text-slate-400">Cân chỉnh nhanh:</span>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={proj.progress}
                    onChange={(e) => handleProgressChange(proj.id, parseInt(e.target.value))}
                    className="flex-1 accent-blue-600 h-1 rounded"
                  />
                </div>
              )}
            </div>

          </div>
        ))}
      </div>

      {/* Project Creation Sheet Overlay Popup */}
      {showCreateProj && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50">
          <form onSubmit={handleCreateProject} className="glass-card w-full max-w-sm rounded-2xl overflow-hidden block shadow-2xl">
            
            <div className="p-4 border-b border-white/5 bg-white/5 dark:bg-black/20 flex justify-between items-center">
              <span className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-350 font-display">Phê duyệt Dự Án Mới</span>
              <button
                type="button"
                onClick={() => setShowCreateProj(false)}
                className="text-slate-450 hover:text-slate-700"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">Tên chiến dịch / Máy xưởng</label>
                <input
                  type="text"
                  required
                  value={projName}
                  onChange={(e) => setProjName(e.target.value)}
                  placeholder="Ví dụ: Lắp đặt Dây chuyền in sấy UV số 4"
                  className="w-full glass-input text-xs px-3.5 py-2 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">Mã viết tắt</label>
                  <input
                    type="text"
                    required
                    value={projCode}
                    onChange={(e) => setProjCode(e.target.value)}
                    placeholder="VD: UV-LINE4"
                    className="w-full glass-input text-xs px-3.5 py-2 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">Phòng ban liên quan</label>
                  <select
                    value={projDept}
                    onChange={(e) => setProjDept(e.target.value as Department)}
                    className="w-full glass-dropdown text-xs px-3.5 py-2 rounded-lg"
                  >
                    {depts.map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">Bản mô tả mục tiêu dự án</label>
                <textarea
                  value={projDesc}
                  onChange={(e) => setProjDesc(e.target.value)}
                  rows={3}
                  className="w-full glass-input text-xs px-3.5 py-2.5 rounded-lg"
                  placeholder="Kế hoạch chuyển đổi tự động mẫu decal màng in chất lượng công nghiệp..."
                />
              </div>

            </div>

            <div className="p-4 border-t border-white/5 bg-white/5 dark:bg-black/20 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setShowCreateProj(false)}
                className="px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-350 rounded-lg"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700"
              >
                Tạo dự án
              </button>
            </div>

          </form>
        </div>
      )}

    </div>
  );
}
