/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { User, Task, Project, KPIs, Notification, TaskComment, ThemeMode, UserRole, Department, TaskPriority, TaskStatus } from './types';
import { DB } from './lib/dataStore';
import { ensureAuth } from './lib/firebase';

// Load child panels modularly
import Login from './components/Login';
import Navigation from './components/Navigation';
import Dashboard from './components/Dashboard';
import Tasks from './components/Tasks';
import ProjectManager from './components/ProjectManager';
import AIImport from './components/AIImport';
import AIReports from './components/AIReports';
import KPIManager from './components/KPIManager';
import AIAssistant from './components/AIAssistant';
import ChatbotDuyen from './components/ChatbotDuyen';
import ZaloOA from './components/ZaloOA';
import FileCenter from './components/FileCenter';
import Settings from './components/Settings';
import UserManagement from './components/UserManagement';
import AIQuickActionBar from './components/AIQuickActionBar';
import ChatbotWidgetFrame from './components/ChatbotWidgetFrame';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [themeMode, setThemeMode] = useState<ThemeMode>(ThemeMode.LIGHT);
  const [isLoading, setIsLoading] = useState(true);
  const [initError, setInitError] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isResetting, setIsResetting] = useState(false);

  // States mirroring our local dataStore tables
  const [tasks, setTasks] = useState<Task[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [kpis, setKpis] = useState<KPIs[]>([]);
  const [comments, setComments] = useState<TaskComment[]>([]);

  // On mount: load initial state bags
  const initData = async () => {
    try {
      setIsLoading(true);
      setInitError(null);

      // 1. First, define the seed structures
      const seedUsers: User[] = [
        { id: 'u_admin', email: 'tuananhcdv', password: 'tdn@1234!', name: 'Trần Tuấn Anh (CDV)', role: UserRole.ADMIN, department: Department.ADMIN, status: 'active', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face' },
        { id: 'u1', email: 'tindancompany22@gmail.com', password: 'admin', name: 'Trần Tuấn Anh (Sếp Tín Dân)', role: UserRole.SUPER_ADMIN, department: Department.ADMIN, status: 'active', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face' },
        { id: 'u2', email: 'marketing.tin@gmail.com', password: '123', name: 'Nguyễn Văn Nam', role: UserRole.MANAGER, department: Department.MARKETING, status: 'active', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&h=150&fit=crop&crop=face' },
        { id: 'u3', email: 'sales.tin@gmail.com', password: '123', name: 'Lê Thị Thuỷ', role: UserRole.EMPLOYEE, department: Department.SALE, status: 'active', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop&crop=face' }
      ];

      const seedProjects: Project[] = [
        { id: 'p1', name: 'Marketing Bao Bì VF5', code: 'PRO-MARK-VF5', description: 'Chiến dịch mác dán bao bì VF5', progress: 65, department: Department.MARKETING, status: 'active' },
        { id: 'p2', name: 'Tối ưu Xưởng Tem Vivian', code: 'PRO-VIVIAN', description: 'Nâng cấp máy in sấy UV', progress: 40, department: Department.KY_THUAT, status: 'active' }
      ];

      const seedTasks: Task[] = [
        {
          id: 't1', projectId: 'p1', projectName: 'Marketing Bao Bì VF5',
          title: 'Thiết kế Tem Vivian mẫu Q2', description: 'Thiết kế marquette in decal cuộn chất lượng cao.',
          checklist: [{ id: 'c1', title: 'Phác thảo mẫu', done: true }],
          deadline: '2026-06-25', createdAt: new Date().toISOString(), assignee: 'Nguyễn Văn Nam', department: Department.MARKETING,
          priority: TaskPriority.HIGH, status: TaskStatus.IN_PROGRESS, attachments: [], commentsCount: 0,
          kpiScore: 15, planMonth: 'June', planWeek: 'Week 2'
        }
      ];

      const seedKPIs: KPIs[] = [
        { id: 'k1', employeeName: 'Nguyễn Văn Nam', department: Department.MARKETING, month: '06/2026', totalTasks: 5, completedTasks: 4, overdueTasks: 0, kpiScore: 85, weeklyProgress: [80, 85, 90, 85], notes: 'Xuất sắc mảng decal.' }
      ];

      // 2. Seed the local cache immediately if empty so the login/demos are 100% active instantly
      DB.seedLocalIfSterile(seedUsers, seedProjects, seedTasks, seedKPIs);

      // 3. Auto authenticate previous session if remembered to show the app instantly
      const savedUser = DB.getCurrentUser();
      if (savedUser) {
        setCurrentUser(savedUser);
        
        // Populate instantly from secure local cache so the CRM is immediately functional
        setTasks(DB.getCachedTasks(savedUser));
        setProjects(DB.getCachedProjects(savedUser));
        setNotifications(DB.getCachedNotifications(savedUser));
        setKpis(DB.getCachedKPIs(savedUser));
        
        // Turn off the loading screen immediately
        setIsLoading(false);
      } else {
        // If not logged in, show the login screen immediately with no waiting
        setIsLoading(false);
      }

      // 4. Background verification & Cloud-seeding if Firestore is empty.
      // This is non-blocking to prevent UI freezes on proxy/restriced network tunnels!
      (async () => {
        try {
          await ensureAuth();
          const existingUsers = await DB.getUsers();
          
          if (existingUsers.length === 0) {
            console.log("[FIREBASE] Cloud DB sterile. Background seeding triggered...");
            for (const u of seedUsers) {
              await DB.saveUser(u);
            }
            await DB.saveProjects(seedProjects);
            await DB.saveTasks(seedTasks);
            await DB.saveKPIs(seedKPIs);
            console.log("[FIREBASE] Background database seeding completed successfully.");
          }
        } catch (err: any) {
          console.log("[FIREBASE] Background sync: database offline or delayed.", err.message || err);
        }
      })();

    } catch (err: any) {
      console.log("Silent connection initialization: database offline.", err);
      const savedUser = DB.getCurrentUser();
      if (!savedUser) {
        setInitError("Kết nối dữ liệu chậm. Vui lòng mở lại trang hoặc liên kết mạng.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    initData();
  }, []);

  // 1. Instantly load from local storage cache for maximum fluidness without triggering database reads
  useEffect(() => {
    if (currentUser) {
      setTasks(DB.getCachedTasks(currentUser));
      setProjects(DB.getCachedProjects(currentUser));
      setNotifications(DB.getCachedNotifications(currentUser));
      setKpis(DB.getCachedKPIs(currentUser));
    }
  }, [currentUser]);

  // 2. Permanent background automatic cloud synchronization via real-time listeners (onSnapshot)
  // This automatically connects, fetches, and syncs data in the background on any new event or modification.
  useEffect(() => {
    if (!currentUser) return;

    console.log("[Firebase CRM] Mounting persistent real-time change-listeners for all core modules...");

    // Task real-time observer stream
    const unsubTasks = DB.subscribeToTasks(currentUser, (freshTasks: Task[]) => {
      setTasks(freshTasks);
    });

    // Projects real-time observer stream
    const unsubProjects = (DB as any).subscribeToProjects(currentUser, (freshProjects: Project[]) => {
      setProjects(freshProjects);
    });

    // KPIs real-time observer stream
    const unsubKPIs = (DB as any).subscribeToKPIs(currentUser, (freshKPIs: KPIs[]) => {
      setKpis(freshKPIs);
    });

    // Notifications real-time observer stream
    const unsubNotifs = (DB as any).subscribeToNotifications(currentUser, (freshNotifs: Notification[]) => {
      setNotifications(freshNotifs);
    });

    return () => {
      console.log("[Firebase CRM] Cleaning up background real-time subscriptions...");
      unsubTasks();
      unsubProjects();
      unsubKPIs();
      unsubNotifs();
    };
  }, [currentUser]);

  const handleSyncWithCloud = async () => {
    if (!currentUser) return;
    try {
      setIsSyncing(true);
      
      // 1. Process offline-queue sync phase
      const syncResult = await (DB as any).syncUnsyncedItems();
      
      // Real-time snapshot streams automatically handle down-sync, no secondary heavy pulling needed!
      let syncMessage = 'Hệ thống tự động kết nối và đồng bộ hóa thành công dữ liệu của Sếp với đám mây Tín Dân!';
      if (syncResult && syncResult.failedCount > 0) {
        syncMessage = `Lưu trữ ngoại tuyến an toàn!\n\n` +
          `✔️ Đã tải lên thành công: ${syncResult.successCount} bản ghi.\n` +
          `⚠️ Còn lại chưa gửi lên mây: ${syncResult.failedCount} bản ghi (Phân hệ: ${syncResult.failedSummary.join(', ')}).\n\n` +
          `🔒 YÊN TÂM TUYỆT ĐỐI: Toàn bộ dữ liệu VẪN ĐƯỢC BẢO TOÀN TRÊN THIẾT BỊ của sếp và nhân viên, không sợ mất mát!`;
      } else if (syncResult && syncResult.successCount > 0) {
        syncMessage = `Tổng quan đồng bộ: Nhận diện thành công ${syncResult.successCount} thao tác chỉnh sửa ngoại tuyến và cập nhật hoàn hảo lên dữ liệu trung tâm Firebase Tín Dân Company.`;
      } else {
        syncMessage = `Kết nối thông suốt! Toàn bộ cơ sở dữ liệu trên máy sếp hiện đã khớp lệnh 100% với máy chủ đám mây trung tâm Tín Dân.`;
      }

      await addSystemNotification(
        'Đồng bộ hệ thống',
        `Đã kích hoạt đồng bộ hóa dữ liệu CRM thủ công thành công với máy chủ đám mây Firebase Firestore Tín Dân.`,
        'system'
      );
      alert(syncMessage);
    } catch (err: any) {
      console.error("Manual sync error:", err);
      alert('Không nhận được tín hiệu phản hồi từ đám mây (Hệ thống tự động lưu trữ ngoại tuyến tại chỗ): ' + (err.message || err));
    } finally {
      setIsSyncing(false);
    }
  };

  const handleResetConnection = async () => {
    try {
      setIsResetting(true);
      // Run diagnostic connection test
      const existingUsers = await DB.getUsers();
      
      // Update states from local cache to refresh visual panels
      if (currentUser) {
        setTasks(DB.getCachedTasks(currentUser));
        setProjects(DB.getCachedProjects(currentUser));
        setNotifications(DB.getCachedNotifications(currentUser));
        setKpis(DB.getCachedKPIs(currentUser));
      }

      await addSystemNotification(
        'Kiểm tra đường truyền',
        `Sếp vừa làm mới kết nối. Trạng thái Supabase: Hoạt động. Tổng số tài khoản cơ sở: ${existingUsers.length}.`,
        'system'
      );
      alert('Reset thành công! Đường truyền Supabase đã được làm mới và hoạt động trơn tru.');
    } catch (err: any) {
      console.error("Manual reset connection error:", err);
      alert('Không thể làm mới kết nối Supabase. Sếp hãy kiểm tra lại kết nối mạng Wifi/4G.');
    } finally {
      setIsResetting(false);
    }
  };

  // Theme support toggle observer
  useEffect(() => {
    if (themeMode === ThemeMode.DARK) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [themeMode]);

  const handleLoginSuccess = async (user: User) => {
    setCurrentUser(user);
    DB.setCurrentUser(user);
    
    // Add positive tracking
    addSystemNotification(
      'Hệ thống trực tuyến',
      `Người dùng ${user.name} vừa đăng nhập không gian làm việc phòng ${user.department}.`,
      'system'
    );
  };

  const handleLogout = () => {
    DB.setCurrentUser(null);
    setCurrentUser(null);
    setCurrentTab('dashboard');
  };

  const addSystemNotification = async (title: string, content: string, type: 'task' | 'comment' | 'ai' | 'system') => {
    const newNotif: Notification = {
      id: 'notif_' + Date.now(),
      title,
      content,
      type,
      createdAt: new Date().toISOString(),
      read: false,
      department: currentUser?.department || 'Admin'
    };
    const updated = [newNotif, ...notifications];
    setNotifications(updated);
    await DB.saveNotifications([newNotif]);
  };

  const handleImportSuccess = async (imported: Task[]) => {
    if (!currentUser) return;
    // Reload components list & state
    const freshlyLoaded = await DB.getTasks(currentUser);
    setTasks(freshlyLoaded);
    addSystemNotification(
      'Hộp Kế Hoạch Đã Nạp',
      `AI vừa phân tích và bóc tách thành công ${imported.length} đầu việc từ danh mục Excel mẫu của bạn.`,
      'ai'
    );
    // Redirect to Tasks board list instantly so the user sees results!
    setCurrentTab('tasks');
  };

  if (isLoading || initError) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-950 p-6 text-center">
        {!initError ? (
          <div className="flex flex-col items-center gap-4">
            <div className="w-10 h-10 border-4 border-blue-600/20 border-t-blue-600 rounded-full animate-spin" />
            <p className="text-xs text-slate-400 font-mono">Đang khởi tạo Tín Dân CRM...</p>
          </div>
        ) : (
          <div className="max-w-md bg-white dark:bg-slate-900 p-8 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800">
            <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-3">Lỗi kết nối</h2>
            <p className="text-slate-600 dark:text-slate-400 mb-6 text-sm">
              {initError}
            </p>
            <button 
              onClick={() => initData()}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold transition-colors shadow-lg shadow-blue-500/20"
            >
              Thử lại ngay
            </button>
            <p className="mt-4 text-xs text-slate-400 italic">
              Đảm bảo mạng ổn định hoặc liên hệ kỹ thuật.
            </p>
          </div>
        )}
      </div>
    );
  }

  // If embed mode is triggered (running in a customer's website iframe), bypass CRM login and render directly
  const isWidgetMode = typeof window !== 'undefined' && window.location.search.includes('view=chatbot-widget');
  if (isWidgetMode) {
    return <ChatbotWidgetFrame />;
  }

  // If session is unauthenticated, show corporate login page exclusively
  if (!currentUser) {
    return <Login onLoginSuccess={handleLoginSuccess} />;
  }

  const unreadNotificationsCount = notifications.filter(n => !n.read).length;

  return (
    <div className="min-h-screen font-sans flex flex-col lg:flex-row frosted-bg text-slate-800 dark:text-slate-100 transition-colors duration-300">
      
      {/* Sidebar & Touch Bottom layouts switcher */}
      <Navigation
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        currentUser={currentUser}
        onLogout={handleLogout}
        unreadCount={unreadNotificationsCount}
      />

      {/* Primary Workstation Scroll Canvas */}
      <main className="flex-1 overflow-y-auto pb-24 lg:pb-6 relative h-screen">
        
        {/* Highly polished, responsive corporate header for Desktop and Mobile */}
        <header className="flex justify-between items-center px-4 lg:px-8 py-3 glass-header shrink-0 border-b border-slate-200/50 dark:border-slate-800/50 flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500 glow-animation shrink-0" />
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-200 uppercase tracking-tight block text-left">
              Cổng Điều Hành CRM • Vivian System
            </span>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            {/* Realtime Status Pill */}
            <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-full text-[10px] font-medium font-mono border border-emerald-500/15">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>KẾT NỐI LIVE</span>
            </div>

            {/* Sync now button */}
            <button
              onClick={handleSyncWithCloud}
              disabled={isSyncing}
              className={`flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 dark:bg-blue-650 dark:hover:bg-blue-700 text-white rounded-lg text-xs font-semibold transition-all border border-blue-500/10 shadow-sm ${
                isSyncing ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer active:scale-95'
              }`}
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className={`h-3.5 w-3.5 ${isSyncing ? 'animate-spin' : ''}`} 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 4v5h.582m15.356 2A8.001 8.001 0 1121.21 8H18" />
              </svg>
              <span>Đồng bộ CRM</span>
            </button>

            {/* Reset/Refresh button */}
            <button
              onClick={handleResetConnection}
              disabled={isResetting}
              className={`flex items-center gap-1.5 px-3 py-1.5 bg-slate-500 hover:bg-slate-600 dark:bg-slate-700 dark:hover:bg-slate-650 text-white rounded-lg text-xs font-semibold transition-all border border-slate-400/10 shadow-sm ${
                isResetting ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer active:scale-95'
              }`}
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className={`h-3.5 w-3.5 ${isResetting ? 'animate-spin' : ''}`} 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
              </svg>
              <span>Làm mới truyền tải</span>
            </button>

            <span className="hidden lg:inline text-xs text-slate-400 font-mono pl-2 border-l border-slate-200 dark:border-slate-800">
              Sếp: <strong className="text-emerald-500 font-semibold">{currentUser.name}</strong> • {new Date().toLocaleDateString('vi-VN')}
            </span>
          </div>
        </header>

        {/* Dynamic Panel Switching routing board */}
        <div className="relative animate-fade-in">
          {currentTab === 'dashboard' && (
            <Dashboard
              currentUser={currentUser}
              onSetTab={setCurrentTab}
              tasks={tasks}
              setTasks={setTasks}
              notifications={notifications}
              setNotifications={setNotifications}
              kpis={kpis}
            />
          )}

          {currentTab === 'tasks' && (
            <Tasks
              currentUser={currentUser}
              tasks={tasks}
              setTasks={setTasks}
              projects={projects}
              comments={comments}
              setComments={setComments}
            />
          )}

          {currentTab === 'projects' && (
            <ProjectManager
              currentUser={currentUser}
              projects={projects}
              setProjects={setProjects}
            />
          )}

          {currentTab === 'excel-import' && (
            <AIImport
              currentUser={currentUser}
              onImportComplete={handleImportSuccess}
            />
          )}

          {currentTab === 'reports' && (
            <AIReports
              currentUser={currentUser}
              tasks={tasks}
              kpis={kpis}
            />
          )}

          {currentTab === 'kpis' && (
            <KPIManager
              currentUser={currentUser}
              kpis={kpis}
              setKpis={setKpis}
              onAddNotification={addSystemNotification}
            />
          )}

          {currentTab === 'assistant' && (
            <AIAssistant
              currentUser={currentUser}
              tasks={tasks}
              setTasks={setTasks}
              projects={projects}
              onRefreshData={() => {
                // Potential to reload more data here
                DB.getTasks(currentUser).then(setTasks);
              }}
            />
          )}

          {currentTab === 'duyen-chatbot' && (
            <ChatbotDuyen />
          )}

          {currentTab === 'zalo-oa' && (
            <ZaloOA />
          )}

          {currentTab === 'files' && (
            <FileCenter
              currentUser={currentUser}
            />
          )}

          {currentTab === 'users' && (
            <UserManagement />
          )}

          {currentTab === 'settings' && (
            <Settings
              currentUser={currentUser}
              themeMode={themeMode}
              setThemeMode={setThemeMode}
              onAddNotification={addSystemNotification}
              onUpdateUser={(updatedUser) => {
                setCurrentUser(updatedUser);
                DB.setCurrentUser(updatedUser);
              }}
            />
          )}
        </div>

      </main>

      <AIQuickActionBar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        currentUser={currentUser}
        tasks={tasks}
        setTasks={setTasks}
        projects={projects}
        setProjects={setProjects}
        onAddNotification={addSystemNotification}
      />
      
    </div>
  );
}
