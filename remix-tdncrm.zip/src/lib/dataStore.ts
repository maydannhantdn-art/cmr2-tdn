/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { db } from './firebase';
import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  deleteDoc,
  query,
  where,
  onSnapshot
} from 'firebase/firestore';
import { 
  User, 
  UserRole, 
  Department, 
  Task, 
  TaskPriority, 
  TaskStatus, 
  Project, 
  KPIs, 
  AISettings, 
  Notification, 
  ThemeMode, 
  TaskComment,
  TaskActivityLog,
  AiTaskAnalysis,
  TaskRiskScore,
  DailySummary,
  EmployeeWorkload
} from '../types';

// ==========================================
// CACHE MANAGEMENT & OFFLINE-FIRST RESILIENCE
// ==========================================
const getLocalCache = <T>(key: string, defaultValue: T): T => {
  try {
    const data = localStorage.getItem(`tindan_cache_${key}`);
    return data ? JSON.parse(data) : defaultValue;
  } catch (e) {
    return defaultValue;
  }
};

const setLocalCache = <T>(key: string, value: T) => {
  try {
    localStorage.setItem(`tindan_cache_${key}`, JSON.stringify(value));
  } catch (e) {
    console.warn(`LocalStorage cache update for ${key} failed:`, e);
  }
};

// Queue for tracking local-only modifications that failed syncing
const getUnsyncedIds = (table: string): string[] => {
  try {
    const data = localStorage.getItem(`tindan_unsynced_${table}`);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
};

const markAsUnsynced = (table: string, id: string) => {
  try {
    const ids = getUnsyncedIds(table);
    if (!ids.includes(id)) {
      ids.push(id);
      localStorage.setItem(`tindan_unsynced_${table}`, JSON.stringify(ids));
      console.log(`[OFFLINE CACHE] Marked ${id} as unsynced under table "${table}"`);
    }
  } catch (e) {
    console.warn(`Unsynced queue update failed for ${table}:`, e);
  }
};

const markAsSynced = (table: string, id: string) => {
  try {
    const ids = getUnsyncedIds(table);
    const filtered = ids.filter(x => x !== id);
    localStorage.setItem(`tindan_unsynced_${table}`, JSON.stringify(filtered));
  } catch (e) {
    console.warn(`Synced queue update failed for ${table}:`, e);
  }
};

// ==========================================
// FILTER UTILITIES (CORRECTED COOPERATIVE MODE)
// ==========================================
const filterTasks = (allTasks: Task[], user: User): Task[] => {
  // Super Admin, Admin, and Manager should see all tasks across all departments to facilitate monitoring
  if (user.role === UserRole.SUPER_ADMIN || user.role === UserRole.ADMIN || user.role === UserRole.MANAGER) {
    return allTasks;
  }
  // Employees see tasks of their department or tasks they are directly involved in (creator, assignee, or followers)
  let results = allTasks.filter(t => t.department === user.department);
  const employeeTasks = allTasks.filter(t => t.createdBy === user.id || t.assignee === user.name);
  const seen = new Set(results.map(t => t.id));
  employeeTasks.forEach(t => {
    if (!seen.has(t.id)) {
      results.push(t);
      seen.add(t.id);
    }
  });
  return results;
};

const filterProjects = (allProjects: Project[], user: User): Project[] => {
  if (user.role === UserRole.SUPER_ADMIN || user.role === UserRole.ADMIN || user.role === UserRole.MANAGER) {
    return allProjects;
  }
  return allProjects.filter(p => p.department === user.department);
};

const filterKPIs = (allKPIs: KPIs[], user: User): KPIs[] => {
  if (user.role === UserRole.SUPER_ADMIN || user.role === UserRole.ADMIN || user.role === UserRole.MANAGER) {
    return allKPIs;
  }
  return allKPIs.filter(k => k.department === user.department);
};

const filterNotifications = (allNotifications: Notification[], user: User): Notification[] => {
  if (user.role === UserRole.SUPER_ADMIN || user.role === UserRole.ADMIN || user.role === UserRole.MANAGER) {
    return allNotifications;
  }
  return allNotifications.filter(n => n.department === user.department);
};

// ==========================================
// RESILIENT FIRESTORE CRUD HELPERS WITH TIMEOUTS
// ==========================================
// ==========================================
// RESILIENT FIRESTORE CRUD HELPERS (INSTANT OFFLINE-FIRST RESPONSE WITH BACKGROUND CLOUD SYNC)
// ==========================================
const safeGet = async (collectionName: string, fallbackKey: string): Promise<any[]> => {
  // 1. Instantly read from local cache so the UI never blocks or lags (0ms latency!)
  const localItems = getLocalCache<any[]>(fallbackKey, []);
  
  // 2. Spawn silent background sync in the background
  (async () => {
    try {
      const colRef = collection(db, collectionName);
      // Let Firestore's native client handle network timeouts and offline cache caching
      const querySnapshot = await getDocs(colRef);
      
      const fetchedItems: any[] = [];
      querySnapshot.forEach((doc) => {
        fetchedItems.push({ id: doc.id, ...doc.data() });
      });

      const unsyncedIds = getUnsyncedIds(collectionName);
      const mergedMap = new Map<string, any>();
      
      for (const item of fetchedItems) {
        if (item.id) {
          mergedMap.set(item.id, item);
        }
      }
      
      for (const item of localItems) {
        if (item.id && unsyncedIds.includes(item.id)) {
          mergedMap.set(item.id, item);
        }
      }
      
      const merged = Array.from(mergedMap.values());
      setLocalCache(fallbackKey, merged);
    } catch {
      // Fail silently in the background. Firestore SDK will retry autonomously.
    }
  })();

  return localItems;
};

const safeWrite = async (collectionName: string, item: any): Promise<boolean> => {
  if (!item || !item.id) return false;
  // 1. Immediately cache the item locally
  const current = getLocalCache<any[]>(collectionName === 'comments' ? 'comments' : collectionName, []);
  const idx = current.findIndex((x: any) => x.id === item.id);
  if (idx > -1) {
    current[idx] = item;
  } else {
    current.push(item);
  }
  setLocalCache(collectionName === 'comments' ? 'comments' : collectionName, current);
  
  // 2. Attempt background upload to cloud database
  try {
    const docRef = doc(db, collectionName, item.id);
    await setDoc(docRef, item, { merge: true });
    markAsSynced(collectionName, item.id);
    return true;
  } catch (err) {
    // If offline, queue for background sync and return success locally
    markAsUnsynced(collectionName, item.id);
    return false;
  }
};

const safeDelete = async (collectionName: string, id: string): Promise<void> => {
  // 1. Immediately remove from local cache
  const current = getLocalCache<any[]>(collectionName === 'comments' ? 'comments' : collectionName, []);
  const updated = current.filter((x: any) => x.id !== id);
  setLocalCache(collectionName === 'comments' ? 'comments' : collectionName, updated);

  // 2. Perform background cloud deletion
  try {
    await deleteDoc(doc(db, collectionName, id));
    markAsSynced(collectionName, id);
  } catch {
    // Silent handling
    markAsSynced(collectionName, id);
  }
};

// ==========================================
// CRM DATABASE MAIN INTERFACE (FIREBASE-POWERED)
// ==========================================
export const DB = {
  seedLocalIfSterile: (seedUsers: User[], seedProjects: Project[], seedTasks: Task[], seedKPIs: KPIs[]) => {
    try {
      if (getLocalCache<User[]>('users', []).length === 0) {
        setLocalCache('users', seedUsers);
      }
      if (getLocalCache<Project[]>('projects', []).length === 0) {
        setLocalCache('projects', seedProjects);
      }
      if (getLocalCache<Task[]>('tasks', []).length === 0) {
        setLocalCache('tasks', seedTasks);
      }
      if (getLocalCache<KPIs[]>('kpis', []).length === 0) {
        setLocalCache('kpis', seedKPIs);
      }
    } catch (e) {
      console.warn("Storage seeding warning:", e);
    }
  },
  // USERS
  getUsers: async (): Promise<User[]> => {
    return safeGet('users', 'users');
  },
  saveUser: async (user: User) => {
    await safeWrite('users', user);
    
    // Synchronize local fallback cache
    const users = getLocalCache<User[]>('users', []);
    const idx = users.findIndex(u => u.id === user.id);
    if (idx > -1) {
      users[idx] = user;
    } else {
      users.push(user);
    }
    setLocalCache('users', users);
  },
  updateUser: async (userId: string, updates: Partial<User>) => {
    try {
      const docRef = doc(db, 'users', userId);
      await setDoc(docRef, updates, { merge: true });
    } catch (err) {
      console.warn(`[FIREBASE] Update user caught exception:`, err);
    }
    
    // Synchronize local cache
    const users = getLocalCache<User[]>('users', []);
    const idx = users.findIndex(u => u.id === userId);
    if (idx > -1) {
      users[idx] = { ...users[idx], ...updates };
      setLocalCache('users', users);
    }
  },
  deleteUser: async (userId: string) => {
    await safeDelete('users', userId);
    
    const users = getLocalCache<User[]>('users', []);
    const updated = users.filter(u => u.id !== userId);
    setLocalCache('users', updated);
  },

  // CURRENT LOGGED IN USER
  getCurrentUser: (): User | null => {
    const saved = localStorage.getItem('tindan_crm_current_user');
    return saved ? JSON.parse(saved) : null;
  },
  setCurrentUser: (user: User | null) => {
    if (user) {
      localStorage.setItem('tindan_crm_current_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('tindan_crm_current_user');
    }
  },

  // IMMEDIATE SYNCHRONOUS CACHE GETTERS FOR LIQUID SPEED UI
  getCachedUsers: (): User[] => {
    return getLocalCache<User[]>('users', []);
  },
  getCachedTasks: (user: User): Task[] => {
    const cached = getLocalCache<Task[]>('tasks', []);
    return filterTasks(cached, user);
  },
  getCachedProjects: (user: User): Project[] => {
    const cached = getLocalCache<Project[]>('projects', []);
    return filterProjects(cached, user);
  },
  getCachedNotifications: (user: User): Notification[] => {
    const cached = getLocalCache<Notification[]>('notifications', []);
    return filterNotifications(cached, user);
  },
  getCachedKPIs: (user: User): KPIs[] => {
    const cached = getLocalCache<KPIs[]>('kpis', []);
    return filterKPIs(cached, user);
  },

  // TASKS (REAL-TIME ACTIVE CONGESTION-FREE SYNC)
  getTasks: async (user: User): Promise<Task[]> => {
    const dbTasks = await safeGet('tasks', 'tasks');
    return filterTasks(dbTasks, user);
  },
  subscribeToTasks: (user: User, onUpdate: (tasks: Task[]) => void): (() => void) => {
    const colRef = collection(db, 'tasks');
    const unsubscribe = onSnapshot(colRef, (snapshot) => {
      const fetchedTasks: Task[] = [];
      snapshot.forEach((snap) => {
        fetchedTasks.push({ id: snap.id, ...snap.data() } as Task);
      });
      setLocalCache('tasks', fetchedTasks);
      onUpdate(filterTasks(fetchedTasks, user));
    }, () => {
      onUpdate(DB.getCachedTasks(user));
    });
    onUpdate(DB.getCachedTasks(user));
    return unsubscribe;
  },

  // REAL-TIME PROJECTS SUBSCRIPTION
  subscribeToProjects: (user: User, onUpdate: (projects: Project[]) => void): (() => void) => {
    const colRef = collection(db, 'projects');
    const unsubscribe = onSnapshot(colRef, (snapshot) => {
      const fetched: Project[] = [];
      snapshot.forEach((snap) => {
        fetched.push({ id: snap.id, ...snap.data() } as Project);
      });
      setLocalCache('projects', fetched);
      onUpdate(filterProjects(fetched, user));
    }, () => {
      onUpdate(DB.getCachedProjects(user));
    });
    onUpdate(DB.getCachedProjects(user));
    return unsubscribe;
  },

  // REAL-TIME NOTIFICATIONS SUBSCRIPTION
  subscribeToNotifications: (user: User, onUpdate: (notifications: Notification[]) => void): (() => void) => {
    const colRef = collection(db, 'notifications');
    const unsubscribe = onSnapshot(colRef, (snapshot) => {
      const fetched: Notification[] = [];
      snapshot.forEach((snap) => {
        fetched.push({ id: snap.id, ...snap.data() } as Notification);
      });
      setLocalCache('notifications', fetched);
      onUpdate(filterNotifications(fetched, user));
    }, () => {
      onUpdate(DB.getCachedNotifications(user));
    });
    onUpdate(DB.getCachedNotifications(user));
    return unsubscribe;
  },

  // REAL-TIME KPIS SUBSCRIPTION
  subscribeToKPIs: (user: User, onUpdate: (kpis: KPIs[]) => void): (() => void) => {
    const colRef = collection(db, 'kpis');
    const unsubscribe = onSnapshot(colRef, (snapshot) => {
      const fetched: KPIs[] = [];
      snapshot.forEach((snap) => {
        fetched.push({ id: snap.id, ...snap.data() } as KPIs);
      });
      setLocalCache('kpis', fetched);
      onUpdate(filterKPIs(fetched, user));
    }, () => {
      onUpdate(DB.getCachedKPIs(user));
    });
    onUpdate(DB.getCachedKPIs(user));
    return unsubscribe;
  },

  // REAL-TIME USERS SUBSCRIPTION
  subscribeToUsers: (onUpdate: (users: User[]) => void): (() => void) => {
    const colRef = collection(db, 'users');
    const unsubscribe = onSnapshot(colRef, (snapshot) => {
      const fetched: User[] = [];
      snapshot.forEach((snap) => {
        fetched.push({ id: snap.id, ...snap.data() } as User);
      });
      setLocalCache('users', fetched);
      onUpdate(fetched);
    }, () => {
      onUpdate(getLocalCache<User[]>('users', []));
    });
    onUpdate(getLocalCache<User[]>('users', []));
    return unsubscribe;
  },

  // REAL-TIME ACTIVITY LOGS SUBSCRIPTION
  subscribeToActivityLogs: (onUpdate: (logs: TaskActivityLog[]) => void): (() => void) => {
    const colRef = collection(db, 'activity_logs');
    const unsubscribe = onSnapshot(colRef, (snapshot) => {
      const fetched: TaskActivityLog[] = [];
      snapshot.forEach((snap) => {
        fetched.push({ id: snap.id, ...snap.data() } as TaskActivityLog);
      });
      setLocalCache('activity_logs', fetched);
      onUpdate(fetched);
    }, () => {
      onUpdate(getLocalCache<TaskActivityLog[]>('activity_logs', []));
    });
    onUpdate(getLocalCache<TaskActivityLog[]>('activity_logs', []));
    return unsubscribe;
  },

  // REAL-TIME EMPLOYEE WORKLOADS SUBSCRIPTION
  subscribeToEmployeeWorkloads: (onUpdate: (workloads: EmployeeWorkload[]) => void): (() => void) => {
    const colRef = collection(db, 'employee_workload');
    const unsubscribe = onSnapshot(colRef, (snapshot) => {
      const fetched: EmployeeWorkload[] = [];
      snapshot.forEach((snap) => {
        fetched.push({ id: snap.id, ...snap.data() } as EmployeeWorkload);
      });
      setLocalCache('employee_workload', fetched);
      onUpdate(fetched);
    }, () => {
      onUpdate(getLocalCache<EmployeeWorkload[]>('employee_workload', []));
    });
    onUpdate(getLocalCache<EmployeeWorkload[]>('employee_workload', []));
    return unsubscribe;
  },

  // REAL-TIME TASK RISK SCORES SUBSCRIPTION
  subscribeToTaskRiskScores: (onUpdate: (scores: TaskRiskScore[]) => void): (() => void) => {
    const colRef = collection(db, 'task_risk_scores');
    const unsubscribe = onSnapshot(colRef, (snapshot) => {
      const fetched: TaskRiskScore[] = [];
      snapshot.forEach((snap) => {
        fetched.push({ id: snap.id, ...snap.data() } as TaskRiskScore);
      });
      setLocalCache('task_risk_scores', fetched);
      onUpdate(fetched);
    }, () => {
      onUpdate(getLocalCache<TaskRiskScore[]>('task_risk_scores', []));
    });
    onUpdate(getLocalCache<TaskRiskScore[]>('task_risk_scores', []));
    return unsubscribe;
  },

  // REAL-TIME AI KPI LOGS SUBSCRIPTION
  subscribeToAiKpiLogs: (onUpdate: (logs: any[]) => void): (() => void) => {
    const colRef = collection(db, 'ai_kpi_logs');
    const unsubscribe = onSnapshot(colRef, (snapshot) => {
      const fetched: any[] = [];
      snapshot.forEach((snap) => {
        fetched.push({ id: snap.id, ...snap.data() });
      });
      setLocalCache('ai_kpi_logs', fetched);
      onUpdate(fetched);
    }, () => {
      onUpdate(getLocalCache<any[]>('ai_kpi_logs', []));
    });
    onUpdate(getLocalCache<any[]>('ai_kpi_logs', []));
    return unsubscribe;
  },
  saveTask: async (task: Task) => {
    if (!task.createdAt) task.createdAt = new Date().toISOString();
    await safeWrite('tasks', task);

    // Sync state cache
    const current = getLocalCache<Task[]>('tasks', []);
    const idx = current.findIndex(t => t.id === task.id);
    if (idx > -1) {
      current[idx] = task;
    } else {
      current.push(task);
    }
    setLocalCache('tasks', current);
  },
  saveTasks: async (tasksList: Task[]) => {
    for (const task of tasksList) {
      await DB.saveTask(task);
    }
  },
  deleteTask: async (taskId: string) => {
    await safeDelete('tasks', taskId);

    const current = getLocalCache<Task[]>('tasks', []);
    const updated = current.filter(t => t.id !== taskId);
    setLocalCache('tasks', updated);
  },

  // PROJECTS
  getProjects: async (user: User): Promise<Project[]> => {
    const dbProjects = await safeGet('projects', 'projects');
    return filterProjects(dbProjects, user);
  },
  saveProjects: async (projectsList: Project[]) => {
    for (const project of projectsList) {
      await safeWrite('projects', project);
    }
    
    const current = getLocalCache<Project[]>('projects', []);
    for (const p of projectsList) {
      const idx = current.findIndex(x => x.id === p.id);
      if (idx > -1) {
        current[idx] = p;
      } else {
        current.push(p);
      }
    }
    setLocalCache('projects', current);
  },

  // COMMENTS
  getComments: async (taskId: string): Promise<TaskComment[]> => {
    // 1. Instantly read comments from local cache (0ms speed!)
    const localComments = getLocalCache<TaskComment[]>('comments', []).filter(c => c.taskId === taskId);
    
    // 2. Query Firestore quietly in background to refresh local memory
    (async () => {
      try {
        const colRef = collection(db, 'comments');
        const q = query(colRef, where('taskId', '==', taskId));
        const querySnapshot = await getDocs(q);
        
        const fetched: TaskComment[] = [];
        querySnapshot.forEach((doc) => {
          fetched.push({ id: doc.id, ...doc.data() } as TaskComment);
        });
        
        fetched.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
        
        const currentComments = getLocalCache<TaskComment[]>('comments', []);
        
        // Update elements
        for (const item of fetched) {
          const idx = currentComments.findIndex(c => c.id === item.id);
          if (idx > -1) {
            currentComments[idx] = item;
          } else {
            currentComments.push(item);
          }
        }
        setLocalCache('comments', currentComments);
      } catch {
        // Quiet background catch
      }
    })();

    // Chronological sorting on cache response
    localComments.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    return localComments;
  },
  saveComments: async (commentsList: TaskComment[]) => {
    for (const comment of commentsList) {
      await safeWrite('comments', comment);
    }

    const current = getLocalCache<TaskComment[]>('comments', []);
    for (const c of commentsList) {
      const idx = current.findIndex(x => x.id === c.id);
      if (idx > -1) {
        current[idx] = c;
      } else {
        current.push(c);
      }
    }
    setLocalCache('comments', current);
  },

  // NOTIFICATIONS
  getNotifications: async (user: User): Promise<Notification[]> => {
    const dbNotifications = await safeGet('notifications', 'notifications');
    return filterNotifications(dbNotifications, user);
  },
  saveNotifications: async (notificationsList: Notification[]) => {
    for (const n of notificationsList) {
      await safeWrite('notifications', n);
    }

    const current = getLocalCache<Notification[]>('notifications', []);
    for (const n of notificationsList) {
      const idx = current.findIndex(x => x.id === n.id);
      if (idx > -1) {
        current[idx] = n;
      } else {
        current.push(n);
      }
    }
    setLocalCache('notifications', current);
  },

  // KPIs
  getKPIs: async (user: User): Promise<KPIs[]> => {
    const dbKPIs = await safeGet('kpis', 'kpis');
    return filterKPIs(dbKPIs, user);
  },
  saveKPIs: async (kpisList: KPIs[]) => {
    for (const k of kpisList) {
      await safeWrite('kpis', k);
    }

    const current = getLocalCache<KPIs[]>('kpis', []);
    for (const k of kpisList) {
      const idx = current.findIndex(x => x.id === k.id);
      if (idx > -1) {
        current[idx] = k;
      } else {
        current.push(k);
      }
    }
    setLocalCache('kpis', current);
  },

  // ACTIVITY LOGS
  getActivityLogs: async (): Promise<TaskActivityLog[]> => {
    return safeGet('activity_logs', 'activity_logs');
  },
  saveActivityLogs: async (logsList: TaskActivityLog[]) => {
    for (const log of logsList) {
      await safeWrite('activity_logs', log);
    }

    const current = getLocalCache<TaskActivityLog[]>('activity_logs', []);
    for (const l of logsList) {
      const idx = current.findIndex(x => x.id === l.id);
      if (idx > -1) {
        current[idx] = l;
      } else {
        current.push(l);
      }
    }
    setLocalCache('activity_logs', current);
  },

  // AI TASK RECOGNITION
  getTaskAnalyses: async (): Promise<AiTaskAnalysis[]> => {
    return safeGet('task_analysis', 'task_analysis');
  },
  saveTaskAnalyses: async (analyses: AiTaskAnalysis[]) => {
    for (const a of analyses) {
      await safeWrite('task_analysis', a);
    }
    
    const current = getLocalCache<AiTaskAnalysis[]>('task_analysis', []);
    for (const a of analyses) {
      const idx = current.findIndex(x => x.id === a.id);
      if (idx > -1) {
        current[idx] = a;
      } else {
        current.push(a);
      }
    }
    setLocalCache('task_analysis', current);
  },

  // RISK ASSESSMENT
  getTaskRiskScores: async (): Promise<TaskRiskScore[]> => {
    return safeGet('task_risk_scores', 'task_risk_scores');
  },
  saveTaskRiskScores: async (scores: TaskRiskScore[]) => {
    for (const s of scores) {
      await safeWrite('task_risk_scores', s);
    }
    
    const current = getLocalCache<TaskRiskScore[]>('task_risk_scores', []);
    for (const s of scores) {
      const idx = current.findIndex(x => x.id === s.id);
      if (idx > -1) {
        current[idx] = s;
      } else {
        current.push(s);
      }
    }
    setLocalCache('task_risk_scores', current);
  },

  // DAILY SUMMARIES
  getDailySummaries: async (): Promise<DailySummary[]> => {
    return safeGet('daily_summaries', 'daily_summaries');
  },
  saveDailySummaries: async (sums: DailySummary[]) => {
    for (const s of sums) {
      await safeWrite('daily_summaries', s);
    }
    
    const current = getLocalCache<DailySummary[]>('daily_summaries', []);
    for (const s of sums) {
      const idx = current.findIndex(x => x.id === s.id);
      if (idx > -1) {
        current[idx] = s;
      } else {
        current.push(s);
      }
    }
    setLocalCache('daily_summaries', current);
  },

  getAiKpiLogs: async (): Promise<any[]> => {
    return safeGet('ai_kpi_logs', 'ai_kpi_logs');
  },

  // EMPLOYEE WORKLOAD
  getEmployeeWorkloads: async (): Promise<EmployeeWorkload[]> => {
    return safeGet('employee_workload', 'employee_workload');
  },
  saveEmployeeWorkloads: async (workloads: EmployeeWorkload[]) => {
    for (const w of workloads) {
      await safeWrite('employee_workload', w);
    }
    
    const current = getLocalCache<EmployeeWorkload[]>('employee_workload', []);
    for (const w of workloads) {
      const idx = current.findIndex(x => x.id === w.id);
      if (idx > -1) {
        current[idx] = w;
      } else {
        current.push(w);
      }
    }
    setLocalCache('employee_workload', current);
  },

  // CHAT HISTORY
  getChatHistory: async (userId: string): Promise<any[]> => {
    const localHistory = getLocalCache<any[]>(`chat_history_${userId}`, []);
    
    (async () => {
      try {
        const colRef = collection(db, 'chat_history');
        const q = query(colRef, where('userId', '==', userId));
        const querySnapshot = await getDocs(q);
        const fetched: any[] = [];
        querySnapshot.forEach((doc) => {
          fetched.push({ id: doc.id, ...doc.data() });
        });
        fetched.sort((a: any, b: any) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
        setLocalCache(`chat_history_${userId}`, fetched);
      } catch {
        // Quiet background catch
      }
    })();

    localHistory.sort((a: any, b: any) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    return localHistory;
  },
  saveChatHistory: async (userId: string, messagesList: any[]) => {
    try {
      for (const msg of messagesList) {
        await safeWrite('chat_history', { ...msg, userId });
      }
    } catch (e) {
      console.log('[FIREBASE] Failed to save chat history silently:', e);
    }
    setLocalCache(`chat_history_${userId}`, messagesList);
  },

  // CHATBOT DUYÊN CONFIGS & LEADS
  getDuyenConfig: async (): Promise<any> => {
    const defaultVal = {
      id: 'default_config',
      botName: 'Duyên AI Chăm Sóc Tự Động',
      greeting: 'Xin chào! Em là trợ lý ảo Duyên của doanh nghiệp Tín Dân. Em có thể tư vấn gì về kỹ thuật in decal tem cuộn cho quý khách ạ?',
      systemPrompt: 'Bạn là tư vấn viên cao cấp của Tín Dân Company. Chỉ trả lời trọng tâm về kỹ thuật in decal bảo ôn mác dán sản xuất UV và các quy chuẩn Vivian, không nói lan man lan sang chủ đề phát sinh khác.',
      primaryColor: '#2563eb',
      layout: 'bottom_right', 
      avatar: '👩‍💼',
      hotlineEnabled: true,
      hotline: '0903810082',
      knowledgeBase: 'Tín Dân in tem cuộn dán nhãn decal bảo ôn Vivian, áp dụng lò sấy UV công suất lớn, độ hoàn thiện tinh xảo...'
    };
    const cached = getLocalCache<any>('chatbot_duyen_config', defaultVal);

    (async () => {
      try {
        const colRef = collection(db, 'chatbot_duyen_config');
        const querySnapshot = await getDocs(colRef);
        if (!querySnapshot.empty) {
          const data: any[] = [];
          querySnapshot.forEach((doc) => {
            data.push({ id: doc.id, ...doc.data() });
          });
          setLocalCache('chatbot_duyen_config', data[0]);
        }
      } catch {
        // Quiet background catch
      }
    })();

    return cached;
  },
  saveDuyenConfig: async (config: any) => {
    await safeWrite('chatbot_duyen_config', config);
    setLocalCache('chatbot_duyen_config', config);
  },

  getDuyenLeads: async (): Promise<any[]> => {
    return safeGet('chatbot_duyen_leads', 'chatbot_duyen_leads');
  },
  saveDuyenLead: async (lead: any) => {
    await safeWrite('chatbot_duyen_leads', lead);
    
    const current = getLocalCache<any[]>('chatbot_duyen_leads', []);
    const idx = current.findIndex(x => x.id === lead.id);
    if (idx > -1) {
      current[idx] = lead;
    } else {
      current.unshift(lead);
    }
    setLocalCache('chatbot_duyen_leads', current);
  },

  // ZALO INTEGRATION
  getZaloOaConfig: async (): Promise<any> => {
    const defaultVal = {
      id: 'default_zalo_oa',
      appId: '',
      secretKey: '',
      oaId: '',
      accessToken: '',
      refreshToken: '',
      isLinked: false,
      oaName: 'Chưa liên kết',
      avatar: ''
    };
    const cached = getLocalCache<any>('zalo_oa_config', defaultVal);

    (async () => {
      try {
        const colRef = collection(db, 'zalo_oa_config');
        const querySnapshot = await getDocs(colRef);
        if (!querySnapshot.empty) {
          const data: any[] = [];
          querySnapshot.forEach((doc) => {
            data.push({ id: doc.id, ...doc.data() });
          });
          setLocalCache('zalo_oa_config', data[0]);
        }
      } catch {
        // Quiet background catch
      }
    })();

    return cached;
  },
  saveZaloOaConfig: async (config: any) => {
    await safeWrite('zalo_oa_config', config);
    setLocalCache('zalo_oa_config', config);
  },

  // CONTINUOUS SYSTEM STATE BACKUP
  runContinuousBackup: async (allData: {
    tasks: any[];
    projects: any[];
    users: any[];
    kpis: any[];
  }): Promise<{ success: boolean; timestamp: string }> => {
    const timestamp = new Date().toISOString();
    try {
      setLocalCache('latest_state_backup', {
        timestamp,
        tasksCount: allData.tasks.length,
        projectsCount: allData.projects.length,
        usersCount: allData.users.length,
        kpisCount: allData.kpis.length,
        payload: {
          tasks: allData.tasks,
          projects: allData.projects,
          users: allData.users,
          kpis: allData.kpis
        }
      });
      return { success: true, timestamp };
    } catch (error) {
      return { success: false, timestamp };
    }
  },

  // OFFLINE SYNC METHODS
  getUnsyncedCount: (): number => {
    const tables = ['tasks', 'projects', 'kpis', 'comments', 'notifications', 'users'];
    let count = 0;
    for (const table of tables) {
      count += getUnsyncedIds(table).length;
    }
    return count;
  },

  syncUnsyncedItems: async (): Promise<{ successCount: number; failedCount: number; failedSummary: string[] }> => {
    const tables = ['tasks', 'projects', 'kpis', 'comments', 'notifications', 'users'];
    let successCount = 0;
    let failedCount = 0;
    const failedSummary: string[] = [];

    for (const table of tables) {
      const unsyncedIds = getUnsyncedIds(table);
      if (unsyncedIds.length === 0) continue;

      const fallbackKey = table === 'comments' ? 'comments' : table;
      const cached = getLocalCache<any[]>(fallbackKey, []);

      for (const id of unsyncedIds) {
        const item = cached.find(x => x.id === id);
        if (item) {
          const success = await safeWrite(table, item);
          if (success) {
            successCount++;
          } else {
            failedCount++;
            if (!failedSummary.includes(table)) {
              failedSummary.push(table);
            }
          }
        } else {
          // Remove from local sync queue if deleted/missing from cache
          markAsSynced(table, id);
        }
      }
    }

    return { successCount, failedCount, failedSummary };
  },

  // HEALTH CHECK - DIRECT LIVE CONNECTION VERIFICATION
  testFirestoreConnection: async (): Promise<{ success: boolean; message: string; latencyMs?: number }> => {
    const testId = 'test_' + Date.now();
    const startTime = Date.now();
    const localTimeout = (ms: number) => new Promise<any>((_, reject) => setTimeout(() => reject(new Error('TIMEOUT')), ms));
    
    try {
      const testDocRef = doc(db, 'system_debug_tests', testId);
      await Promise.race([
        setDoc(testDocRef, {
          id: testId,
          agent: 'Tín Dân AI Super CRM Verification',
          timestamp: new Date().toISOString(),
          status: 'verifying'
        }),
        localTimeout(4000)
      ]);
      
      const fetched = await Promise.race([
        getDoc(testDocRef),
        localTimeout(4000)
      ]);
      const latency = Date.now() - startTime;
      
      try {
        await deleteDoc(testDocRef);
      } catch {}
 
      if (fetched.exists()) {
        return {
          success: true,
          message: `Kết nối thành công! Đã ghi và đọc ngược dữ liệu thành công từ Firebase Firestore đám mây Tín Dân của Sếp.`,
          latencyMs: latency
        };
      } else {
        return {
          success: false,
          message: `Thất bại! Ghi bản ghi thử nghiệm thành công nhưng không thể đọc ngược dữ liệu từ Firebase Firestore.`
        };
      }
    } catch (error: any) {
      return {
        success: false,
        message: `Lỗi kết nối Firebase Firestore: ${error.message || error}`
      };
    }
  }
};
