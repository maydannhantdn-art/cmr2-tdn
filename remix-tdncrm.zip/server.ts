/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import Groq from 'groq-sdk';
import { GoogleGenAI } from '@google/genai';
import { initializeApp } from 'firebase/app';
import { initializeFirestore, collection, doc, getDocs, setDoc, query } from 'firebase/firestore';
import fs from 'fs';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize Firestore Client in backend safely
let db: any = null;
try {
  const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
  if (fs.existsSync(configPath)) {
    const firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    const firebaseApp = initializeApp(firebaseConfig);
    db = initializeFirestore(firebaseApp, {
      experimentalForceLongPolling: true,
    }, firebaseConfig.firestoreDatabaseId);
    console.log("Successfully initialized Firebase Client in Express Server.");
  }
} catch (err) {
  console.error("Backend Firebase Initialization Error:", err);
}

// Initialize Gemini Client
const geminiKey = process.env.GEMINI_API_KEY;
let genAI: GoogleGenAI | null = null;
if (geminiKey) {
  genAI = new GoogleGenAI({ apiKey: geminiKey });
  console.log("Successfully initialized Gemini AI Client.");
}

// Initialize Groq SDK
const groqKey = process.env.GROQ_API_KEY;
let groq: Groq | null = null;

if (groqKey) {
  groq = new Groq({ apiKey: groqKey });
  console.log("Successfully initialized Groq AI Client.");
} else {
  console.log("Groq API key is not set. AI features will operate in Simulation Mode.");
}

// ==========================================
// API ROOTS
// ==========================================

// 1. AI Parse Excel / CSV Plan
app.post('/api/ai/parse-excel', async (req, res) => {
  const { data, engine = 'gemini' } = req.body; 

  if (!data || !Array.isArray(data) || data.length === 0) {
    return res.status(400).json({ success: false, message: 'Dữ liệu đầu vào không hợp lệ hoặc trống.' });
  }

  const payloadString = JSON.stringify(data);
  const prompt = `Hãy phân tích ma trận dữ liệu sau được import từ file Excel:
${payloadString}

Hãy lọc ra các công việc, tính toán 'overdueRisk', tính điểm KPI (5-30), tạo checklist (2-3 gạch đầu dòng).
Trả về JSON structure: { confidenceScore: number, tasks: [{ projectName, planMonth, planWeek, title, description, assignee, department, priority, deadline, kpiScore, checklist: string[] }] }`;

  // Try Gemini 
  if (engine === 'gemini' && genAI) {
    try {
      const response = await genAI.models.generateContent({ 
        model: "gemini-2.5-flash-lite",
        contents: prompt,
        config: { 
          responseMimeType: "application/json" 
        }
      });
      return res.json({ success: true, aiGenerated: true, parsed: JSON.parse(response.text || '{}'), provider: 'gemini' });
    } catch (err) {
      console.warn("⚠️ ERROR: Gemini parse error, switching to Groq as backup:", err);
    }
  }

  if (groq) {
    try {
      const completion = await groq.chat.completions.create({
        messages: [
          {
            role: "system",
            content: "Bạn là trợ lý AI thông minh tích hợp trên Tín Dân CRM. Phản hồi luôn trả về định dạng JSON."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        model: "llama-3.3-70b-versatile",
        response_format: { type: "json_object" }
      });

      const responseText = completion.choices[0].message.content || '{}';
      return res.json({ success: true, aiGenerated: true, parsed: JSON.parse(responseText), provider: 'groq' });
    } catch (error: any) {
      console.error("❌ ERROR: Both Gemini and Groq parse failed:", error);
    }
  }

  // Fallback Simulation
  const mockTasks = (data.slice(1)).map((row, i) => ({
    projectName: row[0] || 'Dự án Tín Dân',
    planMonth: 'Tháng 6',
    planWeek: 'Tuần 2',
    title: row[1] || 'Công việc ' + (i + 1),
    description: row[2] || 'Mô tả chi tiết',
    assignee: row[3] || 'Nguyễn Văn Nam',
    department: 'Marketing',
    priority: 'Medium',
    deadline: '2026-06-15',
    kpiScore: 10,
    checklist: ['Bước 1', 'Bước 2']
  }));

  res.json({ success: true, aiGenerated: false, parsed: { confidenceScore: 0.9, tasks: mockTasks }, provider: 'simulation_fallback' });
});

// 2. AI Reports
app.post('/api/ai/generate-summary', async (req, res) => {
  const { tasks, kpis, reportType = 'weekly', engine = 'gemini' } = req.body;

  const prompt = `Bạn là Trưởng bộ phận Chiến lược của công ty Tín Dân. 
Viết báo cáo hiệu suất cho dữ liệu sau: Tasks: ${JSON.stringify(tasks)}, KPIs: ${JSON.stringify(kpis)}.
ĐỊNH DẠNG: Văn bản thuần (No Markdown), Xuống dòng bằng Enter. 
BẮT ĐẦU: TÍN DÂN COMPANY - ${reportType.toUpperCase()} REPORT...`;

  if (engine === 'gemini' && genAI) {
    try {
      const response = await genAI.models.generateContent({ 
        model: "gemini-2.5-flash-lite",
        contents: prompt
      });
      return res.json({ success: true, aiGenerated: true, summary: (response.text || "").trim(), provider: 'gemini' });
    } catch (err) {
      console.warn("⚠️ ERROR: Gemini summary error, switching to Groq as backup:", err);
    }
  }

  if (groq) {
    try {
      const completion = await groq.chat.completions.create({
        messages: [{ role: "user", content: prompt }],
        model: "llama-3.3-70b-versatile",
      });

      let cleanText = completion.choices[0].message.content || '';
      return res.json({ success: true, aiGenerated: true, summary: cleanText.trim(), provider: 'groq' });
    } catch (err) {
      console.error("❌ ERROR: Both Gemini and Groq summary generation failed:", err);
    }
  }

  res.json({ success: true, aiGenerated: false, summary: "Simulation Report Data...", provider: 'simulation_fallback' });
});

// 3. AI Assistant Chat (with Function Calling)
app.post('/api/ai/chat', async (req, res) => {
  const { messages, currentDataState, engine = 'groq' } = req.body;

  const systemInstruction = `BẠN LÀ HỆ ĐIỀU HÀNH AI TỐI CAO (HOS-vX) CỦA CÔNG TY TÍN DÂN.
QUYỀN HẠN: TOÀN QUYỀN CAN THIỆP VÀO DATABASE QUA TOOLS.
DỮ LIỆU: Users: ${JSON.stringify(currentDataState?.users || [])}, Tasks: ${JSON.stringify(currentDataState?.tasks || [])}.
QUY TẮC PHÂN BIỆT NHIỆM VỤ VS TÀI KHOẢN (RẤT QUAN TRỌNG):
- Khi sếp yêu cầu tạo hay xóa TÀI KHOẢN / CÁ NHÂN / THÀNH VIÊN / NHÂN VIÊN, bạn PHẢI dùng các công cụ liên quan đến USER (create_user, delete_user). TUYỆT ĐỐI không gọi tool liên quan đến TASK.
- Khi sếp yêu cầu tạo hay xóa NHIỆM VỤ / CÔNG VIỆC, bạn PHẢI dùng các công cụ liên quan đến TASK (create_task, delete_task). TUYỆT ĐỐI không gọi tool liên quan đến USER.
- Phản hồi văn bản thuần, không markdown. Hành động > Lời nói. PHẢI CÓ CHECKLIST KHI TẠO TASK.`;

  // 1. Logic for Gemini (Primary for "Gemini 3 Flash" request)
  if (engine === 'gemini' && genAI) {
    try {
      const geminiTools: any[] = [
        {
          functionDeclarations: [
            {
              name: "create_task",
              description: "Tạo nhiệm vụ (công việc, task) mới cho nhân viên. KHÔNG gọi tool này khi sếp yêu cầu tạo tài khoản / nhân viên mới.",
              parameters: {
                type: "OBJECT",
                properties: {
                  title: { type: "STRING" },
                  description: { type: "STRING" },
                  assignee: { type: "STRING" },
                  department: { type: "STRING" },
                  deadline: { type: "STRING" },
                  priority: { type: "STRING", enum: ["Low", "Medium", "High"] },
                  kpiScore: { type: "NUMBER" },
                  followers: { type: "ARRAY", items: { type: "STRING" } },
                  checklist: { type: "ARRAY", items: { type: "STRING" } }
                },
                required: ["title", "assignee", "department", "deadline", "checklist"]
              }
            },
            {
              name: "create_user",
              description: "Tạo thành viên, nhân viên, hoặc tài khoản mới trong công ty. KHÔNG gọi tool này khi sếp yêu cầu tạo nhiệm vụ / công việc.",
              parameters: {
                type: "OBJECT",
                properties: {
                  name: { type: "STRING" },
                  email: { type: "STRING" },
                  role: { type: "STRING", enum: ["Employee", "Manager", "Admin"] },
                  department: { type: "STRING" }
                },
                required: ["name", "role", "department"]
              }
            },
            {
              name: "delete_user",
              description: "Xóa tài khoản, nhân viên, thành viên trong công ty. Hãy dùng đối với lệnh xóa tài khoản hoặc sa thải nhân viên.",
              parameters: {
                type: "OBJECT",
                properties: {
                  email: { type: "STRING" },
                  name: { type: "STRING" }
                }
              }
            },
            {
              name: "delete_task",
              description: "Xóa công việc, nhiệm vụ (task) ra khỏi hệ thống.",
              parameters: {
                type: "OBJECT",
                properties: {
                  taskId: { type: "STRING" },
                  title: { type: "STRING" }
                }
              }
            }
          ]
        }
      ];

      const formattedContents = messages.slice(-10).map((msg: any) => ({
        role: msg.sender === 'user' ? 'user' : 'model',
        parts: [{ text: msg.text || msg.content }]
      }));

      const response = await genAI.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: formattedContents as any,
        config: {
          systemInstruction: systemInstruction,
          tools: geminiTools
        }
      });

      const functionCalls = response.functionCalls;
      if (functionCalls && functionCalls.length > 0) {
        return res.json({ 
          success: true, 
          aiGenerated: true, 
          functionCalls,
          reply: "Đã rõ mệnh lệnh của sếp. Em đang đồng bộ hệ thống..." 
        });
      }

      return res.json({ 
        success: true, 
        aiGenerated: true, 
        reply: (response.text || "").trim() 
      });
    } catch (err) {
      console.error("Gemini Chat with tools error:", err);
    }
  }

  // 2. Logic for Groq (Default / Fallback)
  if (groq) {
    try {
      const groqMessages: any[] = [
        { role: "system", content: systemInstruction },
        ...messages.slice(-10).map((msg: any) => ({
          role: msg.sender === 'user' ? 'user' : 'assistant',
          content: msg.text || msg.content
        }))
      ];

      const groqTools = [
        {
          type: "function" as const,
          function: {
            name: "create_task",
            description: "Tạo nhiệm vụ (công việc, task) mới cho nhân viên. KHÔNG gọi tool này khi sếp yêu cầu tạo tài khoản / nhân viên mới.",
            parameters: {
              type: "object",
              properties: {
                title: { type: "string" },
                description: { type: "string" },
                assignee: { type: "string" },
                department: { type: "string" },
                deadline: { type: "string" },
                priority: { type: "string", enum: ["Low", "Medium", "High"] },
                kpiScore: { type: "number" },
                followers: { type: "array", items: { type: "string" } },
                checklist: { type: "array", items: { type: "string" } }
              },
              required: ["title", "assignee", "department", "deadline", "checklist"]
            }
          }
        },
        {
          type: "function" as const,
          function: {
            name: "create_user",
            description: "Tạo thành viên, nhân viên, hoặc tài khoản mới trong công ty. KHÔNG gọi tool này khi sếp yêu cầu tạo nhiệm vụ / công việc.",
            parameters: {
              type: "object",
              properties: {
                name: { type: "string" },
                email: { type: "string" },
                role: { type: "string", enum: ["Employee", "Manager", "Admin"] },
                department: { type: "string" }
              },
              required: ["name", "role", "department"]
            }
          }
        },
        {
          type: "function" as const,
          function: {
            name: "delete_user",
            description: "Xóa tài khoản, nhân viên, thành viên trong công ty. Hãy dùng đối với lệnh xóa tài khoản hoặc sa thải nhân viên.",
            parameters: {
              type: "object",
              properties: {
                email: { type: "string" },
                name: { type: "string" }
              }
            }
          }
        },
        {
          type: "function" as const,
          function: {
            name: "delete_task",
            description: "Xóa công việc, nhiệm vụ (task) ra khỏi hệ thống.",
            parameters: {
              type: "object",
              properties: {
                taskId: { type: "string" },
                title: { type: "string" }
              }
            }
          }
        }
      ];

      const completion = await groq.chat.completions.create({
        messages: groqMessages,
        model: "llama-3.3-70b-versatile",
        tools: groqTools,
        tool_choice: "auto"
      });

      const choice = completion.choices[0];
      if (choice.message.tool_calls) {
        const functionCalls = choice.message.tool_calls.map(tc => ({
          name: tc.function.name,
          args: JSON.parse(tc.function.arguments)
        }));
        return res.json({ 
          success: true, 
          aiGenerated: true, 
          functionCalls,
          reply: "Đã rõ mệnh lệnh của sếp. Em đang đồng bộ hệ thống..." 
        });
      }

      return res.json({ success: true, aiGenerated: true, reply: choice.message.content?.trim() });
    } catch (err) {
      console.error("Groq Chat error:", err);
    }
  }

  res.json({ success: true, aiGenerated: false, reply: "Simulation reply." });
});

// 4. AI Suggest Checklist
app.post('/api/ai/suggest-checklist', async (req, res) => {
  const { title, department } = req.body;

  if (groq) {
    try {
      const completion = await groq.chat.completions.create({
        messages: [{ role: "user", content: `Hãy phân rã công việc "${title}" tại "${department}" thành 4-6 bước checklist. Ngắn gọn, mỗi bước 1 dòng.` }],
        model: "llama-3.1-8b-instant",
      });
      return res.json({ success: true, checklist: completion.choices[0].message.content });
    } catch (error) {
       console.error("Groq internal error:", error);
    }
  }
  res.json({ success: false });
});

// 5. AI Split Task
app.post('/api/ai/split-task', async (req, res) => {
  const { title } = req.body;

  if (groq) {
    try {
      const completion = await groq.chat.completions.create({
        messages: [{ role: "user", content: `Phân tích: "${title}". Trả về JSON: { description, checklist: string[], kpiScore: number }` }],
        model: "llama-3.3-70b-versatile",
        response_format: { type: "json_object" }
      });
      return res.json({ success: true, data: JSON.parse(completion.choices[0].message.content || '{}') });
    } catch (error) {
       console.error("Groq internal error:", error);
    }
  }
  res.json({ success: false });
});


// ==========================================================
// CHATBOT DUYÊN - REAL INTEGRATION & CONCIERGE ENDPOINTS
// ==========================================================

// 1. Live Embedded Javascript script server
app.get('/api/chatbot/embed.js', (req, res) => {
  res.set('Content-Type', 'application/javascript');
  
  // Construct dynamic host origin based on requested headers to ensure protocol/host correctness
  const host = req.headers.host || `localhost:${PORT}`;
  const protocol = req.secure || req.headers['x-forwarded-proto'] === 'https' ? 'https' : 'http';
  const originUrl = `${protocol}://${host}`;

  const scriptCode = `
(function() {
  if (document.getElementById('tindan-chatbot-root')) return;

  var container = document.createElement('div');
  container.id = 'tindan-chatbot-root';
  container.style.position = 'fixed';
  container.style.bottom = '20px';
  container.style.right = '20px';
  container.style.zIndex = '2147483647';
  container.style.width = '70px';
  container.style.height = '70px';
  container.style.transition = 'all 0.3s cubic-bezier(0.16, 1, 0.3, 1)';
  container.style.borderRadius = '50%';
  container.style.boxShadow = '0 10px 30px rgba(0,0,0,0.18)';
  container.style.overflow = 'hidden';
  document.body.appendChild(container);

  var iframe = document.createElement('iframe');
  iframe.src = "${originUrl}/?view=chatbot-widget&page=" + encodeURIComponent(document.title || window.location.pathname);
  iframe.style.width = '100%';
  iframe.style.height = '100%';
  iframe.style.border = 'none';
  iframe.style.background = 'transparent';
  container.appendChild(iframe);

  window.addEventListener('message', function(event) {
    if (event.origin !== "${originUrl}") return;
    if (event.data && event.data.type === 'tindan_chatbot_resize') {
      if (event.data.collapsed) {
        container.style.width = '70px';
        container.style.height = '70px';
        container.style.bottom = '20px';
        container.style.right = '20px';
        container.style.borderRadius = '50%';
        container.style.boxShadow = '0 10px 30px rgba(0,0,0,0.18)';
      } else {
        if (window.innerWidth < 480) {
          container.style.width = '100%';
          container.style.height = '100%';
          container.style.bottom = '0';
          container.style.right = '0';
          container.style.borderRadius = '0';
        } else {
          container.style.width = '390px';
          container.style.height = '620px';
          container.style.bottom = '24px';
          container.style.right = '24px';
          container.style.borderRadius = '24px';
        }
        container.style.boxShadow = '0 16px 48px rgba(0,0,0,0.22)';
      }
    }
  });
})();
  `;
  res.send(scriptCode.trim());
});

// 2. Fetch Chatbot Config from Firestore
app.get('/api/chatbot/config', async (req, res) => {
  try {
    if (db) {
      const colRef = collection(db, 'chatbot_duyen_config');
      const snap = await getDocs(query(colRef));
      if (!snap.empty) {
        return res.json({ success: true, config: snap.docs[0].data() });
      }
    }
  } catch (err) {
    console.warn("Backend fail to load DB config, serving fallback:", err);
  }

  // Pure default template fallback
  res.json({
    success: true,
    config: {
      botName: 'Duyên AI Chăm Sóc Tự Động',
      greeting: 'Xin chào! Em là trợ lý ảo Duyên của doanh nghiệp Tín Dân. Em có thể tư vấn gì về kỹ thuật in decal tem cuộn cho quý khách ạ?',
      systemPrompt: 'Bạn là tư vấn viên cao cấp của Tín Dân Company. Chỉ trả lời trọng tâm về kỹ thuật in decal bảo ôn mác dán sản xuất UV và các quy chuẩn Vivian, không cư xử thô lỗ hay bừa bãi.',
      primaryColor: '#2563eb',
      layout: 'bottom_right',
      avatar: '👩‍💼',
      popupEffect: 'slide_up',
      hotlineEnabled: true,
      hotline: '0903810082',
      hotlineBtnText: 'Bấm Gọi Hotline Tín Dân',
      knowledgeBase: 'Tín Dân chuyên in ấn tem nhãn cuộn decal, tem bảo ôn, tem dán sản xuất mác Vivian, trang bị lò sấy UV công suất cao, đạt chuẩn Vivian Q2. Hotline hỗ trợ 24/7.',
      aiTemperature: 0.4
    }
  });
});

// 3. Write real Lead entries directly to Firestore
app.post('/api/chatbot/submit-lead', async (req, res) => {
  try {
    const { name, phone, demand, referrerPage } = req.body;
    if (!name || !phone) {
      return res.status(400).json({ success: false, message: 'Vui lòng cung cấp cả Tên và Số điện thoại khách hàng.' });
    }

    const leadId = 'lead_' + Date.now();
    const leadObj = {
      id: leadId,
      name,
      phone,
      demand: demand || `Yêu cầu tư vấn chung tại trang: ${referrerPage || 'Website nhúng'}`,
      referrerPage: referrerPage || 'Website nhúng',
      timestamp: new Date().toISOString(),
      status: 'new'
    };

    if (db) {
      // Use Firestore client initialized on the server
      await setDoc(doc(db, 'chatbot_duyen_leads', leadId), leadObj);
      console.log(`[BACKEND REAL SAVE] Saved genuine Lead from external widget: ${leadId}`);
    }

    res.json({ success: true, leadId });
  } catch (err: any) {
    console.error("Backend error writing lead:", err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// 4. Real AI messaging query via Gemini as primary and Groq as backup fallback
app.post('/api/chatbot/chat', async (req, res) => {
  try {
    const { message, page, config } = req.body;
    const sysPrompt = config?.systemPrompt || 'Bạn là trợ lý ảo Duyên của Tín Dân Company.';
    const kb = config?.knowledgeBase || '';

    const prompt = `Bạn tên là Duyên, trợ lý ảo đại diện cho doanh nghiệp Tín Dân Company.
Hãy trả lời câu hỏi của khách hàng đặt câu hỏi tại trang "${page}" dưới đây:
"${message}"

Tài liệu nội bộ & Kiến thức ngành của Tín Dân (Knowledge Base):
${kb}

Chỉ thị về vai trò & Phong thái giao tiếp (System Prompt):
${sysPrompt}

Quy tắc ứng xử cao cấp:
1. Bạn phải xưng là "em" hoặc "em Duyên", lễ phép và kính trọng gọi khách hàng là "anh/chị" hoặc "sếp".
2. Chỉ bàn luận và làm rõ các kỹ thuật dập tem cuộn dính decal, tem bóc sấy UV, nhãn mát Vivian cao cấp của Tín Dân. Tránh nói chuyện tào lao hay xuyên tạc.
3. Nếu khách hàng tỏ ý quan tâm, muốn nhận tư vấn, báo giá, hoặc thiết kế thử dán nhãn decal, hãy khéo léo gạ xin họ số điện thoại để kỹ sư tại Tổng đài Tín Dân gọi lại hỗ trợ liền.
4. Trả lời cực kỳ ngắn gọn, mạch lạc, tinh tế, không được lạm dụng các ký tự Markdown rườm rà (như *, #, __). Xuống dòng tự nhiên như đang chat zalo thực thụ.`;

    let replyText = "";

    // 1. MAIN STRATEGY: Google Gemini (Powerful Vietnamese, highly intuitive)
    if (genAI) {
      try {
        console.log("[AI CHAT] Đang truy vấn Gemini làm phương án CHÍNH...");
        // Prefer gemini-2.5-flash as it is extremely smart, responsive, and has a rich free-tier capability
        const response = await genAI.models.generateContent({
          model: "gemini-2.5-flash-lite", // Fallbacks elegantly to current latest production builds
          contents: prompt
        });
        replyText = (response.text || "").trim();
        if (replyText) {
          console.log("[AI CHAT] Gemini phản hồi thành công.");
          return res.json({ success: true, reply: replyText, provider: 'gemini' });
        }
      } catch (geminiErr: any) {
        console.warn("[⚠️ AI WARN] Gemini chính gặp lỗi, lập tức kích hoạt Groq dự phòng:", geminiErr.message);
      }
    }

    // 2. BACKUP STRATEGY: Groq API (Unmatched inference speed, versatile)
    if (groq) {
      try {
        console.log("[AI CHAT] Đang truy vấn Groq làm phương án DỰ PHÒNG...");
        const completion = await groq.chat.completions.create({
          messages: [{ role: 'user', content: prompt }],
          model: "llama-3.3-70b-versatile"
        });
        replyText = (completion.choices[0].message.content || "").trim();
        if (replyText) {
          console.log("[AI CHAT] Groq dự phòng phản hồi thành công.");
          return res.json({ success: true, reply: replyText, provider: 'groq' });
        }
      } catch (groqErr: any) {
        console.error("[❌ AI ERROR] Cả phương án chính Gemini và dự phòng Groq đều lỗi:", groqErr.message);
      }
    }

    // 3. Fallback to friendly concierge default response
    res.json({ 
      success: true, 
      reply: "Dạ em Duyên đã nhận được phản hồi của sếp. Hiện tại đường truyền đang bảo trì nhẹ để nâng cấp lò sấy UV, sếp vui lòng liên hệ hotline 0903810082 để bên Tín Dân em gọi điện hỗ trợ tức thì nhé ạ!",
      provider: 'concierge_fallback'
    });
  } catch (err: any) {
    console.error("Chat proxy error:", err);
    res.json({ success: true, reply: "Dạ đường truyền UV đang bận chút xíu, sếp vui lòng để lại số điện thoại để bên em chủ động kết nối ngay ạ!" });
  }
});


// ==========================================================
// ZALO OA - GENUINE DEVELOPERS INTEGRATION ENDPOINTS
// ==========================================================

// 1. Send genuine credentials to Zalo API to test long-term Access Token activity
app.post('/api/zalo/test-connection', async (req, res) => {
  const { accessToken } = req.body;
  if (!accessToken) {
    return res.status(400).json({ success: false, message: 'Sếp cần điền Access Token hợp lệ trước.' });
  }

  try {
    const response = await fetch('https://openapi.zalo.me/v2.0/oa/getoa', {
      method: 'GET',
      headers: {
        'access_token': accessToken
      }
    });

    const data = await response.json();
    if (data.error === 0) {
      res.json({
        success: true,
        message: `Xác thực thành công với Zalo Developers! Tên OA: "${data.data?.name || 'Tín Dân'}", Số người theo dõi: ${data.data?.followers || 0} thành viên.`
      });
    } else {
      res.json({
        success: false,
        message: `Zalo API phản hồi lỗi (Mã lỗi: ${data.error}): ${data.message}`
      });
    }
  } catch (err: any) {
    res.status(500).json({
      success: false,
      message: `Không thể kết xuất tín hiệu mạng tới máy chủ Zalo OpenAPI: ${err.message}`
    });
  }
});

// 2. Real transactional conversion message send to raw customer IDs
app.post('/api/zalo/send-message', async (req, res) => {
  const { accessToken, recipientId, content } = req.body;
  if (!accessToken || !recipientId || !content) {
    return res.status(400).json({ success: false, message: 'Tham số truyền Zalo API không đủ: accessToken, recipientId, content.' });
  }

  try {
    const response = await fetch('https://openapi.zalo.me/v3.0/oa/message/transaction', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'access_token': accessToken
      },
      body: JSON.stringify({
        recipient: {
          user_id: recipientId
        },
        message: {
          text: content
        }
      })
    });

    const data = await response.json();
    if (data.error === 0) {
      res.json({ success: true, message: `Tin nhắn Zalo đã được truyền tải thực tế tới người dùng (ID: ${recipientId})!` });
    } else {
      res.json({ success: false, message: `Zalo API từ chối gửi tin (Mã lỗi: ${data.error}): ${data.message}` });
    }
  } catch (err: any) {
    console.error("Zalo post message error:", err);
    res.status(500).json({ success: false, message: `Lỗi kết nối Zalo Server: ${err.message}` });
  }
});


// ==========================================
// NEW MULTIPLE ZALO OA WEBHOOK RECEIVER & CRM LOGGING
// ==========================================

async function processZaloWebhookEvent(oaId: string, eventData: any) {
  const messageText = eventData?.message?.text || eventData?.content || '';
  const senderName = eventData?.sender?.name || eventData?.sender_name || 'Khách Zalo';
  const senderId = eventData?.sender?.id || eventData?.sender_id || 'zalo_user_' + Date.now();
  
  // Extract phone number from message text
  let extractedPhone = null;
  const cleaned = messageText.replace(/[\s\.-]/g, '');
  const match = cleaned.match(/(?:\+84|84|0)(3|5|7|8|9)\d{8}/) || cleaned.match(/0\d{9,10}/);
  if (match) {
    let num = match[0];
    if (num.startsWith('+84')) num = '0' + num.slice(3);
    else if (num.startsWith('84') && num.length > 10) num = '0' + num.slice(2);
    extractedPhone = num;
  }

  const messageId = 'zmsg_' + Date.now() + Math.random().toString(36).substr(2, 5);
  const zMsgObj = {
    id: messageId,
    oaId,
    senderId,
    senderName,
    content: messageText || '(Không có nội dung văn bản)',
    timestamp: new Date().toISOString(),
    extractedPhone,
    status: 'received'
  };

  if (db) {
    try {
      await setDoc(doc(db, 'zalo_webhook_messages', messageId), zMsgObj);
    } catch (e) {
      console.error("Failed to write webhook message to Firestore:", e);
    }
  }

  // If a phone number is detected, automatically create a Lead
  if (extractedPhone) {
    const leadId = 'lead_zalo_' + Date.now();
    const leadObj = {
      id: leadId,
      name: senderName,
      phone: extractedPhone,
      demand: `Cơ cấu gửi tin từ Zalo OA nhắn tin: "${messageText}"`,
      referrerPage: `Zalo OA Webhook: ${oaId}`,
      timestamp: new Date().toISOString(),
      status: 'new'
    };

    if (db) {
      try {
        await setDoc(doc(db, 'chatbot_duyen_leads', leadId), leadObj);
        
        // Write notification
        const notifId = 'notif_lead_' + Date.now();
        const notificationObj = {
          id: notifId,
          title: 'Khách Phát Sinh từ Zalo OA 🌟',
          content: `Vừa thu hoạch Lead mới từ Zalo OA: ${senderName} (${extractedPhone}). Khách nhắn: "${messageText}".`,
          type: 'system',
          createdAt: new Date().toISOString(),
          read: false,
          department: 'Sale'
        };
        await setDoc(doc(db, 'notifications', notifId), notificationObj);
      } catch (err) {
        console.error("Failed to write Lead/Notification in Zalo Webhook:", err);
      }
    }
  } else {
    // Notify sếp
    if (db) {
      try {
        const notifId = 'notif_zmsg_' + Date.now();
        const notificationObj = {
          id: notifId,
          title: 'Tin nhắn Zalo OA Mới 💬',
          content: `Khách hàng ${senderName} gửi tin nhắn mới: "${messageText}"`,
          type: 'comment',
          createdAt: new Date().toISOString(),
          read: false,
          department: 'Sale'
        };
        await setDoc(doc(db, 'notifications', notifId), notificationObj);
      } catch (err) {
        console.error("Failed to write Zalo message notification:", err);
      }
    }
  }

  return { messageId, extractedPhone, senderName, content: messageText };
}

// REST Webhook receiver
app.post('/api/zalo/webhook/:id', async (req, res) => {
  const { id } = req.params;
  const eventData = req.body;
  try {
    const result = await processZaloWebhookEvent(id, eventData);
    res.status(200).json({ success: true, message: 'Webhook processed successfully', ...result });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET all OA configurations
app.get('/api/zalo/oas', async (req, res) => {
  try {
    if (db) {
      const snap = await getDocs(query(collection(db, 'zalo_oa_configurations')));
      const list = snap.docs.map(d => d.data());
      return res.json({ success: true, list });
    }
  } catch (err: any) {
    console.error("Failed to fetch Zalo OAs:", err);
  }
  res.json({ success: true, list: [] });
});

// POST save/add OA config
app.post('/api/zalo/oas', async (req, res) => {
  const { id, name, status } = req.body;
  if (!id || !name) {
    return res.status(400).json({ success: false, message: 'Thiếu thông tin ID và Tên OA' });
  }

  const oaObj = {
    id,
    name,
    status: status || 'active',
    createdAt: new Date().toISOString()
  };

  try {
    if (db) {
      await setDoc(doc(db, 'zalo_oa_configurations', id), oaObj);
      return res.json({ success: true, oa: oaObj });
    }
  } catch (err: any) {
    console.error("Failed to save Zalo OA:", err);
    return res.status(500).json({ success: false, message: err.message });
  }
  res.json({ success: true, oa: oaObj });
});

// DELETE OA config
app.delete('/api/zalo/oas/:id', async (req, res) => {
  const { id } = req.params;
  try {
    if (db) {
      const { deleteDoc } = await import('firebase/firestore');
      await deleteDoc(doc(db, 'zalo_oa_configurations', id));
      return res.json({ success: true, message: 'Đã xóa OA thành công' });
    }
  } catch (err: any) {
    console.error("Failed to delete Zalo OA:", err);
    return res.status(500).json({ success: false, message: err.message });
  }
  res.json({ success: true });
});

// GET all webhook messages received
app.get('/api/zalo/messages', async (req, res) => {
  try {
    if (db) {
      const snap = await getDocs(query(collection(db, 'zalo_webhook_messages')));
      const list = snap.docs.map(d => d.data());
      list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      return res.json({ success: true, list });
    }
  } catch (err: any) {
    console.warn("Failed to fetch webhook messages:", err);
  }
  res.json({ success: true, list: [] });
});

// Mock simulation of webhook test event trigger
app.post('/api/zalo/test-webhook', async (req, res) => {
  const { oaid, senderName, content } = req.body;
  if (!oaid) {
    return res.status(400).json({ success: false, message: 'Vui lòng chọn OA nhận tin nhắn nhỡ' });
  }

  const fakeEvent = {
    sender: {
      id: 'sender_sim_' + Math.floor(Math.random() * 1000000),
      name: senderName || 'Khách Hàng Bí Danh'
    },
    message: {
      text: content || 'Tôi muốn được gọi điện tư vấn tem dán bảo bì, số điện thoại của tôi: 0914227788'
    }
  };

  try {
    const result = await processZaloWebhookEvent(oaid, fakeEvent);
    return res.json({ success: true, result });
  } catch (err: any) {
    return res.status(500).json({ success: false, message: err.message });
  }
});

// Dry-run/ping chatbot connection checking
app.get('/api/chatbot/ping', (req, res) => {
  res.json({ success: true, message: 'Kết nối thông suốt! Máy chủ AI Tín Dân CRM sẵn sàng phản hồi tín hiệu nhúng.', timestamp: new Date().toISOString() });
});


// ==========================================
// VITE OR STATIC INGRESS HANDLER
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    console.log("Vite development server mounted gracefully.");
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log("Serving production bundle from:", distPath);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[TÍN DÂN CRM SERVER] Running on port http://0.0.0.0:${PORT}`);
  });
}

startServer();
